(function () {

    var app = angular.module('app', ['breeze.angular']);

    app.controller('Main', MainController);
 
 
 
    
    ///////////////////////
    
    function MainController($q, breeze){
      var vm = this;
      vm.message = '... waiting for github angular Members ...';
      vm.title = 'Angular Team Members on github';
      vm.members = [];
 
      
      // create a new EntityManager talking to the github api 
      var ds = new breeze.DataService({
          serviceName: "http://sandbox.gapapp.ca/v1/",
          hasServerMetadata: false 
      });
      
      var manager = new breeze.EntityManager({dataService: ds});
      
      
      
      // Add metadata
      var memberType = {
          shortName: 'Member',

          dataProperties: {
            id:          { dataType: breeze.DataType.Int64, isPartOfKey: true },
            login:       { /* string type by default */ },
            html_url:    { }
          }  
        };
        
      manager.metadataStore
             .addEntityType(new breeze.EntityType(memberType));      

 
      // QUERY github
 
      // Get angular team members 
      var query = breeze.EntityQuery.from('get/incidents?access_token=MLJRbRXOfDGZfFjmWsSKr8VaBrLPhUl1tDRWFKQr')
                         // Must tell Breeze that response data are Members
                        .toType('Member');
      
      manager.executeQuery(query)
        .then(success)
        .then(getMembersFromCache)
        .catch(fail);


      function success(data){
      	var cachedData = manager.exportEntities();
	console.log(cachedData);
      	window.localStorage.setItem('savedCache', cachedData);
        console.log('Got '+ data.results.length+ ' items returned from github');
	console.log(data)
      }
      
      function getMembersFromCache(){
        var cachedMembers = manager.getEntities('Member');
        vm.message = "There are "+cachedMembers.length + " github Members in cache"; 
        vm.members = cachedMembers;
      }
      
      function fail(error) {
          console.log("Angular team member query failed: " + error.message);
          var cacheData = window.localStorage.getItem('savedCache');
          manager.importEntities(cacheData);
          var nquery = query.using(breeze.FetchStrategy.FromLocalCache);
          return $q(function () {return getMembersFromCache();});
      }       

    }

}());

