<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormQTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_q', function (Blueprint $table) {
            $table->increments('id');
            $table->string('date_harvested');
            $table->string('field_block_tag');
            $table->string('harvest_date');
            $table->string('incoming_pack');
            $table->string('lot_id');
            $table->string('market_product_storage');
            $table->string('name_produced');
            $table->string('outgoing_pack_id');
            $table->boolean('packaging_checked');
            $table->boolean('phi_eahd');
            $table->string('primary_package');
            $table->string('product_variety');
            $table->boolean('production_site_assesed');
            $table->string('secondary_package');
            $table->string('wax_lot');
            $table->string('quantity');
            $table->string('packing_repacking');
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_q');
    }
}
