<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormOTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_o', function(Blueprint $table) {
            $table->increments('id');
            $table->boolean('vehicle_inspected')->default(false);
            $table->string('hazards')->nullable();
            $table->string('actions')->nullable();
            $table->text('destination_and_customer');
            $table->string('product_identifier');
            $table->string('quantity_shipped');
            $table->string('truck_id');
            $table->string('person_responsible');
            $table->integer('user_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_o');
    }
}
