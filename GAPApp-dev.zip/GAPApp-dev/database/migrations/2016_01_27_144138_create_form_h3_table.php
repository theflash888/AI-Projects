<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormH3Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_h3', function(Blueprint $table) {
            $table->increments('id');
            $table->integer('production_site')->unsigned();
            $table->string('operation_name');
            $table->string('variety');
            $table->string('product_name');
            $table->string('pcp');
            $table->string('rate_applied');
            $table->string('quantity_treated');
            $table->string('lot_id');
            $table->string('daa');
            $table->integer('user_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('production_site')
              ->references('id')
              ->on('entities_name')
              ->onUpdate('cascade')
              ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_h3');
    }
}
