<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('requests', function (Blueprint $table) {
            $table->increments('id');
            $table->string('token', 10);
            $table->string("org_name");
            $table->string("org_type", 10);
            $table->string('org_first_name');
            $table->string('org_last_name');
            $table->string('org_audit_company');
            $table->string('org_audit_cycle');
            $table->string('org_fns_coordinator');
            $table->string('contact_email');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('requests');
    }
}
