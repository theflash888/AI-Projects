<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormBTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_b', function (Blueprint $table) {
            $table->increments('id');
            $table->string('date');
            $table->integer('storage_id')->unsigned();
            $table->string('ceiling_storage', 3);
            $table->text('ceiling_storage_action')->nullable();
            $table->string('floor_clean', 3);
            $table->text('floor_clean_action')->nullable();
            $table->string('free_animals', 3);
            $table->text('free_animals_action')->nullable();
            $table->string('furnace_exhausting', 3);
            $table->text('furnace_exhausting_action')->nullable();
            $table->string('production_equipment', 3);
            $table->text('production_equipment_action')->nullable();
            $table->string('leaky_area', 3);
            $table->text('leaky_area_action')->nullable();
            $table->string('lights_shatterproof', 3);
            $table->text('lights_shatterproof_action')->nullable();
            $table->string('no_smoking', 3);
            $table->text('no_smoking_action')->nullable();
            $table->string('other', 3);
            $table->text('other_action')->nullable();
            $table->string('potatoes_dark', 3);
            $table->text('potatoes_dark_action')->nullable();
            $table->string('potatoes_treated', 3);
            $table->text('potatoes_treated_action')->nullable();
            $table->string('proper_condition', 3);
            $table->text('proper_condition_action')->nullable();
            $table->string('storage_in_use', 3);
            $table->text('storage_in_use_action')->nullable();
            $table->string('storage_secured', 3);
            $table->text('storage_secured_action')->nullable();
            $table->string('treated_seed', 3);
            $table->text('treated_seed_action')->nullable();
            $table->text('storage_cleaning_desc')->nullable();
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_b');
    }
}
