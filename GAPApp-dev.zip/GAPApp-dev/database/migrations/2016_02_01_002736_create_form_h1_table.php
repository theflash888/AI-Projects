<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormH1Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_h1', function (Blueprint $table) {
            $table->increments('id');
            $table->string('actual_quantity_used');
            $table->string('area_treated');
            $table->string('current_crop');
            $table->string('date_planted');
            $table->string('eahd');
            $table->boolean('label_followed');
            $table->string('method_of_application');
            $table->string('operation_name');
            $table->string('pcp');
            $table->string('phi_daa');
            $table->string('previous_year_crops');
            $table->integer('product_site_information')->unsigned();
            $table->string('product_trade_name');
            $table->string('production_site_area');
            $table->string('rate_applied');
            $table->string('seed_certificate')->nullable();
            $table->string('variety');
            $table->string('weather_condition');
            $table->string('person_responsible');
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('product_site_information')
              ->references('id')
              ->on('entities_name')
              ->onUpdate('cascade')
              ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_h1');
    }
}
