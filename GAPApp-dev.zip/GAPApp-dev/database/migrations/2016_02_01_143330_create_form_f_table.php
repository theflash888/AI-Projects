<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormFTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_f', function (Blueprint $table) {
            $table->increments('id');
            $table->boolean('animal_access');
            $table->boolean('appendix_a');
            $table->boolean('appendix_b');
            $table->boolean('appendix_h');
            $table->string('appendix_or')->nullable();
            $table->boolean('chemical_application');
            $table->boolean('cistern');
            $table->boolean('cleaned');
            $table->string('commodity')->nullable();
            $table->boolean('cooling');
            $table->boolean('drenching');
            $table->boolean('dump_tank');
            $table->boolean('equipment_container');
            $table->boolean('final_rinse');
            $table->boolean('fluming');
            $table->boolean('hand_washing');
            $table->boolean('hose');
            $table->boolean('humidity');
            $table->boolean('ice');
            $table->boolean('other');
            $table->boolean('other_cleaning');
            $table->string('other_method')->nullable();
            $table->boolean('other_possible');
            $table->string('other_possible_hazard')->nullable();
            $table->boolean('pit');
            $table->boolean('pressure_wash');
            $table->boolean('recycled');
            $table->boolean('runoff');
            $table->boolean('spray');
            $table->boolean('stored');
            $table->boolean('tap');
            $table->boolean('treated');
            $table->boolean('washing');
            $table->string('water_first_used');
            $table->string('water_prior_test');
            $table->string('water_second_test');
            $table->integer('water_source');
            $table->boolean('well');
            $table->boolean('wetting');
            $table->boolean('working_condition');
            $table->string('actions', 2);
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_f');
    }
}
