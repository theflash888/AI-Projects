<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConfirmRecordsFixTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('form_b', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_c', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_d', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_e', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_f', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_g', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();
        });

        Schema::table('form_h1', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_h2', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_h3', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_i', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_j', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_k', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();
        });

        Schema::table('form_l', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_m', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_n1', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_n2', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_o', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_p1', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_p2', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_q', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_r', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_s', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        Schema::table('form_t', function($table)
        {
            $table->boolean('is_completed')->default(false);
            $table->integer('confirmed_by_id')->nullable()->unsigned();

            $table->foreign('confirmed_by_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        
    }
}
