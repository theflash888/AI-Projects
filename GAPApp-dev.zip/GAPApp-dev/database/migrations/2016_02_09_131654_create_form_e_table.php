<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormETable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_e', function(Blueprint $table) {
            $table->increments('id');

            $table->boolean('birds_exterior_devices');
            $table->boolean('birds_inside_devices');
            $table->string('birds_exterior_devices_info')->nullable();
            $table->string('birds_inside_devices_info')->nullable();

            $table->boolean('rodents_exterior_bait');
            $table->boolean('rodents_exterior_traps');
            $table->boolean('rodents_chemicals');
            $table->boolean('rodents_exterior_other');
            $table->boolean('rodents_inside_traps');
            $table->boolean('rodents_inside_other');
            $table->string('rodents_exterior_bait_type')->nullable();
            $table->string('rodents_exterior_traps_type')->nullable();
            $table->string('rodents_exterior_other_info')->nullable();
            $table->string('rodents_inside_traps_type')->nullable();
            $table->string('rodents_inside_other_info')->nullable();

            $table->boolean('insects_exterior_bait');
            $table->boolean('insects_exterior_traps');
            $table->boolean('insects_exterior_chemicals');
            $table->boolean('insects_exterior_other');
            $table->boolean('insects_inside_traps');
            $table->boolean('insects_inside_chemicals');
            $table->boolean('insects_inside_other');
            $table->string('insects_exterior_bait_type')->nullable();
            $table->string('insects_exterior_traps_type')->nullable();
            $table->string('insects_exterior_other_info')->nullable();
            $table->string('insects_inside_traps_type')->nullable();
            $table->string('insects_inside_other_info')->nullable();

            $table->text('exterior_chemicals_list')->nullable();
            $table->text('inside_chemicals_list')->nullable();
            $table->text('rodents_chemical_list')->nullable();

            $table->text('other_information')->nullable();

            $table->integer('storage_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('storage_id')
                ->references('id')
                ->on('entities_name')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_e');
    }
}
