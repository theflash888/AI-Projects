<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIncidentCommentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('incident_comments', function (Blueprint $table) {
           $table->increments('id');
           $table->text('comment');
           $table->integer('user_id')->unsigned();
           $table->integer('incident_id')->unsigned();
           $table->softDeletes();
           $table->timestamps();

           $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade'); 

            $table->foreign('incident_id')
                ->references('id')
                ->on('incidents')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('incident_comments');
    }
}
