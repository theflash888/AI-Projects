<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormP2Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_p2', function(Blueprint $table) {
            $table->increments('id');
            $table->string('field_block');
            $table->string('packaging_material');
            $table->boolean('phi_eahd_daa');
            $table->string('product_variety');
            $table->boolean('production_assessed');
            $table->string('quantity');
            $table->string('harvest_date');
            $table->integer('storage_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeleteS();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('storage_id')
              ->references('id')
              ->on('entities_name')
              ->onUpdate('cascade')
              ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_p2');
    }
}
