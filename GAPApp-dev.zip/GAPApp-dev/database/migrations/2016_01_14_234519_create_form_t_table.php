<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormTTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_t', function (Blueprint $table) {
            $table->increments('id');
            $table->string('date');
            $table->boolean('general_security')->default(false);
            $table->boolean('storage_security')->default(false);
            $table->boolean('water_security')->default(false);
            $table->boolean('agriculture_security')->default(false);
            $table->boolean('information_security')->default(false);
            $table->boolean('personnel_security')->default(false);
            $table->boolean('physical_security')->default(false);
            $table->boolean('entry_security')->default(false);
            $table->text('actions')->nullable();
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_t');
    }
}
