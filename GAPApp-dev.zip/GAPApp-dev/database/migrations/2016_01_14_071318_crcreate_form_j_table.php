<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CrcreateFormJTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_j', function (Blueprint $table) {
            $table->increments('id');
            $table->string('facility');
            $table->boolean('assessment')->default(false);
            $table->boolean('paper_towel')->default(false);
            $table->boolean('soap')->default(false);
            $table->boolean('water_source')->default(false);
            $table->boolean('toilet_paper')->default(false);
            $table->boolean('hand_sanitizer')->default(false);
            $table->boolean('garbage_emptied')->default(false);
            $table->integer('location')->unsigned();
            $table->string('location_type')->nullable();
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('location')
                ->references('id')
                ->on('entities_name')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_j');
    }
}
