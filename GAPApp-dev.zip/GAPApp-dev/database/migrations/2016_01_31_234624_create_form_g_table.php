<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormGTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_g', function (Blueprint $table) {
            $table->increments('id');
            $table->string('adequate_ventilation', 3)->nullable();
            $table->string('animals', 3)->nullable();
            $table->string('control_measures', 3)->nullable();
            $table->string('exterior_doors_close_fitting', 3)->nullable();
            $table->string('exterior_doors_secured', 3)->nullable();
            $table->string('exterior_dumpster', 3)->nullable();
            $table->string('exterior_half_perimeter', 3)->nullable();
            $table->string('exterior_land_drainage', 3)->nullable();
            $table->string('exterior_land_drainage_structure', 3)->nullable();
            $table->text('exterior_maintenance')->nullable();
            $table->string('exterior_maintenance_completed_by')->nullable();
            $table->string('exterior_maintenance_completed_date')->nullable();
            $table->string('exterior_maintenance_overseen_by')->nullable();
            $table->string('exterior_maintenance_overseen_date')->nullable();
            $table->string('exterior_no_areas_pests', 3)->nullable();
            $table->string('exterior_no_junk', 3)->nullable();
            $table->string('exterior_roof_cover', 3)->nullable();
            $table->string('exterior_weeds', 3)->nullable();
            $table->string('exterior_weeds_controlled', 3)->nullable();
            $table->string('exterior_windows_closed', 3)->nullable();
            $table->string('fans_air_free', 3)->nullable();
            $table->string('floor_drainage', 3)->nullable();
            $table->string('floor_free_pests', 3)->nullable();
            $table->string('floors_clean', 3)->nullable();
            $table->text('interior_maintenance')->nullable();
            $table->string('interior_maintenance_completed_by')->nullable();
            $table->string('interior_maintenance_completed_date')->nullable();
            $table->string('interior_maintenance_overseen_by')->nullable();
            $table->string('interior_maintenance_overseen_date')->nullable();
            $table->string('material_designated', 3)->nullable();
            $table->string('no_exterior_holes', 3)->nullable();
            $table->string('no_holes', 3)->nullable();
            $table->string('no_pipes', 3)->nullable();
            $table->string('shatterproof', 3)->nullable();
            $table->integer('building_type');
            $table->integer('storage_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('storage_id')
              ->references('id')
              ->on('entities_name')
              ->onUpdate('cascade')
              ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_g');
    }
}
