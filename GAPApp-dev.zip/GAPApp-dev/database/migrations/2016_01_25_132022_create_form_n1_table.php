<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormN1Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_n1', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('water_source');
            $table->string('chlorine_added');
            $table->string('chlorine_concentration');
            $table->string('contact_time');
            $table->string('method');
            $table->string('post_treatment');
            $table->string('pre_treatment');
            $table->string('volume');
            $table->string('water_ph');
            $table->boolean('recirculated_water')->default(false);
            $table->boolean('water_changed')->default(false);
            $table->integer('user_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_n1');
    }
}
