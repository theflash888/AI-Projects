<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormN2Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_n2', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('water_source');
            $table->integer('method');
            $table->string('product');
            $table->integer('month')->unsigned();
            $table->string('temp_type', 1);
            $table->integer('water_temp');
            $table->integer('product_temp');
            $table->integer('difference');
            $table->string('action_taken');
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->string('method_other')->nullable();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_n2');
    }
}
