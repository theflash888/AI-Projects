<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormCTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_c', function (Blueprint $table) {
            $table->increments('id');
            $table->string('aprons_rubber');
            $table->string('aprons_used');
            $table->string('employee_adhere');
            $table->string('employee_aprons');
            $table->string('employees_aware');
            $table->string('employees_trained');
            $table->string('gloves_aprons');
            $table->string('gloves_removed');
            $table->string('gloves_rubber');
            $table->string('gloves_substitute');
            $table->string('gloves_used');
            $table->string('hands_reusable_gloves');
            $table->string('hands_washed');
            $table->string('hands_washed_dried');
            $table->string('major_minor');
            $table->string('no_water');
            $table->string('person_responsible');
            $table->string('person_responsible_name')->nullable();
            $table->string('person_transmit');
            $table->string('reusable_aprons');
            $table->string('reusable_gloves_washed');
            $table->string('trained_fallen');
            $table->string('trained_harvest');
            $table->string('trained_precautions');
            $table->string('trained_touched');
            $table->string('trained_visually');
            $table->string('wipe_hand_sanitizer');
            $table->string('wounds_treated');
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->string('date');
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_c');
    }
}
