<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormDTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_d', function (Blueprint $table) {
            $table->increments('id');
            $table->string('aprons_rubber');
            $table->string('aprons_used');
            $table->string('clean_footwear');
            $table->string('employee_adhere');
            $table->string('employee_aprons');
            $table->string('employee_authorized');
            $table->string('employees_aware');
            $table->string('employees_trained');
            $table->string('false_fingernails');
            $table->string('gloves_aprons');
            $table->string('gloves_removed');
            $table->string('gloves_rubber');
            $table->string('gloves_substitute');
            $table->string('gloves_used');
            $table->string('hands_reusable_gloves');
            $table->string('hands_washed');
            $table->string('hands_washed_dried');
            $table->string('items_removed_pocket');
            $table->string('jewellery_worn');
            $table->string('long_hair_touching');
            $table->string('loose_buttons_fixed');
            $table->string('major_minor');
            $table->string('no_water');
            $table->string('person_responsible');
            $table->string('person_responsible_name')->nullable();
            $table->string('person_transmit');
            $table->string('personal_cleanliness');
            $table->string('personal_cleanliness_other')->nullable();
            $table->string('reusable_aprons');
            $table->string('ring_gloves');
            $table->string('trained_precautions');
            $table->string('wipe_hand_sanitizer');
            $table->string('wounds_treated');
            $table->integer('user_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_d');
    }
}
