<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormSTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_s', function (Blueprint $table) {
            $table->increments('id')->nullable();
            $table->string('cereals_1')->nullable();
            $table->string('cereals_2')->nullable();
            $table->string('cereals_3')->nullable();
            $table->string('cereals_4')->nullable();
            $table->string('cereals_5')->nullable();
            $table->text('comments')->nullable();
            $table->string('eggs_1')->nullable();
            $table->string('eggs_2')->nullable();
            $table->string('eggs_3')->nullable();
            $table->string('eggs_4')->nullable();
            $table->string('eggs_5')->nullable();
            $table->string('fish_1')->nullable();
            $table->string('fish_2')->nullable();
            $table->string('fish_3')->nullable();
            $table->string('fish_4')->nullable();
            $table->string('fish_5')->nullable();
            $table->string('milk_1')->nullable();
            $table->string('milk_2')->nullable();
            $table->string('milk_3')->nullable();
            $table->string('milk_4')->nullable();
            $table->string('milk_5')->nullable();
            $table->text('others_1')->nullable();
            $table->text('others_2')->nullable();
            $table->text('others_3')->nullable();
            $table->text('others_4')->nullable();
            $table->text('others_5')->nullable();
            $table->string('peanut_1')->nullable();
            $table->string('peanut_2')->nullable();
            $table->string('peanut_3')->nullable();
            $table->string('peanut_4')->nullable();
            $table->string('peanut_5')->nullable();
            $table->string('sesame_1')->nullable();
            $table->string('sesame_2')->nullable();
            $table->string('sesame_3')->nullable();
            $table->string('sesame_4')->nullable();
            $table->string('sesame_5')->nullable();
            $table->string('shellfish_molluscs_1')->nullable();
            $table->string('shellfish_molluscs_2')->nullable();
            $table->string('shellfish_molluscs_3')->nullable();
            $table->string('shellfish_molluscs_4')->nullable();
            $table->string('shellfish_molluscs_5')->nullable();
            $table->string('soybeans_1')->nullable();
            $table->string('soybeans_2')->nullable();
            $table->string('soybeans_3')->nullable();
            $table->string('soybeans_4')->nullable();
            $table->string('soybeans_5')->nullable();
            $table->string('storage')->nullable();
            $table->string('sulphites_1')->nullable();
            $table->string('sulphites_2')->nullable();
            $table->string('sulphites_3')->nullable();
            $table->string('sulphites_4')->nullable();
            $table->string('sulphites_5')->nullable();
            $table->string('tree_nuts_1')->nullable();
            $table->string('tree_nuts_2')->nullable();
            $table->string('tree_nuts_3')->nullable();
            $table->string('tree_nuts_4')->nullable();
            $table->string('tree_nuts_5')->nullable();
            $table->integer('storage_id')->unsigned();
            $table->string('mustard_1')->nullable();
            $table->string('mustard_2')->nullable();
            $table->string('mustard_3')->nullable();
            $table->string('mustard_4')->nullable();
            $table->string('mustard_5')->nullable();
            $table->integer('user_id')->unsigned();
            $table->integer('organization_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade')->nullable();

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade')->nullable();

            $table->foreign('storage_id')
                ->references('id')
                ->on('entities_name')
                ->onUpdate('cascade')
                ->onDelete('cascade')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_s')->nullable();
    }
}
