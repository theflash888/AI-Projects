<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormH2Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_h2', function(Blueprint $table) {
            $table->increments('id');
            $table->string('blend');
            $table->string('commercial_rate');
            $table->string('current_crop');
            $table->string('date_planted');
            $table->string('fertilizer_lot_num');
            $table->string('manure_rate');
            $table->string('operation_name');
            $table->string('previous_year_crops');
            $table->integer('product_site_information')->unsigned();
            $table->string('production_site_area');
            $table->string('seed_certificate');
            $table->string('supplier_name');
            $table->string('type');
            $table->string('variety');
            $table->string('what_is_applied');
            $table->string('earliest_harvest_date');
            $table->integer('organization_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('product_site_information')
              ->references('id')
              ->on('entities_name')
              ->onUpdate('cascade')
              ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_h2');
    }
}
