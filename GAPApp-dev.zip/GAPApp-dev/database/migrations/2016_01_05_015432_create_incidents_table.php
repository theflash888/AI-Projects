<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIncidentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('incidents', function (Blueprint $table) {
            $table->increments('id');
            $table->string('date', 10);
            $table->string('time', 5);
            $table->text('description');
            $table->text('cause_deviation');
            $table->text('corrective_action');
            $table->text('prevention_recurrence')->nullable();
            $table->text('modified_procedure')->nullable();
            $table->boolean('is_trained')->default(false);
            $table->integer('form_id')->unsigned();
            $table->boolean('resolved')->default(false);
            $table->integer('organization_id')->unsigned();
            $table->integer('deviation_type');
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });

        /*Schema::create('incident_user', function(Blueprint $table) {
            $table->integer('incident_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('incident_id')->references('id')
                ->on('incidents')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });*/
        Schema::create('incident_images', function(Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('mime', 255);
            $table->string('filename', 255);
            $table->bigInteger('size')->unsigned();
            $table->string('storage_path')->unique();
            $table->string('disk', 10);
            $table->boolean('status');
            $table->integer('incident_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('incident_id')->references('id')
                ->on('incidents')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('user_id')->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('incidents');
        Schema::dropIfExists('incident_images');
    }
}
