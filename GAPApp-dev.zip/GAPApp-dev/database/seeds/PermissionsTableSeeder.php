<?php

use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('permissions')->insert([
          'name' => 'org_admin',
          'display_name' => 'Organization Admin'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_A',
          'display_name' => 'Form A. Buildings Sketch (Interior Floor Plan) and Agricultural Chemical Storage Checklist'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_B',
          'display_name' => 'Form B. Storage Assessment'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_C',
          'display_name' => 'Form C. Employee Personal Hygiene and Food Handling Practices Policy - Production Site'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_D',
          'display_name' => 'Form D. Employee Personal Hygiene and Food Handling Practices Policy - Packinghouse/Product Storage'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_E',
          'display_name' => 'Form E. Pest Control Program for Buildings'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_F',
          'display_name' => 'Form F. Water (for Fluming and Cleaning) Assessment'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_G',
          'display_name' => 'Form G. Cleaning, Maintenance and Repair of Buildings'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_H1',
          'display_name' => 'Form H1. Agronomic Inputs (Agricultural Chemicals)'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_H2',
          'display_name' => 'Form H2. Agronomic Inputs (Other)'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_H3',
          'display_name' => 'Form H3. Agricultural Chemical Application (During Packing)'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_I',
          'display_name' => 'Form I. Equipment Cleaning, Maintenance and Calibration'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_J',
          'display_name' => 'Form J. Cleaning and Maintenance - Personal Hygiene Facilities'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_K',
          'display_name' => 'Form K. Training Session'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_L',
          'display_name' => 'Form L. Visitor Sign-In Log'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_M',
          'display_name' => 'Form M. Pest Monitoring for Buildings'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_N1',
          'display_name' => 'Form N1. Water Treatment Control and Monitoring'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_N2',
          'display_name' => 'Form N2. Water Temperature Control and Monitoring'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_O',
          'display_name' => 'Form O. Transporting Product'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_P1',
          'display_name' => 'Form P1. Harvesting and Storing Product (FOR POTATOES ONLY)'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_P2',
          'display_name' => 'Form P2. Harvesting and Storing Product (FOR ALL COMMODITIES EXCEPT POTATOES)'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_Q',
          'display_name' => 'Form Q. Packing, Repacking, Storing and Brokerage of Market Product'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_R',
          'display_name' => 'Form R. Major Deviations and Corrective Actions'
        ]);
        DB::table('permissions')->insert([
          'name' => 'form_R2',
          'display_name' => 'Form R2. Minor Deviations and Corrective Actions'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_S',
          'display_name' => 'Form S. Allergen Information – Assessment'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'form_T',
          'display_name' => 'Form T. Food Defence'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'audits',
          'display_name' => 'Audits'
        ]);
        DB::table('permissions')->insert([
        	'name' => 'incidents',
          'display_name' => 'Incidents'
        ]);
    }
}
