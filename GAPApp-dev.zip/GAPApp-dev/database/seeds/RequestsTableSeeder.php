<?php

use Illuminate\Database\Seeder;

class RequestsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('requests')->insert([
        	'id' => str_random(10),
        	'org_name' => 'Organization 1',
        	'org_type' => 'Both',
        	'org_first_name' => 'Priyank',
        	'org_last_name' => 'Patel',
        	'org_audit_company' => 'Audit company 1',
        	'org_audit_cycle' => 'September',
        	'org_fns_coordinator' => 'John Doe',
        	'contact_email' => 'app@gapapp.ca'
        ]);
    }
}
