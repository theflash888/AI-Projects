<?php

use Illuminate\Database\Seeder;

class OrganizationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('organizations')->insert([
        	'name' => 'Durham Foods',
          'logo' => '0878726437.png',
        	'type' => 'vegetable',
        	'person_responsible' => 'Priyank Patel',
        	'audit_company' => 'Audit Company #1',
        	'audit_cycle' => 'Tuesday',
        	'coordinator' => 'Silent Coder',
 			    'active' => true,
 			    'approved' => true
        ]);

        DB::table('organizations')->insert([
        	'name' => 'Ontario Foods',
          'logo' => '1198830803.jpg',
        	'type' => 'both',
        	'person_responsible' => 'Priyank Patel',
        	'audit_company' => 'Audit Company #1',
        	'audit_cycle' => 'Tuesday',
        	'coordinator' => 'Silent Coder',
 			    'active' => false,
 			    'approved' => false
        ]);
    }
}
