<?php

use Illuminate\Database\Seeder;

class EntitiesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('entities_type')->insert([
        	"type" => "Building Name",
        	"description" => ""
        ]);

        DB::table('entities_type')->insert([
        	"type" => "Water Source",
        	"description" => ""
        ]);

        DB::table('entities_type')->insert([
        	"type" => "Storage ID",
        	"description" => ""
        ]);

        DB::table('entities_type')->insert([
        	"type" => "Hygiene Facility Type and Location",
        	"description" => ""
        ]);
    }
}
