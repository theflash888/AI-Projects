<?php

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
        	'email'	=>	'jim@gapapp.ca',
        	'password'	=>	bcrypt('gapapp'),
            'first' => 'Jim',
            'last' => 'Sheehan',
            'activated' => '1',
            'verified' => '1',
            'organization_id' => 1
        ]);

        DB::table('users')->insert([
            'email' =>  'priyank.patel@uoit.net',
            'password'  =>  bcrypt('priyank'),
            'first' => 'Silent',
            'last' => 'Coder',
            'activated' => true,
            'verified' => true,
            'organization_id' => 1
        ]);

        DB::table('users')->insert([
            'email' =>  'john.doe@uoit.net',
            'password'  =>  bcrypt('priyank'),
            'first' => 'John',
            'last' => 'Doe',
            'organization_id' => 2
        ]);

        DB::table('users')->insert([
            'email' =>  'joe.monroe@uoit.net',
            'password'  =>  bcrypt('priyank'),
            'first' => 'Joe',
            'last' => 'Monroe',
            'activated' => true,
            'verified' => true,
            'organization_id' => 2
        ]);

        DB::table('organization_user')->insert([
            'organization_id' => '1',
            'user_id' => '1'
        ]);

        DB::table('organization_user')->insert([
            'organization_id' => '1',
            'user_id' => '2'
        ]);

        DB::table('organization_user')->insert([
            'organization_id' => '2',
            'user_id' => '3'
        ]);

        DB::table('organization_user')->insert([
            'organization_id' => '2',
            'user_id' => '4'
        ]);
    }
}
