<?php

use Illuminate\Database\Seeder;

class FormsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('forms')->insert([
        	'form' => 'A',
        	'title' => 'Buildings Sketch (Interior Floor Plan) and Agricultural Chemical Storage Checklist',
        	'period' => 'ANNUAL',
          'version' => '6.3'
        ]);

        DB::table('forms')->insert([
        	'form' => 'B',
        	'title' => 'Storage Assessment',
        	'period' => 'ANNUAL',
          'version' => '6.3'
        ]);

        DB::table('forms')->insert([
        	'form' => 'C',
        	'title' => 'Employee Personal Hygiene and Food Handling Practices Policy - Production Site',
        	'period' => 'ANNUAL',
          'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'D',
            'title' => 'Employee Personal Hygiene and Food Handling Practices Policy - Packinghouse/Product Storage',
            'period' => 'ANNUAL',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'E',
            'title' => 'Pest Control Program for Buildings',
            'period' => 'ANNUAL',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'F',
            'title' => 'Water (for Fluming and Cleaning) Assessment',
            'period' => 'ANNUAL',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'G',
            'title' => 'Cleaning, Maintenance and Repair of Buildings',
            'period' => 'MONTHLY',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'H1',
            'title' => 'Agronomic Inputs (Agricultural Chemicals)',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'H2',
            'title' => 'Agronomic Inputs (Other)',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'H3',
            'title' => 'Agricultural Chemical Application (During Packing)',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'I',
            'title' => 'Equipment Cleaning, Maintenance and Calibration',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'J',
            'title' => 'Cleaning and Maintenance - Personal Hygiene Facilities',
            'period' => 'WEEKLY/DAILY',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'K',
            'title' => 'Training Session',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'L',
            'title' => 'Visitor Sign-In Log',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'M',
            'title' => 'Pest Monitoring for Buildings',
            'period' => 'MONTHLY',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'N1',
            'title' => 'Water Treatment Control and Monitoring',
            'period' => 'DAILY',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'N2',
            'title' => 'Water Temperature Control and Monitoring',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'O',
            'title' => 'Transporting Product',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'P1',
            'title' => 'Harvesting and Storing Product (FOR POTATOES ONLY)',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'P2',
            'title' => 'Harvesting and Storing Product (FOR ALL COMMODITIES EXCEPT POTATOES)',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'Q',
            'title' => 'Packing, Repacking, Storing and Brokerage of Market Product',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'R',
            'title' => 'Deviations and Corrective Actions',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'R2',
            'title' => 'Minor Deviations and Corrective Actions',
            'period' => 'ONGOING',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'S',
            'title' => 'Allergen Information – Assessment',
            'period' => 'ANNUAL',
            'version' => '6.3'
        ]);

        DB::table('forms')->insert([
            'form' => 'T',
            'title' => 'Food Defence',
            'period' => 'ANNUAL',
            'version' => '6.3'
        ]);
    }
}
