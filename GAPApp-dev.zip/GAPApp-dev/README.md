### GAPApp Full Stack Development
---

#### TODO 
- [ ] GAPApp Logo
- [x] Organization Logo on Login
- [ ] Calendar
- [ ] Verify Mail Server
- [ ] Improve Incidents / Form R
- [ ] Settings
- [ ] Forms
- [ ] Picture compression
- [ ] Initial Setup Page
      - Go through each form
      - Edit permissions and roles
      - Default Roles/Modify Access
      - Next Audit or expected Audit
- [ ] Various Packages on Requests
- [ ] Vertical side menu background to (dark brown)
- [ ] Limit resolution for uploads
- [ ] Summary in PDF form
- [ ] List of Auditors
- [ ] Entities
      - Organizations creation
- [ ] Arial Font
- [ ] Required: yellow\Error: red
- [ ] Accordian
- Form A
      - Checklist
- Form C
      - 2 Checkbox/1 Radio button
      - Tooltip
- Form E
      - Add multiple chemicals
- Form J
      - Excerpt header/add tooltip
- Form K
      - Description 
- Incidents for all Form
- Audit Form
      - Go back
- Compromise the popup
- ****[ ] Need to show how it was resolved
- ****[ ] Being able to see the description fully, either pop-up or hover over
            - Details --> new page --> then SAVE/RESOLVE
            - Only Manager can resolve the incident
                  - Rolename: Organization Manager
            - Incident Resolved = completely gone
            - Organized by oldest first
- ****[ ] Show reports for ALL the incidents that have taken place
      - Will be shown as a PDF
      - Only the unresolved incidents will be displayed
- ****[ ] LOGO: Durham Foods
- ****[ ] Colours: Brown, Green, Light Colours
            - 
- ****[ ] Activate vs. Inactivate
            - Make it a AngularJS Switch (Active, Inactive)
- [ ] Roles & Permissions
- [ ] Compile list of Forms
- [ ] Remove the entity type, keep entity names
      - Run Test
- ****[ ] Once they make a record (Form B), cannot go back and edit anything (also for YES/NO)
            - Fix the saving feature of Yes/No
                  - Is not showing saved Yes/No when clicking Details
            - Add N/A button
                  - Add new colouring for the N/A button
                  - Make sure it is updated in the database
            - If it is a "No" allow the user to create an incident?
- ****[ ] Make Incident Button on every Form
            - Make a Description box for all Forms where an incident can be created
            - Format may be adjusted for each time No is selected
- [ ] Logged in, add the author of the account, pre-fill the places where its signed off
- ****[ ] Reports for 1 or 2 forms for Fridays meeting
- Send link for: Team Viewer & Colour Picker

Form B:

- hit Form B, code appears, get rid of it.
- save record -> should tell you where the mistake is
	- for example is something is not done
- not saving properly in Form B
- Wants the page to save and auto refresh

Form C:
- Any reason we have to pick NO, incident pop-ups

Reports:
**- must look similar to the format of the 
actual form (WED)
- pick a form and date range -> give you all filled out ones
-> then pick the specific one you're looking for

*Get rid of the +, make it words (Add record, create record)*
- auto populate the time and date
- Form "x" is not working, only works to clicking out

Form J:

- Fill in the record, thats a good experience, change the + to words
- "New Record for Form J" -> need a way to create an incident
- Change the way you fill, like live on the form bc you need have incidents
- Checks and exes are not working properly

N2:

- Water Source, is it a well, a city, a pond, etc.
- Auto check the difference, range between the temperatures
- Drop down for Farenheit and Celcius

O:

- Show whose actually loading

Photos:

- Take a picture from that point and tag it to the date and time

Dashboard:

- Summaries

Colour:

- Update on Tuesday
