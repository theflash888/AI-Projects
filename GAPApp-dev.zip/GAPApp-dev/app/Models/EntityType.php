<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EntityType extends Model
{
    protected $table = "entities_type";

    public function names()
    {
    	return $this->belongsTo('App\Models\EntityName');
    }
}
