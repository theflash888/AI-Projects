<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormT extends Model
{
    protected $table = "form_t";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }
}
