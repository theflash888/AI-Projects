<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormS extends Model
{
    protected $table = "form_s";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function production()
    {
        return $this->belongsTo('App\Models\EntityName', 'storage_id', 'id');
    }
}
