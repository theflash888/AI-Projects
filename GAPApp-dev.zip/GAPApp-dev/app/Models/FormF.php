<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormF extends Model
{
    protected $table = "form_f";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }
}
