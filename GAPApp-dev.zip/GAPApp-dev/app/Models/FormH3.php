<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormH3 extends Model
{
    protected $table = "form_h3";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function production()
    {
        return $this->belongsTo('App\Models\EntityName', 'production_site', 'id');
    }
}
