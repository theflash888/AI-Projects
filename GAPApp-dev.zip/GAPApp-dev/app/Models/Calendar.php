<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Calendar extends Model
{
    protected $table = 'calendar';

    public function organization() 
    {
        return $this->belongsTo('App\Models\Organizations', 'id');
    }

    public function user() {
    	return $this->belongsTo('App\Models\User', 'id');
    }
}
