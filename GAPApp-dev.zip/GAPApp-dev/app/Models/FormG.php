<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormG extends Model
{
    protected $table = "form_g";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function storage()
    {
        return $this->belongsTo('App\Models\EntityName', 'storage_id', 'id');
    }
}
