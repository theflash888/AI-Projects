<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Zizaco\Entrust\Traits\EntrustRoleTrait;

class Organization extends Model
{
    use EntrustRoleTrait;

    protected $table = "organizations";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'type', 'person_responsible', 'audit_company', 'audit_cycle', 'coordinator', 'active', 'approved'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [

    ];

    public function users()
    {
        return $this->hasMany('App\User');
    }

    public function incidents()
    {
        return $this->hasMany('App\Models\Incident')->orderBy('created_at', 'DESC');
    }

    public function calendars()
    {
        return $this->hasMany('App\Models\Calendar', 'organizations_id');
    }

    public function forms_b()
    {
        return $this->hasMany('App\Models\FormB')->orderBy('created_at', 'DESC');
    }

    public function forms_c()
    {
        return $this->hasMany('App\Models\FormC')->orderBy('created_at', 'DESC');
    }

    public function forms_i()
    {
        return $this->hasMany('App\Models\FormI')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_j()
    {
        return $this->hasMany('App\Models\FormJ')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_k()
    {
        return $this->hasMany('App\Models\FormK')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_L()
    {
        return $this->hasMany('App\Models\FormL')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_t()
    {
        return $this->hasMany('App\Models\FormT')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_m()
    {
      return $this->hasMany('App\Models\FormM')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_n1()
    {
      return $this->hasMany('App\Models\FormN1')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_n2()
    {
        return $this->hasMany('App\Models\FormN2')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_h3()
    {
        return $this->hasMany('App\Models\FormH3')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_r()
    {
        return $this->hasMany('App\Models\FormR')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_g()
    {
        return $this->hasMany('App\Models\FormG')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_d()
    {
        return $this->hasMany('App\Models\FormD')->orderBy('created_at', 'DESC');
    }

    public function forms_h1()
    {
        return $this->hasMany('App\Models\FormH1')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_h2()
    {
        return $this->hasMany('App\Models\FormH2')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_p2()
    {
        return $this->hasMany('App\Models\FormP2')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_f()
    {
        return $this->hasMany('App\Models\FormF')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_o()
    {
        return $this->hasMany('App\Models\FormO')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_q()
    {
        return $this->hasMany('App\Models\FormQ')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_s()
    {
        return $this->hasMany('App\Models\FormS')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_e()
    {
        return $this->hasMany('App\Models\FormE')->orderBy('created_at', 'DESC');
    }

    public function forms_p1()
    {
        return $this->hasMany('App\Models\FormP1')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function forms_a()
    {
        return $this->hasMany('App\Models\FormA')->orderBy('created_at', 'DESC');
    }

    public function forms_r2()
    {
        return $this->hasMany('App\Models\FormR2')->orderBy('created_at', 'DESC')->where('is_completed', false);
    }

    public function entities_name()
    {
        return $this->hasMany('App\Models\EntityName');
    }

    public function audit()
    {
        return $this->hasMany('App\Models\Audit')->orderBy('created_at', 'DESC');
    }

    public function role() {
        return $this->hasMany('App\Models\Role');
    }
}
