<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Incident extends Model
{
	protected $table = "incidents";

    //protected $with = ['users'];
	
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'date', 'time', 'description', 'form', 'resolved', 'user_id', 'organization_id'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        
    ];

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function images()
    {
        return $this->hasMany('App\Models\Image');
    }

    public function comments()
    {
        return $this->hasMany('App\Models\Comment');
    }

    public function form()
    {
        return $this->belongsTo('App\Models\FormList');
    }

    public function logs() 
    {
        return $this->hasMAny('App\Models\IncidentsLog')->orderBy('created_at', 'DESC');
    }
}
