<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EntityName extends Model
{
    protected $table = "entities_name";

}
