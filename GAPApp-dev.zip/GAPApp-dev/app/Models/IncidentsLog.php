<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IncidentsLog extends Model
{
    protected $table = "incidents_log";

    public function user()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function incident()
    {
        return $this->belongsTo('App\Incident', 'incident_id', 'id');
    }
}
