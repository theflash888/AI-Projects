<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Audit extends Model
{
	protected $casts = [
        'audit_data' => 'array', // Will convarted to (Array)
    ];

    protected $table = "audits";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }
}
