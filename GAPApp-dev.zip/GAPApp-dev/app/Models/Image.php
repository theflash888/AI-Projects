<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
	protected $table = "incident_images";

    //protected $with = ['users'];
	
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['mime', 'storage_path', 'status', 'filename', 'size', 'disk'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        
    ];

    public function incident()
    {
        return $this->belongsTo('App\Incident', 'incident_id', 'id');
    }
}
