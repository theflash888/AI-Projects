@extends('dashboard.home')

@section('dashboard-content')
	<div class="row animated fadeIn align-justify">
		<div class="large-4 columns DBTitle">
			<h1><i class="bi_user-single-a-group"></i> Organizations</h1>
		</div>
		<div class="large-5 columns DBTitle">
			<div class="Admin-Stats">
				<h3>{{ \App\Models\Organization::where('active', 1)->count() }}</h3>
				<a href="{{ url('/dashboard/administrator/organizations#OrganizationList') }}">Organizations</a>
			</div>
			<div class="Admin-Stats">
				<h3>{{ \App\Models\Requests::count() }}</h3>
				<a href="{{ url('/dashboard/administrator/organizations#PendingApproval') }}">Pending Approval</a>
			</div>
		</div>
	</div>
	<div class="row" id="OrganizationList">
		<div class="large-12 columns IncidentsTable">
			<div class="row align-justify IncidentsTable-Header">
				<div class="large-4 columns">
					<h3>List of Organizations</h3>
				</div>
				<div class="large-2 columns">
					<a class="ViewMoreLink" href=""><i class="bi_interface-plus"></i> View All</a>
				</div>
			</div>
			<div class="row">
				<table>
					<thead>
						<tr>
							<th>Name</th>
							<th>Type</th>
							<th>Responsible</th>
							<th>Audit Company</th>
							<th>F&S Coordinator</th>
							<th>More</th>
						</tr>
					</thead>
					<tbody>
						@foreach(\App\Models\Organization::where('active', 1)->get() as $org)
						<tr>
							<td>{{ $org->name }}</td>
							<td>{{ $org->type }}</td>
							<td>{{ $org->person_responsible }}</td>
							<td>{{ $org->audit_company }}</td>
							<td>{{ $org->coordinator }}</td>
							<td><md-button ng-href="{{ url('/dashboard/administrator/organization/' . $org->id) }}">Details</md-button></td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="row" id="PendingApproval">
		<div class="large-12 columns IncidentsTable">
			<div class="row align-justify IncidentsTable-Header">
				<div class="large-4 columns">
					<h3>Pending Approvals</h3>
				</div>
				<div class="large-2 columns">
					<a class="ViewMoreLink" href=""><i class="bi_interface-plus"></i> View All</a>
				</div>
			</div>
			<div class="row">
				<table>
					<thead>
						<tr>
							<th>Name</th>
							<th>Type</th>
							<th>Responsible</th>
							<th>Audit Company</th>
							<th>F&S Coordinator</th>
							<th>More</th>
						</tr>
					</thead>
					<tbody>
						@foreach(\App\Models\Requests::get() as $org)
						<tr>
							<td>{{ $org->org_name }}</td>
							<td>{{ $org->org_type }}</td>
							<td>{{ $org->org_first_name . ' ' . $org->org_last_name }}</td>
							<td>{{ $org->org_audit_company }}</td>
							<td>{{ $org->org_fns_coordinator }}</td>
							<td><md-button ng-href="{{ url('/dashboard/administrator/organization/request/' . $org->token) }}">Details</md-button></td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
@stop
