<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormFWaterTests extends Model
{
    protected $table = "form_f_water_tests";

    public function author()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function formF()
    {
    	return $this->belongsTo('App\FormF', 'form_f_id', 'id');
    }
}
