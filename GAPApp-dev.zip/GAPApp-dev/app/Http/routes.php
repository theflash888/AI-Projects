<?php


use App\Models\Role;
use App\Models\Permission;
use App\User;
use Symfony\Component\Validator\ValidatorInterface;


/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/permissions', function () {
	$superAdmin = new Role();
	$superAdmin->name 		=	'superadmin';
	$superAdmin->display_name	=	'Mafam Platform Administrator';
	$superAdmin->description 	=	'Administrator of the Mafam Platform';
	$superAdmin->organization_id = 1;
	$superAdmin->save();

	$orgAdmin = new Role();
	$orgAdmin->name 			=	'orgadmin';
	$orgAdmin->display_name 	=	'Organization Admin';
	$orgAdmin->description 		=	'Administrator of the organization';
	$orgAdmin->organization_id = 1;
	$orgAdmin->save();

	$user = User::where('email', '=', 'jim@gapapp.ca')->first();
	$user->attachRole($superAdmin);
	$user->attachRole($orgAdmin);
	//$user->roles()->attach($superAdmin->id);

	$addOrganization = new Permission();
	$addOrganization->name 			=	'create-organization';
	$addOrganization->display_name	=	'Create Organizations';
	$addOrganization->description 	=	'Create new organizations';
	$addOrganization->save();

	$superAdmin->attachPermission($addOrganization);
});

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::get('pass', function () {
	return Hash::make('gapapp');
});

Route::group(['middleware' => ['web', 'csrf']], function () {
	Route::get('/', function () {
	    //return view('welcome');
	    $org = App\Models\Organization::find(1);
	    echo "<pre>";
		print_r(Auth::user());
	});

	Route::get('/request', function () {
		return view('organizations/request');
	});

	Route::group(['prefix' => 'serviceLogin'], function () {
		Route::get('/', [function () {
			if(Auth::check())
				return redirect()->intended('dashboard');
			else
				return view('auth/login');
		}]);

		Route::get('/logout', [function () {
			if(Auth::check()) {
				Auth::logout();
				return redirect()->intended('serviceLogin');
			}
		}]);
	});

	Route::get('/signup/{token}', function ($token) {
		return view('organizations.signup', ['token' => $token]);
	});

	Route::get('/validate/{token}/{email}', ['uses' => 'Auth\LoginController@verifyEmail']);

	Route::group(['prefix' => 'dashboard', 'middleware' => 'auth'], function () {
		Route::get('/', function () {
			return view('dashboard/main/home');
		});

		Route::get('/administrator', ['middleware' => ['role:superadmin'], function () {
			return view('dashboard/administrator/administrator');
		}]);

		Route::get('/administrator/announcements', ['middleware' => ['role:superadmin'], function () {
			return view('dashboard/administrator/announcements');
		}]);

		Route::get('/administrator/organizations', ['middleware' => ['role:superadmin'], function () {
			return view('dashboard/administrator/organizations');
		}]);

		Route::get('/administrator/organization/{id}', ['middleware' => ['role:superadmin'], 'uses' => 'AdministratorController@organizationDetails']);
		Route::get('/administrator/organization/request/{id}', ['middleware' => ['role:superadmin'], 'uses' => 'AdministratorController@requestDetails']);

		Route::get('/incidents', function () {
			if(Entrust::can('incidents')) {
					return view('dashboard/incidents/home');
			} else {
					return redirect('/dashboard');
			}
		});

		Route::get('/incidents/details/{id}', function ($id) {
			if(Entrust::can('incidents'))
					return view('dashboard/incidents/details', ['incident' => App\Models\Incident::find($id)]);
			else
					return redirect('/dashboard');
		});

		Route::get('/incidents/new', function () {
			if(Entrust::can('incidents'))
					return view('dashboard/incidents/new');
			else
					return redirect('/dashboard');
		});

		Route::get('/audits', function () {
			if(Entrust::can('audits'))
					return view('dashboard/audits/home');
			else
					return redirect('/dashboard');
		});

		Route::get('/audits/new', function () {
			if(Entrust::can('audits'))
					return view('dashboard/audits/new');
			else
					return redirect('/dashboard');
		});

		Route::get('/report/{form?}/{startDate?}/{endDate?}', function ($form = null, $startDate = null, $endDate = null) {
			Blade::extend(function($value) {
			    return preg_replace('/\{\?(.+)\?\}/', '<?php ${1} ?>', $value);
			});
			return view('dashboard/reports/home', ['form' => $form, 'startDate' => $startDate, 'endDate' => $endDate]);
		});

		Route::get('/form/R/{id}', function ($id) {
			$form_r = \App\Models\FormR::where('id', $id)->first();
			return view('dashboard.form_templates.form_R_details', ['form_r' => $form_r]);
		});

		Route::get('/report/{form}/{startDate}/{endDate}/download', function ($form, $startDate, $endDate) {
			$pdf = PDF::loadView('dashboard.reports.templates.form_' . $form, ['form' => $form, 'startDate' => $startDate, 'endDate' => $endDate]);
			if($form == 'R' || $form == 'F' || $form == 'H1' || $form == 'H2' || $form == 'H3' || $form == 'P1' || $form == 'Q')
				$pdf->setPaper('a4', 'landscape');
			return $pdf->download('Form ' . $form . ' : ' . \App\Models\FormList::where('form', $form)->first()->title . '.pdf');
		});

		Route::get('/calendar', function () {
			return view('dashboard/calendar/home');
		});

		Route::get('/form/{form?}', function ($form = null) {
			//$displayForm = (empty($form)) ? false : true;
				if($form != null) {
					if(Entrust::can('form_' . $form))
							return view('dashboard/forms/home', ['form' => $form]);
					else {
							return redirect('/dashboard/form');
					}
				} else {
					return view('dashboard/forms/home', ['form' => $form]);
				}

		});

		Route::get('/settings', function () {
			return view('dashboard/settings/home');
		});
	});

    Route::group(['prefix' => 'api'], function () {
    	Route::get('/user/me', 'Auth\LoginController@getLoggedInUser');
    	Route::post('/login/email/validate', 'Auth\LoginController@validateEmail');
    	Route::post('/login/credentials/validate', 'Auth\LoginController@validateLogin');
    	Route::post('/request/create', 'MailController@organizationRequest');
    	Route::post('/request/approved', 'MailController@sendApprovalEmail');
    	Route::post('/request/signup', 'MailController@sendValidationEmail');
    	Route::post('/get/calendar/events', 'CalendarController@listEvents');
    	Route::post('/new/calendar/events', 'CalendarController@newEvent');
    	Route::post('/login/organization/logo', 'Auth\LoginController@getOrganizationLogo');
    	Route::post('/settings/password/validate', 'SettingsController@changePassword');

    	Route::post('/new/incidents', 'IncidentsController@createNewIncidents');
    	Route::post('/new/incidents/comment', 'IncidentsController@addNewComment');
    	Route::post('/new/incidents/images', 'IncidentsController@uploadImages');
    	Route::post('/get/incidents/images', 'IncidentsController@getAllImages');
    	Route::post('/new/incident', 'IncidentsController@createNewIncident');
    	Route::post('/new/incident/quick', 'IncidentsController@createQuickIncident');

    	Route::get('/forms/lists', 'FormsController@getAllForms');

    	Route::post('/form_i/new/record', 'FormsController@createFormIRecord');
    	Route::post('/form_k/new/record', 'FormsController@createFormKRecord');
    	Route::post('/form_l/new/record', 'FormsController@createFormLRecord');
    	Route::post('/form_j/new/record', 'FormsController@createFormJRecord');
    	Route::post('/form_t/new/record', 'FormsController@createFormTRecord');
    	Route::post('/form_t/detail/record', 'FormsController@getFormTRecord');
    	Route::post('/form_t/save/record', 'FormsController@saveFormTRecord');
    	Route::post('/form_t/confirm/record', 'FormsController@confirmFormTRecord');

    	Route::post('/form_c/new/record', 'FormsController@createFormCRecord');
    	Route::post('/form_c/detail/record', 'FormsController@getFormCRecord');
    	Route::post('/form_c/save/record', 'FormsController@saveFormCRecord');
    	Route::post('/form_c/confirm/record', 'FormsController@confirmFormCRecord');

    		Route::post('/form_b/new/record', 'FormsController@createFormBRecord');
    		Route::post('/form_b/save/record', 'FormsController@saveFormBRecord');
			Route::post('/form_b/detail/record', 'FormsController@getFormBRecord');
			Route::post('/form_b/confirm/record', 'FormsController@confirmFormBRecord');

			Route::post('/entity/name/new', 'SettingsController@createNewEntityName');
			Route::post('/entity/name/list/all', 'SettingsController@getAllEntities');
			Route::post('/entity/name/list', 'SettingsController@getActiveEntities');
			Route::post('/entity/change/state', 'SettingsController@changEntityState');
			Route::post('/user/add', 'SettingsController@addNewUser');

			Route::post('/form_m/new/record', 'FormsController@createFormMRecord');
			Route::post('/form_n1/new/record', 'FormsController@createFormN1Record');
			Route::post('/form_n1/detail/record', 'FormsController@getFormN1Record');
			Route::post('/form_n1/save/record', 'FormsController@saveFormN1Record');
			Route::post('/form_n1/confirm/record', 'FormsController@confirmFormN1Record');

			Route::post('/form_n2/new/record', 'FormsController@createFormN2Record');
			Route::post('/form_n2/detail/record', 'FormsController@getFormN2Record');
			Route::post('/form_n2/save/record', 'FormsController@saveFormN2Record');
			Route::post('/form_n2/confirm/record', 'FormsController@confirmFormN2Record');

			Route::post('/form_o/new/record', 'FormsController@createFormORecord');
			Route::post('/form_o/detail/record', 'FormsController@getFormORecord');
			Route::post('/form_o/save/record', 'FormsController@saveFormORecord');
			Route::post('/form_o/confirm/record', 'FormsController@confirmFormORecord');

			Route::post('/form_h3/new/record', 'FormsController@createFormH3Record');
			Route::post('/form_h3/detail/record', 'FormsController@getFormH3Record');
			Route::post('/form_h3/save/record', 'FormsController@saveFormH3Record');
			Route::post('/form_h3/confirm/record', 'FormsController@confirmFormH3Record');

			Route::post('/form_g/new/record', 'FormsController@createFormGRecord');
			Route::post('/form_g/detail/record', 'FormsController@getFormGRecord');
			Route::post('/form_g/save/record', 'FormsController@saveFormGRecord');
			Route::post('/form_g/confirm/record', 'FormsController@confirmFormGRecord');

			Route::post('/form_h1/new/record', 'FormsController@createFormH1Record');
			Route::post('/form_h1/detail/record', 'FormsController@getFormH1Record');
			Route::post('/form_h1/save/record', 'FormsController@saveFormH1Record');
			Route::post('/form_h1/confirm/record', 'FormsController@confirmFormH1Record');

			Route::post('/form_h2/new/record', 'FormsController@createFormH2Record');
			Route::post('/form_h2/detail/record', 'FormsController@getFormH2Record');
			Route::post('/form_h2/save/record', 'FormsController@saveFormH2Record');
			Route::post('/form_h2/confirm/record', 'FormsController@confirmFormH2Record');

			Route::post('/form_p2/new/record', 'FormsController@createFormP2Record');
			Route::post('/form_p2/detail/record', 'FormsController@getFormP2Record');
			Route::post('/form_p2/save/record', 'FormsController@saveFormP2Record');
			Route::post('/form_p2/confirm/record', 'FormsController@confirmFormP2Record');

			Route::post('/form_f/new/record', 'FormsController@createFormFRecord');
			Route::post('/form_f/detail/record', 'FormsController@getFormFRecord');
			Route::post('/form_f/save/record', 'FormsController@saveFormFRecord');
			Route::post('/form_f/confirm/record', 'FormsController@confirmFormFRecord');

			Route::post('/form_r/new/record', 'FormsController@createFormRRecord');
			Route::post('/form_r/detail/record', 'FormsController@getFormRRecord');

			Route::post('/form_d/new/record', 'FormsController@createFormDRecord');
			Route::post('/form_d/detail/record', 'FormsController@getFormDRecord');
			Route::post('/form_d/save/record', 'FormsController@saveFormDRecord');
			Route::post('/form_d/confirm/record', 'FormsController@confirmFormDRecord');

			Route::post('/form_q/new/record', 'FormsController@createFormQRecord');
			Route::post('/form_q/detail/record', 'FormsController@getFormQRecord');
			Route::post('/form_q/save/record', 'FormsController@saveFormQRecord');
			Route::post('/form_q/confirm/record', 'FormsController@confirmFormQRecord');

			Route::post('/form_s/new/record', 'FormsController@createFormSRecord');
			Route::post('/form_s/detail/record', 'FormsController@getFormSRecord');
			Route::post('/form_s/save/record', 'FormsController@saveFormSRecord');
			Route::post('/form_s/confirm/record', 'FormsController@confirmFormSRecord');

			Route::post('/form_e/new/record', 'FormsController@createFormERecord');
			Route::post('/form_e/detail/record', 'FormsController@getFormERecord');
			Route::post('/form_e/save/record', 'FormsController@saveFormERecord');
			Route::post('/form_e/confirm/record', 'FormsController@confirmFormERecord');

			Route::post('/incident/get/record', 'IncidentsController@getIncidentInfo');

			Route::post('/form_r/resolve/record', 'FormsController@resolveFormRRecord');

			Route::post('/form_p1/new/record', 'FormsController@createFormP1Record');
			Route::post('/form_p1/detail/record', 'FormsController@getFormP1Record');
			Route::post('/form_p1/save/record', 'FormsController@saveFormP1Record');
			Route::post('/form_p1/confirm/record', 'FormsController@confirmFormP1Record');

			Route::post('/incident/deviation/change', 'FormsController@changeDeviationType');

			Route::post('/new/form_a/record', 'FormsController@createFormARecord');

			Route::post('/role/create', 'AdministratorController@createNewRole');
			Route::post('/role/list', 'AdministratorController@listRoles');

			Route::post('/permissions/list', 'AdministratorController@listPermissions');
			Route::post('/user/role', 'AdministratorController@getUserRoles');

			Route::post('/user/role/change', 'AdministratorController@changeUserRole');
			Route::post('/role/permission/change', 'AdministratorController@changePermissions');

			Route::post('/announcements/new', 'AdministratorController@createNewAnnouncement');
			Route::post('/announcements/list', 'AdministratorController@getAnnouncements');
			Route::post('/announcements/delete', 'AdministratorController@deleteAnnouncement');

			Route::post('/audit/new', 'AuditController@saveAudit');
			Route::post('/get/incident/data', 'IncidentsController@getIncidentInfo');
			Route::post('/edit/incident/data', 'IncidentsController@editIncidentInfo');
			Route::post('/new/incident/minor', 'IncidentsController@createMinorRRecord');
    });
});




Route::group(['middleware' => ['web']], function () {
	Route::group(['prefix' => 'v1'], function () {


		Route::post('oauth/access_token', function() {
			   return Response::json(Authorizer::issueAccessToken());
		});

		Route::group(['middleware' => 'oauth'], function () {
			Route::get('/user/me', 'Auth\LoginController@getLoggedInUser');
			Route::get('/user/organization', 'APIMainData@getOrganization');
			Route::get('/get/incidents', 'APIMainData@getAllIncidentLists');
			Route::get('/get/forms', 'APIMainData@getAllFormsList');
			
			/*function apiRequest($resource) {
				$app = require_once(__DIR__ . '/../Models/breeze.php');
				$app->enableCors();
				$results = array();
				//$manager = $app->getObjectManager();
				//array_merge($results, $manager->getRepository('\App\Entities\Incident')->findAll());
				$request = Request::instance();
				$request->attributes->set('resource', $resource);
				$response = $app->handle($request);
				//$response = $app->getSerializedResponse($manager->getRepository("\App\Entities\\" . $resource)->findAll(), $request);
    			$response->send();
			}

			Route::get('resource/{resourceName}', function ($resourceName) {
				return apiRequest($resourceName);
			});*/

			Route::get('/Metadata', function () {
				$app = require_once(__DIR__ . '/../Models/breeze.php');
				$manager = $app->getObjectManager();
				return $manager->getClassMetadata("App\Entities\Incidents");
			});
		});
	});
});

function apiRequest($resource) {
				$app = require_once(__DIR__ . '/../Models/breeze.php');
				$app->enableCors();
				/*$request->attributes->set('resource', 'SaveChanges');
				$response = $app->handle($request);
				var_dump($response);*/
				$results = array();
				//$manager = $app->getObjectManager();
				//array_merge($results, $manager->getRepository('\App\Entities\Incident')->findAll());
				$request = Request::instance();
				$request->attributes->set('resource', $resource);
				//$response = $app->handle($request);
				$response = $app->getSerializedResponse($manager->getRepository("\App\Entities\\" . $resource)->findAll(), $request);
    			$response->send();
			}

			Route::get('resource/{resourceName}', function ($resourceName) {
				return apiRequest($resourceName);
			});