<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\EntityName;

use Auth;
use Hash;
use DB;

class SettingsController extends Controller
{
    public function changePassword(Request $request) {
    	if(!$request->input('password') || !$request->input('newPassword') || !$request->input('repeatPassword')) {
    		$error = [
    			'code' => 401,
    			'message' => 'Missing one of the required fields'
    		];

    		return response()->json([
    			'error' => $error
    		], 401);
    	} else {
    		if(!Auth::attempt(['email' => Auth::user()->email, 'password' => $request->input('password')])) {
    			$error = [
    				'code' => 401,
    				'message' => 'Password does not match with the system!'
    			];

    			return response()->json([
		    		'error' => $error
		    	], 401);
    		} else {
    			if(!($request->input('newPassword') === $request->input('repeatPassword'))) {
    				$error = [
		    			'code' => 401,
		    			'message' => 'New password does not match!'
		    		];

		    		return response()->json([
		    			'error' => $error
		    		], 401);
    			} else {
    				$user = Auth::user();
    				$user->password = bcrypt($request->input('newPassword'));
    				$user->save();

    				$success = [
    					'code' => 200,
    					'message' => 'Password has been changed!'
    				];

    				return response()->json([
    					'success' => $success
    				], 200);
    			}
    		}
    	}
    }

    public function createNewEntityName(Request $request) {
        $en_check = \App\Models\EntityName::where('name', $request->input('name'))->count();

        if($en_check > 0) {
            $error = [
                'code' => 401,
                'message' => "Entity name already exists! Try new name!"
            ];

            return response()->json([
                'error' => $error
            ], 200);
        } else {
            $en = new \App\Models\EntityName();
            $en->name = $request->input('name');
            $org = \App\Models\Organization::find(Auth::user()->organizations()->first()->id);
            $org->entities_name()->save($en);

            $success = [
                'code' => 200,
                'description' => "New Entity Added"
            ];

            return response()->json([
                'success' => $success
            ], 200);
        }
    }

    public function getAllEntities()
    {
        $org = \App\Models\Organization::find(Auth::user()->organizations()->first()->id);
        return response()->json([
            'entities' => $org->entities_name
        ], 200);
    }

    public function getActiveEntities()
    {
        $org = \App\Models\Organization::find(Auth::user()->organizations()->first()->id);
        return response()->json([
            'entities' => $org->entities_name->where('active', '1')->all()
        ], 200);
    }

    public function changEntityState(Request $request)
    {
        $id = $request->input('id');
        $entity = \App\Models\EntityName::find($id);
        if($entity->active == true)
        {
            $entity->active = false;
            $entity->save();
        } else {
            $entity->active = true;
            $entity->save();
        }

        $success = [
            'code' => 200,
            'entity' => $entity->first()
        ];

        return response()->json([
            'success' => $success
        ], 200);

    }

    public function addNewUser(Request $request)
    {
        $check_email = \App\User::where('email', $request->input('email'))->count();

        if($check_email > 0)
        {
            $error = [
                'code' => 401,
                'message' => "Email Address already exists!"
            ];

            return response()->json([
                'error' => $error
          ], 200);
        } else {
            $pass = $request->input('password');
            $rpass = $request->input('repeat_password');

            if($pass == $rpass) {
                $user = new \App\User();
                $user->first = $request->input('firstname');
                $user->last = $request->input('lastname');
                $user->email = $request->input('email');
                $user->password = bcrypt($request->input('password'));
                $user->activation_code = str_random(20);
                $user->activated = false;
                $user->verified = false;

                $org = \App\Models\Organization::find(Auth::user()->organizations()->first()->id);
                $user->organization_id = $org->id;
                $org->users()->save($user);

                DB::table("role_user")->insert(['user_id' => $user->id, 'role_id' => $request->input('role_id')]);

                DB::table('organization_user')->insert(['organization_id' => $org->id, 'user_id' => $user->id]);

                $success = [
                    'code' => 200,
                    'message' => "New User " . $user->first . ' ' . $user->last . ' Added!'
                ];

                return response()->json([
                    'success' => $success
                ], 200);

            } else {
                $error = [
                    'code' => 401,
                    'message' => "Password do not match!"
                ];

                return response()->json([
                    'error' => $error
              ], 200);
            }
        }
    }
}
