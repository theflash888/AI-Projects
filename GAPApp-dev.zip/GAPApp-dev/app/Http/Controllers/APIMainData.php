<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Auth;
use App\Models\Incident;
use App\Models\FormList;
use Log;

class APIMainData extends Controller
{
    public function getOrganization() {
        return response()->json(['organization' => Auth::user()->organizations], 200);
    }

    public function getAllIncidentLists() {
        return response()->json(Incident::where('organization_id', '1')->where('resolved', 0)->orderBy('created_at', 'DESC')->get(), 200);
    }

    public function getAllFormsList() {
        return response()->json(FormList::get(), 200);
    }

    public function saveChanges(Request $request) {
    	//Log::info("FROM API");
    	//Log::info($request->all());
    	return response()->json($request->all(), 200);
    }
}
