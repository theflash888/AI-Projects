<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Mail;

class MailController extends Controller
{
    public function organizationRequest(Request $request) {
    	$req = new \App\Models\Requests();
    	/*Mail::send('emails.request.copy', [], function ($m) {
    		$m->from('noreply@gapapp.ca', 'Testing');
    		$m->to('app@gapapp.ca', 'Priyank Patel')->subject('Testing');
    	});*/
		$data = [
			'_id' => str_random(10),
			'name' => $request->input('name'),
			'type' => $request->input('type'),
			'firstName' => $request->input('firstName'),
			'lastName' => $request->input('lastName'),
			'auditCompany' => $request->input('auditCompany'),
			'auditCycle' => $request->input('auditCycle'),
			'foodNSafety' => $request->input('foodNSafety'),
			'contactEmail' => $request->input('contactEmail')
		];

		$req->token = $data['_id'];
		$req->org_name = $data['name'];
		$req->org_type = $data['type'];
		$req->org_first_name = $data['firstName'];
		$req->org_last_name = $data['lastName'];
		$req->org_audit_company = $data['auditCompany'];
		$req->org_audit_cycle = $data['foodNSafety'];
		$req->org_fns_coordinator = $data['foodNSafety'];
		$req->contact_email = $data['contactEmail'];
		$req->save();

		Mail::send('emails.request.copy', $data, function ($m) use ($data) {
    		$m->from('noreply@gapapp.ca', 'GAPApp');
    		$m->to($data['contactEmail'], $data['firstName'] . ' ' . $data['lastName'])->subject('Organization Request submitted, waiting for approval.');
    	});

    	if(count(Mail::failures()) > 0) {
    		$error = [
    			'code' => 401,
    			'is_sent' => false
    		];

    		return response()->json([
    			'error' => $error
    		], 401);
    	} else {
    		$success = [
    			'code' => 200,
    			'is_sent' => true
    		];

    		return response()->json([
    			'success' => $success
    		], 200);
    	}
    }

    public function sendApprovalEmail(Request $request) {
        if($request->input('token')) {
            $request = \App\Models\Requests::where('token', '=', $request->input('token'))->first();
            $org = new \App\Models\Organization();

            $org->name = $request->org_name;
            $org->type = $request->org_type;
            $org->person_responsible = $request->org_first_name . ' ' . $request->org_last_name;
            $org->audit_company = $request->org_audit_company;
            $org->audit_cycle = $request->org_audit_cycle;
            $org->coordinator = $request->org_fns_coordinator;
            $org->approved = 1;
            $org->active = 1;
            $org->token = $request->token;
            $org->save();

        $data = [
            'firstName' => $request->org_first_name,
            'lastName' => $request->org_last_name,
            'url' => url('/signup/' . $request->token),
            'contactEmail' => $request->contact_email
        ];

        Mail::send('emails.request.approved', $data, function ($m) use ($data) {
            $m->from('noreply@gapapp.ca', 'GAPApp');
            $m->to($data['contactEmail'], $data['firstName'] . ' ' . $data['lastName'])->subject('Organization request granted.');
        });
        $request->delete();

        } else {
            $error = [
                'code' => 401,
                'message' => 'token is missing'
            ];

            return response()->json([
                'error' => $error
            ], 401);
        }
    }

    public function sendValidationEmail(Request $request) {
        if($request->input('token')) {
            if(\App\User::where('email', '=', $request->input('emailAddr'))->count() == 0) {
                $rand = str_random(20);
                $user = new \App\User();
                $user->email = $request->input('emailAddr');
                $user->password = bcrypt($request->input('password'));
                $user->first = $request->input('firstName');
                $user->last = $request->input('lastName');
                $user->activated = false;
                $user->verified = false;
                $user->activation_code = $rand;

                $org = \App\Models\Organization::where('token', '=', $request->input('token'))->get()->first();
                $user->organization_id = $org->id;
                //$user->save();
                $org->users()->save($user);

                $orgUser = new \App\Models\OrgUser();
                $orgUser->organization_id = $org->id;
                $orgUser->user_id = $user->id;
                $orgUser->save();

                $data = [
                    'contactEmail' => $request->input('emailAddr'),
                    'firstName' => $request->input('firstName'),
                    'lastName' => $request->input('lastName'),
                    'url' => url('/validate/' . $rand . '/' . $request->input('emailAddr'))
                ];

                $owner = new \App\Models\Role();
                $owner->name         = 'orgadmin' . $org->id;
                $owner->display_name = $org->name . '\'s Administrator'; // optional
                $owner->organization_id = $org->id;
                $owner->save();

                $user->attachRole($owner);

                Mail::send('emails.request.signup', $data, function ($m) use ($data) {
                    $m->from('noreply@gapapp.ca', 'GAPApp');
                    $m->to($data['contactEmail'], $data['firstName'] . ' ' . $data['lastName'])->subject('Thank you for signing up. Verify your email to start using the dashboard.');
                });

                $success = [
                    'code' => 200,
                    'message' => 'Account creation successful!'
                ];

                return response()->json([
                    'success' => $success
                ], 200);
            } else {
                $error = [
                    'code' => 401,
                    'message' => 'email already exists'
                ];

                return response()->json([
                    'error' => $error
                ], 401);
            }
        } else {
            $error = [
                'code' => 401,
                'message' => 'token is missing'
            ];

            return response()->json([
                'error' => $error
            ], 401);
        }
    }
}
