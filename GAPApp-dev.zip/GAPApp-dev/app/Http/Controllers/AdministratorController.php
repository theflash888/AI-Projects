<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\Organization;
use Auth;
use DB;
use App\Models\Announcement;

class AdministratorController extends Controller
{
    public function organizationDetails($id) {
    	return view('dashboard/administrator/organizationDetails', ['org' => Organization::findOrFail($id), 'users' => Organization::find($id)->users]);
    }

    public function requestDetails($id) {
    	return view('dashboard/administrator/requestDetails', ['req' => \App\Models\Requests::where('token', '=', $id)->first()]);
    }

    public function createNewRole(Request $request) {
    	$role = \App\Models\Role::where("name", $request->input('name'))->count();

    	if($role > 0)
    	{
    		$error = [
    			'code' => 400,
    			'message' => 'Role with that identifier already exists!'
    		];

    		return response()->json(['error' => $error], 400);
    	} else {
    		$new_role = new \App\Models\Role();
    		$new_role->organization_id = $request->input('orgID');
    		$new_role->name = $request->input('name');
    		$new_role->display_name = $request->input('displayName');
    		$org = Organization::find(Auth::user()->organizations()->first()->id);
    		$org->role()->save($new_role);

    		$success = [
    			'code' => 200,
    			'message' => 'New Role ' . $request->input('name') . ' created!'
    		];

    		return response()->json(['success' => $success], 200);
    	}
    }

    public function listRoles() {
    	$org = Organization::find(Auth::user()->organizations()->first()->id);

    	return response()->json(['code' => 200, 'roles' => $org->role], 200);
    }

    public function listPermissions(Request $request)
    {
      $permissions = \App\Models\Permission::get();
      $permission_list = [];
      $role = \App\Models\Role::where('id', $request->input('id'))->first();
      foreach($permissions as $permission)
      {
        array_push($permission_list, ['id' => $permission->id, 'name' => $permission->display_name, 'canUse' => ($this->checkForPermission($permission->id, $request->input('id')) > 0) ? true : false]);
      }
      return response()->json(['code' => 200, 'role' => $role->display_name, 'permissions' => $permission_list], 200);
    }

    public function checkForPermission($pID, $rID)
    {
      $role = \App\Models\Role::find($rID);
      return DB::table('permission_role')->where('role_id', $rID)->where('permission_id', $pID)->count();
    }

    public function getUserRoles()
    {
      $org = Organization::find(Auth::user()->organizations()->first()->id);
      $users = [];
      foreach($org->users as $user)
      {
        array_push($users, ['user' => $user, 'role' => $this->getUserRole($user->id)]);
      }
      return response()->json(['code' => 200, 'users' => $users], 200);
    }

    public function getUserRole($uID)
    {
      return DB::table('role_user')->where('user_id', $uID)->first();
    }

    public function changeUserRole(Request $request) {
      $user = DB::table("role_user")->where('user_id', $request->input('userID'))->count();

      if($user > 0)
      {
        $change_role = DB::table("role_user")->where('user_id', $request->input('userID'))->update(['role_id' => $request->input('roleID')]);

        $success = [
    			'code' => 200,
          'role' => $change_role,
    			'message' => 'Role successfully altered!'
    		];

    		return response()->json(['success' => $success], 200);
      }
    }

    public function changePermissions(Request $request) {
      $permissions = DB::table("permission_role")->where("role_id", $request->input('rID'))->where("permission_id", $request->input('pID'))->count();

      if($permissions > 0) {
        $per = DB::table("permission_role")->where("role_id", $request->input('rID'))->where("permission_id", $request->input('pID'))->delete();

        $success = [
    			'code' => 200,
          'permission' => $per,
    			'message' => 'Permission successfully altered!'
    		];

    		return response()->json(['success' => $success], 200);
      } else {
        $per = DB::table("permission_role")->insert(['role_id' => $request->input('rID'), 'permission_id' => $request->input('pID')]);

        $success = [
    			'code' => 200,
          'permission' => $per,
    			'message' => 'Permission successfully altered!'
    		];

    		return response()->json(['success' => $success], 200);
      }
    }

    public function createNewAnnouncement(Request $request) {
        $ann = new Announcement();
        $ann->title = $request->input('title');
        $ann->content = $request->input('content');
        $ann->start_period = $request->input('start_date');
        $ann->end_period = $request->input('end_date');
        $ann->author = Auth::user()->id;
        $ann->save();

        $success = [
    			'code' => 200,
    			'message' => 'New Announcement Posted!'
    		];

    		return response()->json(['success' => $success], 200);
    }

    public function getAnnouncements() {
        $ann = Announcement::orderBy('created_at', 'DESC')->get();

        $success = [
    			'code' => 200,
    			'announcements' => $ann
    		];

    		return response()->json(['success' => $success], 200);
    }

    public function deleteAnnouncement(Request $request) {
        $ann = Announcement::find($request->input('id'));
        if(!$ann->trashed()) {
            $success = [
            'code' => 200,
            'announcements' => $ann->delete()
          ];

          return response()->json(['success' => $success], 200);
        }
    }
}
