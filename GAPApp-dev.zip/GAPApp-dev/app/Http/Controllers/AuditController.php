<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Audit;
use App\Models\Organization;
use Auth;

class AuditController extends Controller
{
    public function saveAudit(Request $request) {
    	$audit = new Audit();
    	$audit->audit_data = $request->input('audit_data');
		$org = Organization::find(Auth::user()->organizations()->first()->id);
      	$audit->user_id = Auth::user()->id;
      	$org->audit()->save($audit);

      	$success = [
    		"code" => 200,
    		"message" => "Audit saved successfull!"
    	];

    	return response()->json([
    		"success" => $success
    	], 200);
    }
}
