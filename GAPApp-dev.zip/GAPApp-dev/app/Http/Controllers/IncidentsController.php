<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Models\Incident;
use Auth;
use App\User;
use App\Models\Organization;
use App\Models\Image;
use App\Models\Comment;
use Storage;
use App\Models\FormR2;
use App\Models\IncidentsLog;

class IncidentsController extends Controller
{
    public function createNewIncidents(Request $request) {
    	$date = $request->input('datestamp');
    	$time = $request->input('timestamp');
    	$description = $request->input('description');
    	$form = $request->input('form');

    	$incident = new Incident();
    	$incident->date = date('Y-m-d');
    	$incident->time = date('H:i:s');
    	$incident->description = $description;
        $incident->corrective_action = $request->input('corrective_action');
        $incident->cause_deviation = $request->input('cause_deviation');
        $incident->form_id = $form;
        $incident->deviation_type = $request->input('deviationType');
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $incident->user_id = Auth::user()->id;
        $org->incidents()->save($incident);

        $log = new IncidentsLog();
        $log->incident_id = $incident->id;
        $log->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $log->organization_id = $org->id;
        $log->comments = "New Incident Added";
        $log->save();

        //Auth::user()->incidents()->save($incident);

        /*$image = new Image();
        $image->mime = "text/png";
        $image->size = "20MB";
        $image->storage_path = "blah";
        $image->filename = "test.png";
        $image->disk = "s3";
        $image->status = false;*/
        //$incident->images()->save($image);
        //
    }

    public function createQuickIncident(Request $request)
    {
        $date = $request->input('datestamp');
        $time = $request->input('timestamp');
        $description = $request->input('description');
        $form = $request->input('formID');

        $incident = new Incident();
        $incident->date = date('Y-m-d');
        $incident->time = date('H:i:s');
        $incident->description = $description;
        $incident->corrective_action = $request->input('corrective_action');
        $incident->cause_deviation = $request->input('cause_deviation');
        $incident->deviation_type = $request->input('deviationType');
        $incident->form_id = $form;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $incident->user_id = Auth::user()->id;
        $org->incidents()->save($incident);

        $log = new IncidentsLog();
        $log->incident_id = $incident->id;
        $log->user_id = Auth::user()->id;
        $log->comments = "New Incident Added";
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $log->organization_id = $org->id;
        $log->save();

        $success = [
            'code' => 200,
            'message' => 'New Incident Added!'
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function addNewComment(Request $request)
    {
        $comment = new Comment();
        $comment->user_id = Auth::user()->id;
        $comment->comment = $request->input('newComment');

        $incident = Incident::find($request->input('incident_id'));
        $incident->comments()->save($comment);

        if($request->input('resolve') && $request->input('resolve') == $request->input('incident_id'))
        {
            $incident->resolved = true;
            $incident->save();
        }

        $log = new IncidentsLog();
        $log->incident_id = $incident->id;
        $log->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $log->organization_id = $org->id;
        $log->comments = "New Comment Added!";
        $log->save();

        return back()->withInput();
    }

    public function uploadImages(Request $request) 
    {
        $incident = Incident::find($request->input('id'));

        $file = $request->file('file');

        $image = new Image();
        $image->id = str_random(36);
        $image->mime = $file->getClientMimeType();
        $image->size = $file->getClientSize();
        $image->storage_path = "gapapp_incidents/" . $file->getFilename() . '.' . $file->guessClientExtension();
        $image->filename = $file->getFilename() . '.' . $file->guessClientExtension();
        $image->disk = "s3";
        $image->status = true;
        Storage::disk('s3')->put('gapapp_incidents/' . $file->getFilename() . '.' . $file->guessClientExtension(), file_get_contents($file));
        $incident->images()->save($image);

        $success = [
            'code' => 200,
            'message' => 'Image Uploaded'
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function getAllImages(Request $request)
    {
        $incident_id = $request->input('incident_id');
        $incident = Incident::find($incident_id);
        $incident_images = [];
        foreach($incident->images as $image) {
            $img = [
                'file_path' => env('S3') . $image->storage_path,
                'timestamp' => $image->created_at,
                'id' => $image->id
            ];

            array_push($incident_images, $img);
        }
        $success = [
            'code' => 200,
            'images' => $incident_images
        ];


        return response()->json([
            'success' => $success
        ], 200);
    }

    public function getIncidentInfo(Request $request) {
        $incident_id = $request->input('incidentID');
        $incident = Incident::find($incident_id);

        $success = [
            'code' => 200,
            'incident' => $incident
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function editIncidentInfo(Request $request) {
        $incident_id = $request->input('id');
        $incident = Incident::find($incident_id);

        $incident->description = $request->input('description');
        $incident->cause_deviation = $request->input('cause_deviation');
        $incident->corrective_action = $request->input('corrective_action');
        $incident->form_id = $request->input('relatedForm');

        if($incident->deviation_type == 1) {
            if($request->input('prevention_recurrence'))
                $incident->prevention_recurrence = $request->input('prevention_recurrence');

            if($request->input('modified_procedure'))
                $incident->modified_procedure = $request->input('modified_procedure');
        }

        $log = new IncidentsLog();
        $log->incident_id = $incident->id;
        $log->user_id = Auth::user()->id;
        $log->comments = "Incident Information Edited!";
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $log->organization_id = $org->id;
        $log->save();

        $success = [
            'code' => 200,
            'changes_saved' => $incident->save(),
            'message' => 'Changes have been saved!'
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createMinorRRecord(Request $request) {
        $incident_id = $request->input('incidentID');
        $incident = Incident::find($incident_id);

        $incident->resolved = true;
        
        $form_r2 = new FormR2();
        $form_r2->incident_id = $incident->id;
        $form_r2->major_deviation = $incident->description;
        $form_r2->cause_of_deviation = $incident->cause_deviation;
        $form_r2->corrective_action = $incident->corrective_action;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $form_r2->user_id = Auth::user()->id;
        
        $log = new IncidentsLog();
        $log->incident_id = $incident->id;
        $log->user_id = Auth::user()->id;
        $log->comments = "Incident Resolved!";
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $log->organization_id = $org->id;
        $log->save();

        $success = [
            'code' => 200,
            'changes_saved' => ($org->forms_r2()->save($form_r2) && $incident->save()),
            'message' => 'Incident has been resolved!'
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function getAllIncidentLists() {
        //foreach(Auth::user()->organizations as $org) {
            return response()->json(['incidents' => Incident::where('organization_id', '1')->get()], 200);
        //}
    }
}
