<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\User;
use Auth;
use Storage;

class LoginController extends Controller
{
    public function validateEmail(Request $request) {
    		if(User::where('email', '=', $request->input('email'))->exists()) {
    			$success = [
    				"code" => 200,
    				"validation" => true
    			];
    			return response()->json([
    				"success" => $success
    			], 200);
    		} else {
    			$error = [
    				"code" => 401,
    				"validation" => false
    			];
    			return response()->json([
    				"error" => $error
    			], 401);
    		}
    }

    public function validateLogin(Request $request) {
    	$email = $request->input('email');
    	$password = $request->input('password');

    	if (Auth::attempt(['email' => $email, 'password' => $password])) {
    		/*$success = [
    			"code" => 200,
    			"validation" => true
    		];
    		return response()->json([
    			"success" => $success
    		], 200);*/
			return redirect()->intended('dashboard');
    	} else {
    		$error = [
    			"code" => 401,
    			"validation" => false
    		];
    		return response()->json([
    			"error" => $error
    		], 401);
    	}
    }

    public function verifyEmail($token, $email) {
        if($token && $email) {
            $user = User::where('activation_code', '=', $token)->get()->first();
            if($user && $user->email == $email && $user->activated == false) {
                $user->activation_code = '';
                $user->verified = true;
                $user->activated = true;
                $user->save();

                return view('organizations.validated', ['validated' => true]);
            } else {
                return view('organizations.validated', ['validated' => false]);
            }
        }
    }

    public function getOrganizationLogo(Request $request) {
        if($request->input('email')) {
            $user = User::where('email', '=', $request->input('email'))->get()->first();
            foreach($user->organizations as $org)
            {
                //if(Storage::disk('s3')->has('gapapp_organizations/logos/' . $org->logo)) {
                    $success = [
                        'code' => 200,
                        'content' => env('S3') . 'gapapp_organizations/logos/' . $org->logo
                    ];
                    return  response()->json([
                            'success' => $success
                        ], 200);
                /*} else {
                    $error = [
                        "code" => 404,
                        "message" => 'logo not found'
                    ];
                    return response()->json([
                        "error" => $error
                    ], 404);
                    
                }*/
            }
            
        } else {
            $error = [
                "code" => 401,
                "message" => 'email not specified'
            ];
            return response()->json([
                "error" => $error
            ], 401);
        }
    }

    public function getLoggedInUser() {
        return response()->json(['me' => Auth::user()], 200);
    }
}
