<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Models\FormList;
use App\Models\FormI;
use App\Models\FormK;
use App\Models\FormL;
use App\Models\FormJ;
use App\Models\FormT;
use App\Models\FormC;
use App\Models\FormB;
use App\Models\FormM;
use App\Models\FormN1;
use App\Models\FormN2;
use App\Models\FormO;
use App\Models\FormH3;
use App\Models\FormG;
use App\Models\FormH1;
use App\Models\FormH2;
use App\Models\FormP2;
use App\Models\FormF;
use App\Models\FormR;
use App\Models\FormD;
use App\Models\FormQ;
use App\Models\FormS;
use App\Models\FormE;
use App\Models\FormP1;
use App\Models\FormA;
use App\Models\Incident;
use Storage;
use Auth;
use App\Models\Organization;
use App\Models\IncidentsLog;

class FormsController extends Controller
{
    public function getAllForms() {
    	$forms = FormList::all();

    	return response()->json([
    		'forms' => $forms
    	], 200);
    }

    public function createFormIRecord(Request $request) {
    	$form_i = new FormI();
    	$form_i->equipment = $request->input('equipment');
    	$form_i->employee = Auth::user()->first . ' ' . Auth::user()->last;
    	$form_i->activity_code = $request->input('activity');
      $form_i->activity_other = $request->input('activity_other');
    	$form_i->description = $request->input('description');
      $org = Organization::find(Auth::user()->organizations()->first()->id);
      $form_i->user_id = Auth::user()->id;
      $org->forms_i()->save($form_i);

    	$success = [
    		"code" => 200,
    		"message" => "New Record added successfully!"
    	];

    	return response()->json([
    		"success" => $success
    	], 200);
    }

    public function createFormKRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
    	$form_k = new FormK();
    	$form_k->employees = $request->input('employees');
    	$form_k->topics = $request->input('topic');
    	$form_k->responsible = $request->input('responsible');
    	$form_k->signature = $request->input('signature');
    	$form_k->user_id = Auth::user()->id;
    	$org->forms_k()->save($form_k);

    	$success = [
    		"code" => 200,
    		"message" => "New Record added successfully!"
    	];

    	return response()->json([
    		"success" => $success
    	], 200);
    }

    public function createFormLRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
    	$form_l = new FormL();
    	$form_l->visitor = $request->input('visitor');
    	$form_l->company_purpose = $request->input('company_purpose');
      $form_l->location = $request->input('location');
    	$form_l->user_id = Auth::user()->id;
    	$org->forms_L()->save($form_l);

    	$success = [
    		"code" => 200,
    		"message" => "New Record added successfully!"
    	];

    	return response()->json([
    		"success" => $success
    	], 200);
    }

    public function createFormJRecord(Request $request) {
    	$form_j = new FormJ();
    	$form_j->assessment = ($request->input('assessment') == true ? true : false);
    	$form_j->paper_towel = ($request->input('paper_towel') == true ? true : false);
    	$form_j->soap = ($request->input('soap') == true ? true : false);
    	$form_j->water_source = ($request->input('water_source') == true ? true : false);
    	$form_j->toilet_paper = ($request->input('toilet_paper') == true ? true : false);
    	$form_j->hand_sanitizer = ($request->input('hand_sanitizer') == true ? true : false);
    	$form_j->garbage_emptied = ($request->input('garbage_emptied') == true ? true : false);
        $form_j->location = $request->input('location');
        $form_j->location_type = $request->input('location_type');
      $org = Organization::find(Auth::user()->organizations()->first()->id);
      $form_j->user_id = Auth::user()->id;
      $org->forms_i()->save($form_j);
    	//return ($request->input('assessment') == true ? "true" : "false");
    	//
    	$success = [
    		"code" => 200,
    		"message" => "New Record added successfully!"
    	];

    	return response()->json([
    		"success" => $success
    	], 200);
    }

    public function createFormTRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $form_t = new FormT();
        $form_t->date = $request->input('date');
        $form_t->general_security = ($request->input('general_security') == true ? true : false);
        $form_t->storage_security = ($request->input('storage_security') == true ? true : false);
        $form_t->agriculture_security = ($request->input('agriculture_security') == true ? true : false);
        $form_t->water_security = ($request->input('water_security') == true ? true : false);
        $form_t->information_security = ($request->input('information_security') == true ? true : false);
        $form_t->personnel_security = ($request->input('personnel_security') == true ? true : false);
        $form_t->physical_security = ($request->input('physical_security') == true ? true : false);
        $form_t->entry_security = ($request->input('entry_security') == true ? true : false);
        $form_t->actions = $request->input('actions');
        $form_t->user_id = Auth::user()->id;
        $org->forms_t()->save($form_t);

        $success = [
            "code" => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            "success" => $success
        ], 200);
    }

    public function saveFormTRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $form_t = FormT::find($request->input('id'));
        $form_t->date = $request->input('date');
        $form_t->general_security = ($request->input('general_security') == true ? true : false);
        $form_t->storage_security = ($request->input('storage_security') == true ? true : false);
        $form_t->agriculture_security = ($request->input('agriculture_security') == true ? true : false);
        $form_t->water_security = ($request->input('water_security') == true ? true : false);
        $form_t->information_security = ($request->input('information_security') == true ? true : false);
        $form_t->personnel_security = ($request->input('personnel_security') == true ? true : false);
        $form_t->physical_security = ($request->input('physical_security') == true ? true : false);
        $form_t->entry_security = ($request->input('entry_security') == true ? true : false);
        $form_t->actions = $request->input('actions');
        $form_t->user_id = Auth::user()->id;
        $org->forms_t()->save($form_t);

        $success = [
            "code" => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            "success" => $success
        ], 200);
    }

    public function getFormTRecord(Request $request) {
        $form_t = FormT::where('id', $request->input('id'))
                    ->where('date', $request->input('date'))
                    ->where('organization_id', $request->input('organizations_id'))
                    ->where('user_id', $request->input('users_id'));

        $success = [
            'code' => 200,
            'details' => $form_t->first()
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function createFormCRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $form_c = new FormC();
        $form_c->date = $request->input('date');
        $form_c->aprons_rubber = $request->input('aprons_rubber');
        $form_c->aprons_used = $request->input('aprons_used');
        $form_c->employee_adhere = $request->input('employee_adhere');
        $form_c->employee_aprons = $request->input('employee_aprons');
        $form_c->employees_aware = $request->input('employees_aware');
        $form_c->employees_trained = $request->input('employees_trained');
        $form_c->gloves_aprons = $request->input('gloves_aprons');
        $form_c->gloves_removed = $request->input('gloves_removed');
        $form_c->gloves_rubber = $request->input('gloves_rubber');
        $form_c->gloves_substitute = $request->input('gloves_substitute');
        $form_c->gloves_used = $request->input('gloves_used');
        $form_c->hands_reusable_gloves = $request->input('hands_reusable_gloves');
        $form_c->hands_washed = $request->input('hands_washed');
        $form_c->hands_washed_dried = $request->input('hands_washed_dried');
        $form_c->major_minor = $request->input('major_minor');
        $form_c->no_water = $request->input('no_water');
        $form_c->person_responsible = $request->input('person_responsible');
        $form_c->person_responsible_name = $request->input('person_responsible_name');
        $form_c->person_transmit = $request->input('person_transmit');
        $form_c->reusable_aprons = $request->input('reusable_aprons');
        $form_c->reusable_gloves_washed = $request->input('reusable_gloves_washed');
        $form_c->trained_fallen = $request->input('trained_fallen');
        $form_c->trained_harvest = $request->input('trained_harvest');
        $form_c->trained_precautions = $request->input('trained_precautions');
        $form_c->trained_touched = $request->input('trained_touched');
        $form_c->trained_visually = $request->input('trained_visually');
        $form_c->wipe_hand_sanitizer = $request->input('wipe_hand_sanitizer');
        $form_c->wounds_treated = $request->input('wounds_treated');
        $form_c->user_id = Auth::user()->id;
        $org->forms_c()->save($form_c);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormCRecord(Request $request) {
        $form_c = FormC::find($request->input('id'));
        $form_c->date = $request->input('date');
        $form_c->aprons_rubber = $request->input('aprons_rubber');
        $form_c->aprons_used = $request->input('aprons_used');
        $form_c->employee_adhere = $request->input('employee_adhere');
        $form_c->employee_aprons = $request->input('employee_aprons');
        $form_c->employees_aware = $request->input('employees_aware');
        $form_c->employees_trained = $request->input('employees_trained');
        $form_c->gloves_aprons = $request->input('gloves_aprons');
        $form_c->gloves_removed = $request->input('gloves_removed');
        $form_c->gloves_rubber = $request->input('gloves_rubber');
        $form_c->gloves_substitute = $request->input('gloves_substitute');
        $form_c->gloves_used = $request->input('gloves_used');
        $form_c->hands_reusable_gloves = $request->input('hands_reusable_gloves');
        $form_c->hands_washed = $request->input('hands_washed');
        $form_c->hands_washed_dried = $request->input('hands_washed_dried');
        $form_c->major_minor = $request->input('major_minor');
        $form_c->no_water = $request->input('no_water');
        $form_c->person_responsible = $request->input('person_responsible');
        $form_c->person_responsible_name = $request->input('person_responsible_name');
        $form_c->person_transmit = $request->input('person_transmit');
        $form_c->reusable_aprons = $request->input('reusable_aprons');
        $form_c->reusable_gloves_washed = $request->input('reusable_gloves_washed');
        $form_c->trained_fallen = $request->input('trained_fallen');
        $form_c->trained_harvest = $request->input('trained_harvest');
        $form_c->trained_precautions = $request->input('trained_precautions');
        $form_c->trained_touched = $request->input('trained_touched');
        $form_c->trained_visually = $request->input('trained_visually');
        $form_c->wipe_hand_sanitizer = $request->input('wipe_hand_sanitizer');
        $form_c->wounds_treated = $request->input('wounds_treated');
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_c()->save($form_c);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormCRecord(Request $request) {
        $form_c = FormC::where('id', $request->input('id'));

        $success = [
            'code' => 200,
            'details' => $form_c->first()
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function createFormDRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $form_d = new FormD();
        $form_d->aprons_rubber = $request->input('aprons_rubber');
        $form_d->aprons_used = $request->input('aprons_used');
        $form_d->clean_footwear = $request->input('clean_footwear');
        $form_d->employee_adhere = $request->input('employee_adhere');
        $form_d->employee_aprons = $request->input('employee_aprons');
        $form_d->employee_authorized = $request->input('employee_authorized');
        $form_d->employees_aware = $request->input('employees_aware');
        $form_d->employees_trained = $request->input('employees_trained');
        $form_d->false_fingernails = $request->input('false_fingernails');
        $form_d->gloves_aprons = $request->input('gloves_aprons');
        $form_d->gloves_removed = $request->input('gloves_removed');
        $form_d->gloves_rubber = $request->input('gloves_rubber');
        $form_d->gloves_substitute = $request->input('gloves_used');
        $form_d->gloves_used = $request->input('gloves_used');
        $form_d->hands_reusable_gloves = $request->input('hands_reusable_gloves');
        $form_d->hands_washed = $request->input('hands_washed');
        $form_d->hands_washed_dried = $request->input('hands_washed_dried');
        $form_d->items_removed_pocket = $request->input('items_removed_pocket');
        $form_d->jewellery_worn = $request->input('jewellery_worn');
        $form_d->long_hair_touching = $request->input('long_hair_touching');
        $form_d->loose_buttons_fixed = $request->input('loose_buttons_fixed');
        $form_d->major_minor = $request->input('major_minor');
        $form_d->no_water = $request->input('no_water');
        $form_d->person_responsible = $request->input('person_responsible');
        $form_d->person_responsible_name = $request->input('person_responsible_name');
        $form_d->person_transmit = $request->input('person_transmit');
        $form_d->personal_cleanliness = $request->input('personal_cleanliness');
        $form_d->personal_cleanliness_other = $request->input('personal_cleanliness_other');
        $form_d->reusable_aprons = $request->input('reusable_aprons');
        $form_d->ring_gloves = $request->input('ring_gloves');
        $form_d->trained_precautions = $request->input('trained_precautions');
        $form_d->wipe_hand_sanitizer = $request->input('wipe_hand_sanitizer');
        $form_d->wounds_treated = $request->input('wounds_treated');
        $form_d->user_id = Auth::user()->id;
        $org->forms_d()->save($form_d);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormDRecord(Request $request) {
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $form_d = FormD::find($request->input('id'));
        $form_d->aprons_rubber = $request->input('aprons_rubber');
        $form_d->aprons_used = $request->input('aprons_used');
        $form_d->clean_footwear = $request->input('clean_footwear');
        $form_d->employee_adhere = $request->input('employee_adhere');
        $form_d->employee_aprons = $request->input('employee_aprons');
        $form_d->employee_authorized = $request->input('employee_authorized');
        $form_d->employees_aware = $request->input('employees_aware');
        $form_d->employees_trained = $request->input('employees_trained');
        $form_d->false_fingernails = $request->input('false_fingernails');
        $form_d->gloves_aprons = $request->input('gloves_aprons');
        $form_d->gloves_removed = $request->input('gloves_removed');
        $form_d->gloves_rubber = $request->input('gloves_rubber');
        $form_d->gloves_substitute = $request->input('gloves_used');
        $form_d->gloves_used = $request->input('gloves_used');
        $form_d->hands_reusable_gloves = $request->input('hands_reusable_gloves');
        $form_d->hands_washed = $request->input('hands_washed');
        $form_d->hands_washed_dried = $request->input('hands_washed_dried');
        $form_d->items_removed_pocket = $request->input('items_removed_pocket');
        $form_d->jewellery_worn = $request->input('jewellery_worn');
        $form_d->long_hair_touching = $request->input('long_hair_touching');
        $form_d->loose_buttons_fixed = $request->input('loose_buttons_fixed');
        $form_d->major_minor = $request->input('major_minor');
        $form_d->no_water = $request->input('no_water');
        $form_d->person_responsible = $request->input('person_responsible');
        $form_d->person_responsible_name = $request->input('person_responsible_name');
        $form_d->person_transmit = $request->input('person_transmit');
        $form_d->personal_cleanliness = $request->input('personal_cleanliness');
        $form_d->personal_cleanliness_other = $request->input('personal_cleanliness_other');
        $form_d->reusable_aprons = $request->input('reusable_aprons');
        $form_d->ring_gloves = $request->input('ring_gloves');
        $form_d->trained_precautions = $request->input('trained_precautions');
        $form_d->wipe_hand_sanitizer = $request->input('wipe_hand_sanitizer');
        $form_d->wounds_treated = $request->input('wounds_treated');
        $form_d->user_id = Auth::user()->id;
        $org->forms_d()->save($form_d);

        $success = [
            'code' => 200,
            "message" => "Record save successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormDRecord(Request $request) {
        $form_d = FormD::where('id', $request->input('id'));

        $success = [
            'code' => 200,
            'details' => $form_d->first()
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function createFormBRecord(Request $request) {
        $form_b = new FormB();
        $form_b->date = $request->input('date');
        $form_b->storage_id = $request->input('storage_id');
        $form_b->ceiling_storage = $request->input('ceiling_storage');
        $form_b->ceiling_storage_action = ($request->input('ceiling_storage_action') ? $request->input('ceiling_storage_action') : null);
        $form_b->floor_clean = $request->input('floor_clean');
        $form_b->floor_clean_action = ($request->input('floor_clean_action') ? $request->input('floor_clean_action') : null);
        $form_b->free_animals = $request->input('free_animals');
        $form_b->free_animals_action = ($request->input('free_animals_action') ? $request->input('free_animals_action') : null);
        $form_b->furnace_exhausting = $request->input('furnace_exhausting');
        $form_b->furnace_exhausting_action = ($request->input('furnace_exhausting_action') ? $request->input('furnace_exhausting_action') : null);
        $form_b->production_equipment = $request->input('production_equipment');
        $form_b->production_equipment_action = ($request->input('production_equipment_action') ? $request->input('production_equipment_action') : null);
        $form_b->leaky_area = $request->input('leaky_area');
        $form_b->leaky_area_action = ($request->input('leaky_area_action') ? $request->input('leaky_area_action') : null);
        $form_b->lights_shatterproof = $request->input('lights_shatterproof');
        $form_b->lights_shatterproof_action = ($request->input('lights_shatterproof_action') ? $request->input('lights_shatterproof_action') : null);
        $form_b->no_smoking = $request->input('no_smoking');
        $form_b->no_smoking_action = ($request->input('no_smoking_action') ? $request->input('no_smoking_action') : null);
        $form_b->other = $request->input('other');
        $form_b->other_action = ($request->input('other_action') ? $request->input('other_action') : null);
        $form_b->potatoes_dark = $request->input('potatoes_dark');
        $form_b->potatoes_dark_action = ($request->input('potatoes_dark_action') ? $request->input('potatoes_dark_action') : null);
        $form_b->potatoes_treated = $request->input('potatoes_treated');
        $form_b->potatoes_treated_action = ($request->input('potatoes_treated_action') ? $request->input('potatoes_treated_action') : null);
        $form_b->proper_condition = $request->input('proper_condition');
        $form_b->proper_condition_action = ($request->input('proper_condition_action') ? $request->input('proper_condition_action') : null);
        $form_b->storage_in_use = $request->input('storage_in_use');
        $form_b->storage_in_use_action = ($request->input('storage_in_use_action') ? $request->input('storage_in_use_action') : null);
        $form_b->storage_secured = $request->input('storage_secured');
        $form_b->storage_secured_action = ($request->input('storage_secured_action') ? $request->input('storage_secured_action') : null);
        $form_b->treated_seed = $request->input('treated_seed');
        $form_b->treated_seed_action = ($request->input('treated_seed_action') ? $request->input('treated_seed_action') : null);
        $form_b->storage_cleaning_desc = $request->input('storage_cleaning_desc');
        $form_b->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_b()->save($form_b);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormBRecord(Request $request) {
        $form_b = FormB::find($request->input('id'));
        $form_b->date = $request->input('date');
        $form_b->storage_id = $request->input('storage_id');
        $form_b->ceiling_storage = $request->input('ceiling_storage');
        $form_b->ceiling_storage_action = ($request->input('ceiling_storage_action') ? $request->input('ceiling_storage_action') : null);
        $form_b->floor_clean = $request->input('floor_clean');
        $form_b->floor_clean_action = ($request->input('floor_clean_action') ? $request->input('floor_clean_action') : null);
        $form_b->free_animals = $request->input('free_animals');
        $form_b->free_animals_action = ($request->input('free_animals_action') ? $request->input('free_animals_action') : null);
        $form_b->furnace_exhausting = $request->input('furnace_exhausting');
        $form_b->furnace_exhausting_action = ($request->input('furnace_exhausting_action') ? $request->input('furnace_exhausting_action') : null);
        $form_b->production_equipment = $request->input('production_equipment');
        $form_b->production_equipment_action = ($request->input('production_equipment_action') ? $request->input('production_equipment_action') : null);
        $form_b->leaky_area = $request->input('leaky_area');
        $form_b->leaky_area_action = ($request->input('leaky_area_action') ? $request->input('leaky_area_action') : null);
        $form_b->lights_shatterproof = $request->input('lights_shatterproof');
        $form_b->lights_shatterproof_action = ($request->input('lights_shatterproof_action') ? $request->input('lights_shatterproof_action') : null);
        $form_b->no_smoking = $request->input('no_smoking');
        $form_b->no_smoking_action = ($request->input('no_smoking_action') ? $request->input('no_smoking_action') : null);
        $form_b->other = $request->input('other');
        $form_b->other_action = ($request->input('other_action') ? $request->input('other_action') : null);
        $form_b->potatoes_dark = $request->input('potatoes_dark');
        $form_b->potatoes_dark_action = ($request->input('potatoes_dark_action') ? $request->input('potatoes_dark_action') : null);
        $form_b->potatoes_treated = $request->input('potatoes_treated');
        $form_b->potatoes_treated_action = ($request->input('potatoes_treated_action') ? $request->input('potatoes_treated_action') : null);
        $form_b->proper_condition = $request->input('proper_condition');
        $form_b->proper_condition_action = ($request->input('proper_condition_action') ? $request->input('proper_condition_action') : null);
        $form_b->storage_in_use = $request->input('storage_in_use');
        $form_b->storage_in_use_action = ($request->input('storage_in_use_action') ? $request->input('storage_in_use_action') : null);
        $form_b->storage_secured = $request->input('storage_secured');
        $form_b->storage_secured_action = ($request->input('storage_secured_action') ? $request->input('storage_secured_action') : null);
        $form_b->treated_seed = $request->input('treated_seed');
        $form_b->treated_seed_action = ($request->input('treated_seed_action') ? $request->input('treated_seed_action') : null);
        $form_b->storage_cleaning_desc = $request->input('storage_cleaning_desc');
        $form_b->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_b()->save($form_b);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormBRecord(Request $request)
    {
        $form_b = FormB::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_b' => $form_b
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormMRecord(Request $request) {
      $form_m = new FormM();
      $form_m->storage_id = $request->input('storage_id');
      $form_m->device_number = $request->input('device_number');
      $form_m->findings = $request->input('findings');
      $form_m->action_taken = $request->input('action_taken');
      $form_m->user_id = Auth::user()->id;
      $org = Organization::find(Auth::user()->organizations()->first()->id);
      $org->forms_m()->save($form_m);

      $success = [
          'code' => 200,
          "message" => "New Record added successfully!"
      ];

      return response()->json([
          'success' => $success
      ]);
    }

    public function createFormN1Record(Request $request)
    {
        $form_n1 = new FormN1();
        $form_n1->water_source = $request->input('water_source');
        $form_n1->chlorine_added = $request->input('chlorine_added');
        $form_n1->chlorine_concentration = $request->input('chlorine_concentration');
        $form_n1->contact_time = $request->input('contact_time');
        $form_n1->method = $request->input('method');
        $form_n1->post_treatment = $request->input('post_treatment');
        $form_n1->pre_treatment = $request->input('pre_treatment');
        $form_n1->recirculated_water = ($request->input('recirculated_water') != null ? $request->input('recirculated_water') : false);
        $form_n1->volume = $request->input('volume');
        $form_n1->water_ph = $request->input('water_ph');
        $form_n1->water_source = $request->input('water_source');
        $form_n1->water_changed = ($request->input('water_changed') != null ? $request->input('water_changed') : false);
        $form_n1->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_m()->save($form_n1);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormN1Record(Request $request) {
        $form_n1 = FormN1::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_n1' => $form_n1
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function saveFormN1Record(Request $request)
    {
        $form_n1 = FormN1::find($request->input('id'));
        $form_n1->water_source = $request->input('water_source');
        $form_n1->chlorine_added = $request->input('chlorine_added');
        $form_n1->chlorine_concentration = $request->input('chlorine_concentration');
        $form_n1->contact_time = $request->input('contact_time');
        $form_n1->method = $request->input('method');
        $form_n1->post_treatment = $request->input('post_treatment');
        $form_n1->pre_treatment = $request->input('pre_treatment');
        $form_n1->recirculated_water = ($request->input('recirculated_water') != null ? $request->input('recirculated_water') : false);
        $form_n1->volume = $request->input('volume');
        $form_n1->water_ph = $request->input('water_ph');
        $form_n1->water_source = $request->input('water_source');
        $form_n1->water_changed = ($request->input('water_changed') != null ? $request->input('water_changed') : false);
        $form_n1->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_m()->save($form_n1);

        $success = [
            'code' => 200,
            "message" => "Record save successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function createFormN2Record(Request $request)
    {
        $form_n2 = new FormN2();
        $form_n2->water_source = $request->input('water_source');
        $form_n2->method = $request->input('method');
        $form_n2->product = $request->input('product');
        $form_n2->month = $request->input('month');
        $form_n2->temp_type = $request->input('temp_type');
        $form_n2->water_temp = $request->input('water_temp');
        $form_n2->product_temp = $request->input('product_temp');
        $form_n2->difference = $request->input('difference');
        $form_n2->action_taken = $request->input('action_taken');
        $form_n2->method_other = $request->input('method_other');
        $form_n2->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_n2()->save($form_n2);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormN2Record(Request $request)
    {
        $form_n2 = FormN2::find($request->input('id'));
        $form_n2->water_source = $request->input('water_source');
        $form_n2->method = $request->input('method');
        $form_n2->product = $request->input('product');
        $form_n2->month = $request->input('month');
        $form_n2->temp_type = $request->input('temp_type');
        $form_n2->water_temp = $request->input('water_temp');
        $form_n2->product_temp = $request->input('product_temp');
        $form_n2->difference = $request->input('difference');
        $form_n2->action_taken = $request->input('action_taken');
        $form_n2->method_other = $request->input('method_other');
        $form_n2->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_n2()->save($form_n2);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormN2Record(Request $request) {
        $form_n2 = FormN2::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_n2' => $form_n2
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormORecord(Request $request) {
        $form_o = new FormO();
        $form_o->vehicle_inspected = ($request->input('vehicle_inspected') ? $request->input('vehicle_inspected') : false);
        $form_o->hazards = $request->input('hazards');
        $form_o->actions = $request->input('actions');
        $form_o->destination_and_customer = $request->input('destination_and_customer');
        $form_o->product_identifier = $request->input('product_identifier');
        $form_o->quantity_shipped = $request->input('quantity_shipped');
        $form_o->truck_id = $request->input('truck_id');
        $form_o->person_responsible = $request->input('person_responsible');
        $form_o->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_n2()->save($form_o);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormORecord(Request $request) {
        $form_o = FormO::find($request->input('id'));
        $form_o->vehicle_inspected = ($request->input('vehicle_inspected') ? $request->input('vehicle_inspected') : false);
        $form_o->hazards = $request->input('hazards');
        $form_o->actions = $request->input('actions');
        $form_o->destination_and_customer = $request->input('destination_and_customer');
        $form_o->product_identifier = $request->input('product_identifier');
        $form_o->quantity_shipped = $request->input('quantity_shipped');
        $form_o->truck_id = $request->input('truck_id');
        $form_o->person_responsible = $request->input('person_responsible');
        $form_o->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_n2()->save($form_o);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormORecord(Request $request) {
        $form_o = FormO::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_o' => $form_o
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormH3Record(Request $request)
    {
        $form_h3 = new FormH3();
        $form_h3->production_site = $request->input('production_site');
        $form_h3->operation_name = $request->input('operation_name');
        $form_h3->variety = $request->input('variety');
        $form_h3->product_name = $request->input('product_name');
        $form_h3->pcp = $request->input('pcp');
        $form_h3->rate_applied = $request->input('rate_applied');
        $form_h3->quantity_treated = $request->input('quantity_treated');
        $form_h3->lot_id = $request->input('lot_id');
        $form_h3->daa = $request->input('daa');
        $form_h3->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_h3()->save($form_h3);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormH3Record(Request $request)
    {
        $form_h3 = FormH3::find($request->input('id'));
        $form_h3->production_site = $request->input('production_site');
        $form_h3->operation_name = $request->input('operation_name');
        $form_h3->variety = $request->input('variety');
        $form_h3->product_name = $request->input('product_name');
        $form_h3->pcp = $request->input('pcp');
        $form_h3->rate_applied = $request->input('rate_applied');
        $form_h3->quantity_treated = $request->input('quantity_treated');
        $form_h3->lot_id = $request->input('lot_id');
        $form_h3->daa = $request->input('daa');
        $form_h3->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_h3()->save($form_h3);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormH3Record(Request $request)
    {
        $form_h3 = FormH3::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_h3' => $form_h3
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormGRecord(Request $request)
    {
        $form_g = new FormG();
        $form_g->adequate_ventilation = $request->input('adequate_ventilation');
        $form_g->animals = $request->input('animals');
        $form_g->control_measures = $request->input('control_measures');
        $form_g->exterior_doors_close_fitting = $request->input('exterior_doors_close_fitting');
        $form_g->exterior_doors_secured = $request->input('exterior_doors_secured');
        $form_g->exterior_dumpster = $request->input('exterior_dumpster');
        $form_g->exterior_half_perimeter = $request->input('exterior_half_perimeter');
        $form_g->exterior_land_drainage = $request->input('exterior_land_drainage');
        $form_g->exterior_land_drainage_structure = $request->input('exterior_land_drainage_structure');
        $form_g->exterior_maintenance = $request->input('exterior_maintenance');
        $form_g->exterior_maintenance_completed_by = $request->input('exterior_maintenance_completed_by');
        $form_g->exterior_maintenance_completed_date = $request->input('exterior_maintenance_completed_date');
        $form_g->exterior_maintenance_overseen_by = $request->input('exterior_maintenance_overseen_by');
        $form_g->exterior_maintenance_overseen_date = $request->input('exterior_maintenance_overseen_date');
        $form_g->exterior_no_areas_pests = $request->input('exterior_no_areas_pests');
        $form_g->exterior_no_junk = $request->input('exterior_no_junk');
        $form_g->exterior_roof_cover = $request->input('exterior_roof_cover');
        $form_g->exterior_weeds = $request->input('exterior_weeds');
        $form_g->exterior_weeds_controlled = $request->input('exterior_weeds_controlled');
        $form_g->exterior_windows_closed = $request->input('exterior_windows_closed');
        $form_g->fans_air_free = $request->input('fans_air_free');
        $form_g->floor_drainage = $request->input('floor_drainage');
        $form_g->floor_free_pests = $request->input('floor_free_pests');
        $form_g->floors_clean = $request->input('floors_clean');
        $form_g->interior_maintenance = $request->input('interior_maintenance');
        $form_g->interior_maintenance_completed_by = $request->input('interior_maintenance_completed_by');
        $form_g->interior_maintenance_completed_date = $request->input('interior_maintenance_completed_date');
        $form_g->interior_maintenance_overseen_by = $request->input('interior_maintenance_overseen_by');
        $form_g->interior_maintenance_overseen_date = $request->input('interior_maintenance_overseen_date');
        $form_g->material_designated = $request->input('material_designated');
        $form_g->no_exterior_holes = $request->input('no_exterior_holes');
        $form_g->no_holes = $request->input('no_holes');
        $form_g->no_pipes = $request->input('no_pipes');
        $form_g->shatterproof = $request->input('shatterproof');
        $form_g->storage_id = $request->input('storage_id');
        $form_g->building_type = $request->input('building_type');
        $form_g->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_g()->save($form_g);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormGRecord(Request $request)
    {
        $form_g = FormG::find($request->input('id'));
        $form_g->adequate_ventilation = $request->input('adequate_ventilation');
        $form_g->animals = $request->input('animals');
        $form_g->control_measures = $request->input('control_measures');
        $form_g->exterior_doors_close_fitting = $request->input('exterior_doors_close_fitting');
        $form_g->exterior_doors_secured = $request->input('exterior_doors_secured');
        $form_g->exterior_dumpster = $request->input('exterior_dumpster');
        $form_g->exterior_half_perimeter = $request->input('exterior_half_perimeter');
        $form_g->exterior_land_drainage = $request->input('exterior_land_drainage');
        $form_g->exterior_land_drainage_structure = $request->input('exterior_land_drainage_structure');
        $form_g->exterior_maintenance = $request->input('exterior_maintenance');
        $form_g->exterior_maintenance_completed_by = $request->input('exterior_maintenance_completed_by');
        $form_g->exterior_maintenance_completed_date = $request->input('exterior_maintenance_completed_date');
        $form_g->exterior_maintenance_overseen_by = $request->input('exterior_maintenance_overseen_by');
        $form_g->exterior_maintenance_overseen_date = $request->input('exterior_maintenance_overseen_date');
        $form_g->exterior_no_areas_pests = $request->input('exterior_no_areas_pests');
        $form_g->exterior_no_junk = $request->input('exterior_no_junk');
        $form_g->exterior_roof_cover = $request->input('exterior_roof_cover');
        $form_g->exterior_weeds = $request->input('exterior_weeds');
        $form_g->exterior_weeds_controlled = $request->input('exterior_weeds_controlled');
        $form_g->exterior_windows_closed = $request->input('exterior_windows_closed');
        $form_g->fans_air_free = $request->input('fans_air_free');
        $form_g->floor_drainage = $request->input('floor_drainage');
        $form_g->floor_free_pests = $request->input('floor_free_pests');
        $form_g->floors_clean = $request->input('floors_clean');
        $form_g->interior_maintenance = $request->input('interior_maintenance');
        $form_g->interior_maintenance_completed_by = $request->input('interior_maintenance_completed_by');
        $form_g->interior_maintenance_completed_date = $request->input('interior_maintenance_completed_date');
        $form_g->interior_maintenance_overseen_by = $request->input('interior_maintenance_overseen_by');
        $form_g->interior_maintenance_overseen_date = $request->input('interior_maintenance_overseen_date');
        $form_g->material_designated = $request->input('material_designated');
        $form_g->no_exterior_holes = $request->input('no_exterior_holes');
        $form_g->no_holes = $request->input('no_holes');
        $form_g->no_pipes = $request->input('no_pipes');
        $form_g->shatterproof = $request->input('shatterproof');
        $form_g->storage_id = $request->input('storage_id');
        $form_g->building_type = $request->input('building_type');
        $form_g->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_g()->save($form_g);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormGRecord(Request $request)
    {
        $form_g = FormG::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_g' => $form_g
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormH1Record(Request $request)
    {
        $form_h1 = new FormH1();
        $form_h1->actual_quantity_used = $request->input('actual_quantity_used');
        $form_h1->area_treated = $request->input('area_treated');
        $form_h1->current_crop = $request->input('current_crop');
        $form_h1->date_planted = $request->input('date_planted');
        $form_h1->eahd = $request->input('eahd');
        $form_h1->label_followed = ($request->input('label_followed') ? $request->input('label_followed') : false);
        $form_h1->method_of_application = $request->input('method_of_application');
        $form_h1->operation_name = $request->input('operation_name');
        $form_h1->pcp = $request->input('pcp');
        $form_h1->phi_daa = $request->input('phi_daa');
        $form_h1->previous_year_crops = $request->input('previous_year_crops');
        $form_h1->product_site_information = $request->input('product_site_information');
        $form_h1->product_trade_name = $request->input('product_trade_name');
        $form_h1->production_site_area = $request->input('production_site_area');
        $form_h1->rate_applied = $request->input('rate_applied');
        $form_h1->seed_certificate = $request->input('seed_certificate');
        $form_h1->variety = $request->input('variety');
        $form_h1->weather_condition = $request->input('weather_condition');
        $form_h1->person_responsible = $request->input('person_responsible');
        $form_h1->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_h1()->save($form_h1);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormH1Record(Request $request)
    {
        $form_h1 = FormH1::find($request->input('id'));
        $form_h1->actual_quantity_used = $request->input('actual_quantity_used');
        $form_h1->area_treated = $request->input('area_treated');
        $form_h1->current_crop = $request->input('current_crop');
        $form_h1->date_planted = $request->input('date_planted');
        $form_h1->eahd = $request->input('eahd');
        $form_h1->label_followed = ($request->input('label_followed') ? $request->input('label_followed') : false);
        $form_h1->method_of_application = $request->input('method_of_application');
        $form_h1->operation_name = $request->input('operation_name');
        $form_h1->pcp = $request->input('pcp');
        $form_h1->phi_daa = $request->input('phi_daa');
        $form_h1->previous_year_crops = $request->input('previous_year_crops');
        $form_h1->product_site_information = $request->input('product_site_information');
        $form_h1->product_trade_name = $request->input('product_trade_name');
        $form_h1->production_site_area = $request->input('production_site_area');
        $form_h1->rate_applied = $request->input('rate_applied');
        $form_h1->seed_certificate = $request->input('seed_certificate');
        $form_h1->variety = $request->input('variety');
        $form_h1->weather_condition = $request->input('weather_condition');
        $form_h1->person_responsible = $request->input('person_responsible');
        $form_h1->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_h1()->save($form_h1);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormH1Record(Request $request)
    {
        $form_h1 = FormH1::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_h1' => $form_h1
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormH2Record(Request $request)
    {
        $form_h2 = new FormH2();
        $form_h2->blend = $request->input('blend');
        $form_h2->commercial_rate = $request->input('commercial_rate');
        $form_h2->current_crop = $request->input('current_crop');
        $form_h2->date_planted = $request->input('date_planted');
        $form_h2->fertilizer_lot_num = $request->input('fertilizer_lot_num');
        $form_h2->manure_rate = $request->input('manure_rate');
        $form_h2->operation_name = $request->input('operation_name');
        $form_h2->previous_year_crops = $request->input('previous_year_crops');
        $form_h2->product_site_information = $request->input('product_site_information');
        $form_h2->production_site_area = $request->input('production_site_area');
        $form_h2->seed_certificate = $request->input('seed_certificate');
        $form_h2->supplier_name = $request->input('supplier_name');
        $form_h2->type = $request->input('type');
        $form_h2->variety = $request->input('variety');
        $form_h2->what_is_applied = $request->input('what_is_applied');
        $form_h2->earliest_harvest_date = $request->input('earliest_harvest_date');
        $form_h2->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_h2()->save($form_h2);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormH2Record(Request $request)
    {
        $form_h2 = FormH2::find($request->input('id'));
        $form_h2->blend = $request->input('blend');
        $form_h2->commercial_rate = $request->input('commercial_rate');
        $form_h2->current_crop = $request->input('current_crop');
        $form_h2->date_planted = $request->input('date_planted');
        $form_h2->fertilizer_lot_num = $request->input('fertilizer_lot_num');
        $form_h2->manure_rate = $request->input('manure_rate');
        $form_h2->operation_name = $request->input('operation_name');
        $form_h2->previous_year_crops = $request->input('previous_year_crops');
        $form_h2->product_site_information = $request->input('product_site_information');
        $form_h2->production_site_area = $request->input('production_site_area');
        $form_h2->seed_certificate = $request->input('seed_certificate');
        $form_h2->supplier_name = $request->input('supplier_name');
        $form_h2->type = $request->input('type');
        $form_h2->variety = $request->input('variety');
        $form_h2->what_is_applied = $request->input('what_is_applied');
        $form_h2->earliest_harvest_date = $request->input('earliest_harvest_date');
        $form_h2->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_h2()->save($form_h2);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormH2Record(Request $request)
    {
        $form_h2 = FormH2::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_h2' => $form_h2
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormP2Record(Request $request) {
        $form_p2 = new FormP2();
        $form_p2->field_block = $request->input('field_block');
        $form_p2->packaging_material = $request->input('packaging_material');
        $form_p2->phi_eahd_daa = $request->input('phi_eahd_daa');
        $form_p2->product_variety = $request->input('product_variety');
        $form_p2->production_assessed = $request->input('production_assessed');
        $form_p2->quantity = $request->input('quantity');
        $form_p2->storage_id = $request->input('storage_id');
        $form_p2->harvest_date = $request->input('harvest_date');
        $form_p2->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_p2()->save($form_p2);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormP2Record(Request $request) {
        $form_p2 = FormP2::find($request->input('id'));
        $form_p2->field_block = $request->input('field_block');
        $form_p2->packaging_material = $request->input('packaging_material');
        $form_p2->phi_eahd_daa = $request->input('phi_eahd_daa');
        $form_p2->product_variety = $request->input('product_variety');
        $form_p2->production_assessed = $request->input('production_assessed');
        $form_p2->quantity = $request->input('quantity');
        $form_p2->storage_id = $request->input('storage_id');
        $form_p2->harvest_date = $request->input('harvest_date');
        $form_p2->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_p2()->save($form_p2);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormP2Record(Request $request)
    {
        $form_p2 = FormP2::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_p2' => $form_p2
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormFRecord(Request $request) {
        $form_f = new FormF();
        $form_f->animal_access = (isset($request->input('data')['animal_access']) ? ($request->input('data')['animal_access'] == "true" ? true : false) : false);
        $form_f->appendix_a = (isset($request->input('data')['appendix_a']) ? ($request->input('data')['appendix_a'] == "true" ? true : false) : false);
        $form_f->appendix_b = (isset($request->input('data')['appendix_b']) ? ($request->input('data')['appendix_b'] == "true" ? true : false) : false);
        $form_f->appendix_h = (isset($request->input('data')['appendix_h']) ? ($request->input('data')['appendix_h'] == "true" ? true : false) : false);
        $form_f->appendix_or = (isset($request->input('data')['appendix_or']) ? $request->input('appendix_or') : "");
        $form_f->chemical_application = (isset($request->input('data')['chemical_application']) ? ($request->input('data')['chemical_application'] == "true" ? true : false) : false);
        $form_f->cistern = (isset($request->input('data')['cistern']) ? ($request->input('data')['cistern'] == "true" ? true : false) : false);
        $form_f->cleaned = (isset($request->input('data')['cleaned']) ? ($request->input('data')['cleaned'] == "true" ? true : false) : false);
        $form_f->commodity = (isset($request->input('data')['commodity']) ? $request->input('data')['commodity'] : "");
        $form_f->cooling = (isset($request->input('data')['cooling']) ? ($request->input('data')['cooling'] == "true" ? true : false) : false);
        $form_f->drenching = (isset($request->input('data')['drenching']) ? ($request->input('data')['drenching'] == "true" ? true : false) : false);
        $form_f->dump_tank = (isset($request->input('data')['dump_tank']) ? ($request->input('data')['dump_tank'] == "true" ? true : false) : false);
        $form_f->equipment_container = (isset($request->input('data')['equipment_container']) ? ($request->input('data')['equipment_container'] == "true" ? true : false) : false);
        $form_f->final_rinse = (isset($request->input('data')['final_rinse']) ? ($request->input('data')['final_rinse'] == "true" ? true : false) : false);
        $form_f->fluming = (isset($request->input('data')['fluming']) ? ($request->input('data')['fluming'] == "true" ? true : false) : false);
        $form_f->hand_washing = (isset($request->input('data')['hand_washing']) ? ($request->input('data')['hand_washing'] == "true" ? true : false) : false);
        $form_f->hose = (isset($request->input('data')['hose']) ? ($request->input('data')['hose'] == "true" ? true : false) : false);
        $form_f->humidity = (isset($request->input('data')['humidity']) ? ($request->input('data')['humidity'] == "true" ? true : false) : false);
        $form_f->ice = (isset($request->input('data')['ice']) ? ($request->input('data')['ice'] == "true" ? true : false) : false);
        $form_f->other = (isset($request->input('data')['other']) ? ($request->input('data')['other'] == "true" ? true : false) : false);
        $form_f->other_method = (isset($request->input('data')['other_method']) ? $request->input('data')['other_method'] : "");
        $form_f->other_possible = (isset($request->input('data')['other_possible']) ? ($request->input('data')['other_possible'] == "true" ? true : false) : false);
        $form_f->other_possible_hazard = (isset($request->input('data')['other_possible_hazard']) ? $request->input('data')['other_possible_hazard'] : "");
        $form_f->pit = (isset($request->input('data')['pit']) ? ($request->input('data')['pit'] == "true" ? true : false) : false);
        $form_f->pressure_wash = (isset($request->input('data')['pressure_wash']) ? ($request->input('data')['pressure_wash'] == "true" ? true : false) : false);
        $form_f->recycled = (isset($request->input('data')['recycled']) ? ($request->input('data')['recycled'] == "true" ? true : false) : false);
        $form_f->runoff = (isset($request->input('data')['runoff']) ? ($request->input('data')['runoff'] == "true" ? true : false) : false);
        $form_f->spray = (isset($request->input('data')['spray']) ? ($request->input('data')['spray'] == "true" ? true : false) : false);
        $form_f->stored = (isset($request->input('data')['stored']) ? ($request->input('data')['stored'] == "true" ? true : false) : false);
        $form_f->tap = (isset($request->input('data')['tap']) ? ($request->input('data')['tap'] == "true" ? true : false) : false);
        $form_f->treated = (isset($request->input('data')['treated']) ? ($request->input('data')['treated'] == "true" ? true : false) : false);
        $form_f->washing = (isset($request->input('data')['washing']) ? ($request->input('data')['washing'] == "true" ? true : false) : false);
        $form_f->water_first_used = (isset($request->input('data')['water_first_used']) ? $request->input('data')['water_first_used'] : "");
        $form_f->water_prior_test = (isset($request->input('data')['water_prior_test']) ? $request->input('data')['water_prior_test'] : "");
        $form_f->water_second_test = (isset($request->input('data')['water_second_test']) ? $request->input('data')['water_second_test'] : "");
        $form_f->water_source = (isset($request->input('data')['water_source']) ? $request->input('data')['water_source'] : "");
        $form_f->well = (isset($request->input('data')['well']) ? ($request->input('data')['well'] == "true" ? true : false) : false);
        $form_f->wetting = (isset($request->input('data')['wetting']) ? ($request->input('data')['wetting'] == "true" ? true : false) : false);
        $form_f->working_condition = (isset($request->input('data')['working_condition']) ? ($request->input('data')['working_condition'] == "true" ? true : false) : false);
        $form_f->actions = (isset($request->input('data')['actions']) ? $request->input('data')['actions'] : "");
        $form_f->other_cleaning = (isset($request->input('data')['other_cleaning']) ? ($request->input('data')['other_cleaning'] == "true" ? true : false) : false);
        $form_f->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_f()->save($form_f);
        
        if(isset($request->file('files')[0])) {
            foreach($request->file('files')[0] as $wtFile) {
                $form_fwt = new \App\Models\FormFWaterTests();
                $form_fwt->mime = $wtFile->getClientMimeType();
                $form_fwt->size = $wtFile->getClientSize();
                $form_fwt->storage_path = "gapapp_form_f_water_tests/" . $wtFile->getFilename() . '.' . $wtFile->guessClientExtension();
                $form_fwt->filename = $wtFile->getFilename() . '.' . $wtFile->guessClientExtension();
                $form_fwt->disk = "s3";
                $form_fwt->status = true;
                Storage::disk('s3')->put('gapapp_form_f_water_tests/' . $wtFile->getFilename() . '.' . $wtFile->guessClientExtension(), $wtFile->__toString());
                $form_fwt->user_id = Auth::user()->id;
                $org = Organization::find(Auth::user()->organizations()->first()->id);
                $form_fwt->organization_id = $org->id;
                $form_fwt->form_f_id = $form_f->id;
                $form_fwt->save();
            }
        }

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormFRecord(Request $request) {
        $form_f = FormF::find($request->input('data')['id']);
        $form_f->animal_access = (isset($request->input('data')['animal_access']) ? ($request->input('data')['animal_access'] == "true" ? true : false) : false);
        $form_f->appendix_a = (isset($request->input('data')['appendix_a']) ? ($request->input('data')['appendix_a'] == "true" ? true : false) : false);
        $form_f->appendix_b = (isset($request->input('data')['appendix_b']) ? ($request->input('data')['appendix_b'] == "true" ? true : false) : false);
        $form_f->appendix_h = (isset($request->input('data')['appendix_h']) ? ($request->input('data')['appendix_h'] == "true" ? true : false) : false);
        $form_f->appendix_or = (isset($request->input('data')['appendix_or']) ? $request->input('appendix_or') : "");
        $form_f->chemical_application = (isset($request->input('data')['chemical_application']) ? ($request->input('data')['chemical_application'] == "true" ? true : false) : false);
        $form_f->cistern = (isset($request->input('data')['cistern']) ? ($request->input('data')['cistern'] == "true" ? true : false) : false);
        $form_f->cleaned = (isset($request->input('data')['cleaned']) ? ($request->input('data')['cleaned'] == "true" ? true : false) : false);
        $form_f->commodity = (isset($request->input('data')['commodity']) ? $request->input('data')['commodity'] : "");
        $form_f->cooling = (isset($request->input('data')['cooling']) ? ($request->input('data')['cooling'] == "true" ? true : false) : false);
        $form_f->drenching = (isset($request->input('data')['drenching']) ? ($request->input('data')['drenching'] == "true" ? true : false) : false);
        $form_f->dump_tank = (isset($request->input('data')['dump_tank']) ? ($request->input('data')['dump_tank'] == "true" ? true : false) : false);
        $form_f->equipment_container = (isset($request->input('data')['equipment_container']) ? ($request->input('data')['equipment_container'] == "true" ? true : false) : false);
        $form_f->final_rinse = (isset($request->input('data')['final_rinse']) ? ($request->input('data')['final_rinse'] == "true" ? true : false) : false);
        $form_f->fluming = (isset($request->input('data')['fluming']) ? ($request->input('data')['fluming'] == "true" ? true : false) : false);
        $form_f->hand_washing = (isset($request->input('data')['hand_washing']) ? ($request->input('data')['hand_washing'] == "true" ? true : false) : false);
        $form_f->hose = (isset($request->input('data')['hose']) ? ($request->input('data')['hose'] == "true" ? true : false) : false);
        $form_f->humidity = (isset($request->input('data')['humidity']) ? ($request->input('data')['humidity'] == "true" ? true : false) : false);
        $form_f->ice = (isset($request->input('data')['ice']) ? ($request->input('data')['ice'] == "true" ? true : false) : false);
        $form_f->other = (isset($request->input('data')['other']) ? ($request->input('data')['other'] == "true" ? true : false) : false);
        $form_f->other_method = (isset($request->input('data')['other_method']) ? $request->input('data')['other_method'] : "");
        $form_f->other_possible = (isset($request->input('data')['other_possible']) ? ($request->input('data')['other_possible'] == "true" ? true : false) : false);
        $form_f->other_possible_hazard = (isset($request->input('data')['other_possible_hazard']) ? $request->input('data')['other_possible_hazard'] : "");
        $form_f->pit = (isset($request->input('data')['pit']) ? ($request->input('data')['pit'] == "true" ? true : false) : false);
        $form_f->pressure_wash = (isset($request->input('data')['pressure_wash']) ? ($request->input('data')['pressure_wash'] == "true" ? true : false) : false);
        $form_f->recycled = (isset($request->input('data')['recycled']) ? ($request->input('data')['recycled'] == "true" ? true : false) : false);
        $form_f->runoff = (isset($request->input('data')['runoff']) ? ($request->input('data')['runoff'] == "true" ? true : false) : false);
        $form_f->spray = (isset($request->input('data')['spray']) ? ($request->input('data')['spray'] == "true" ? true : false) : false);
        $form_f->stored = (isset($request->input('data')['stored']) ? ($request->input('data')['stored'] == "true" ? true : false) : false);
        $form_f->tap = (isset($request->input('data')['tap']) ? ($request->input('data')['tap'] == "true" ? true : false) : false);
        $form_f->treated = (isset($request->input('data')['treated']) ? ($request->input('data')['treated'] == "true" ? true : false) : false);
        $form_f->washing = (isset($request->input('data')['washing']) ? ($request->input('data')['washing'] == "true" ? true : false) : false);
        $form_f->water_first_used = (isset($request->input('data')['water_first_used']) ? $request->input('data')['water_first_used'] : "");
        $form_f->water_prior_test = (isset($request->input('data')['water_prior_test']) ? $request->input('data')['water_prior_test'] : "");
        $form_f->water_second_test = (isset($request->input('data')['water_second_test']) ? $request->input('data')['water_second_test'] : "");
        $form_f->water_source = (isset($request->input('data')['water_source']) ? $request->input('data')['water_source'] : "");
        $form_f->well = (isset($request->input('data')['well']) ? ($request->input('data')['well'] == "true" ? true : false) : false);
        $form_f->wetting = (isset($request->input('data')['wetting']) ? ($request->input('data')['wetting'] == "true" ? true : false) : false);
        $form_f->working_condition = (isset($request->input('data')['working_condition']) ? ($request->input('data')['working_condition'] == "true" ? true : false) : false);
        $form_f->actions = (isset($request->input('data')['actions']) ? $request->input('data')['actions'] : "");
        $form_f->other_cleaning = (isset($request->input('data')['other_cleaning']) ? ($request->input('data')['other_cleaning'] == "true" ? true : false) : false);
        $form_f->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_f()->save($form_f);
        
        if(isset($request->file('files')[0])) {
            foreach($request->file('files')[0] as $wtFile) {
                $form_fwt = new \App\Models\FormFWaterTests();
                $form_fwt->mime = $wtFile->getClientMimeType();
                $form_fwt->size = $wtFile->getClientSize();
                $form_fwt->storage_path = "gapapp_form_f_water_tests/" . $wtFile->getFilename() . '.' . $wtFile->guessClientExtension();
                $form_fwt->filename = $wtFile->getFilename() . '.' . $wtFile->guessClientExtension();
                $form_fwt->disk = "s3";
                $form_fwt->status = true;
                Storage::disk('s3')->put('gapapp_form_f_water_tests/' . $wtFile->getFilename() . '.' . $wtFile->guessClientExtension(), $wtFile->__toString());
                $form_fwt->user_id = Auth::user()->id;
                $org = Organization::find(Auth::user()->organizations()->first()->id);
                $form_fwt->organization_id = $org->id;
                $form_fwt->form_f_id = $form_f->id;
                $form_fwt->save();
            }
        }

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    

    public function getFormFRecord(Request $request)
    {
        $form_f = FormF::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();
        $tests = \App\Models\FormFWaterTests::where('form_f_id', $request->input('id'))->get();

        $success = [
            'code' => 200,
            'form_f' => $form_f,
            'tests' => $tests
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormRRecord(Request $request) {
        /*$form_r = new FormR();
        $form_r->incident_id = $request->input('incidentID');
        $form_r->major_deviation = $request->input('form')['major_deviation'];
        $form_r->cause_of_deviation = $request->input('form')['cause_of_deviation'];
        $form_r->corrective_action = $request->input('form')['corrective_action'];

        if($request->input('deviationType') == '1') {
            $form_r->prevention_of_recurrence = $request->input('form')['prevention_of_recurrence'];
            $form_r->modified_procedure = $request->input('form')['modified_procedure'];
            //$form_r->employee_trained = ($request->input('form')['employee_trained'] == 1 ? true : false);
        }

        $form_r->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_r()->save($form_r);

        if($request->input('deviationType') == '2') {
            $incident = Incident::find($request->input('incidentID'));
            $incident->resolved = true;
            $incident->save();
        }*/

        $incident = Incident::find($request->input('incidentID'));
        $form_r = new FormR();
        if($request->input('form')['is_trained']) {
            $incident->is_trained = $request->input('form')['is_trained'];
            $incident->resolved = true;
            $incident->save();

            $form_r->incident_id = $incident->id;
            $form_r->major_deviation = $incident->description;
            $form_r->cause_of_deviation = $incident->cause_deviation;
            $form_r->corrective_action = $incident->corrective_action;
            $form_r->prevention_of_recurrence = $incident->prevention_recurrence;
            $form_r->modified_procedure  = $incident->modified_procedure;
            $form_r->employee_trained = $incident->is_trained;
            $form_r->user_id = Auth::user()->id;
            $org = Organization::find(Auth::user()->organizations()->first()->id);
            $org->forms_r()->save($form_r);
        }

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function resolveFormRRecord(Request $request) {
        $form_r = FormR::find($request->input('id'));
        $form_r->employee_trained = $request->input('form')['employee_trained'];
        $form_r->save();

        $incident = Incident::find($form_r->incident_id);
        $incident->resolved = true;
        $incident->save();

        $success = [
            'code' => 200,
            "message" => "Incident resolved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormQRecord(Request $request)
    {
        $form_q = FormQ::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_q' => $form_q
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormQRecord(Request $request) {
        $form_q = new FormQ();
        $form_q->date_harvested = $request->input('date_harvested');
        $form_q->field_block_tag = $request->input('field_block_tag');
        $form_q->harvest_date = $request->input('harvest_date');
        $form_q->incoming_pack = $request->input('incoming_pack');
        $form_q->lot_id = $request->input('lot_id');
        $form_q->market_product_storage = $request->input('market_product_storage');
        $form_q->name_produced = $request->input('name_produced');
        $form_q->outgoing_pack_id = $request->input('outgoing_pack_id');
        $form_q->packaging_checked = $request->input('packaging_checked');
        $form_q->phi_eahd = ($request->input('phi_eahd') == "true" ? true : false);
        $form_q->primary_package = $request->input('primary_package');
        $form_q->product_variety = $request->input('product_variety');
        $form_q->production_site_assesed = ($request->input('production_site_assesed') == "true" ? true : false);
        $form_q->secondary_package = $request->input('secondary_package');
        $form_q->quantity = $request->input('quantity');
        $form_q->wax_lot = $request->input('wax_lot');
        $form_q->packing_repacking = $request->input('packing_repacking');
        $form_q->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_q()->save($form_q);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormQRecord(Request $request) {
        $form_q = FormQ::find($request->input('id'));
        $form_q->date_harvested = $request->input('date_harvested');
        $form_q->field_block_tag = $request->input('field_block_tag');
        $form_q->harvest_date = $request->input('harvest_date');
        $form_q->incoming_pack = $request->input('incoming_pack');
        $form_q->lot_id = $request->input('lot_id');
        $form_q->market_product_storage = $request->input('market_product_storage');
        $form_q->name_produced = $request->input('name_produced');
        $form_q->outgoing_pack_id = $request->input('outgoing_pack_id');
        $form_q->packaging_checked = $request->input('packaging_checked');
        $form_q->phi_eahd = ($request->input('phi_eahd') == "true" ? true : false);
        $form_q->primary_package = $request->input('primary_package');
        $form_q->product_variety = $request->input('product_variety');
        $form_q->production_site_assesed = ($request->input('production_site_assesed') == "true" ? true : false);
        $form_q->secondary_package = $request->input('secondary_package');
        $form_q->quantity = $request->input('quantity');
        $form_q->wax_lot = $request->input('wax_lot');
        $form_q->packing_repacking = $request->input('packing_repacking');
        $form_q->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_q()->save($form_q);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormSRecord(Request $request)
    {
        $form_s = FormS::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_s' => $form_s
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormSRecord(Request $request) {
        $form_s = new FormS();
        $form_s->cereals_1 = $request->input('cereals_1');
        $form_s->cereals_2 = $request->input('cereals_2');
        $form_s->cereals_3 = $request->input('cereals_3');
        $form_s->cereals_4 = $request->input('cereals_4');
        $form_s->cereals_5 = $request->input('cereals_5');
        $form_s->comments = $request->input('comments');
        $form_s->eggs_1 = $request->input('eggs_1');
        $form_s->eggs_2 = $request->input('eggs_2');
        $form_s->eggs_3 = $request->input('eggs_3');
        $form_s->eggs_4 = $request->input('eggs_4');
        $form_s->eggs_5 = $request->input('eggs_5');
        $form_s->fish_1 = $request->input('fish_1');
        $form_s->fish_2 = $request->input('fish_2');
        $form_s->fish_3 = $request->input('fish_3');
        $form_s->fish_4 = $request->input('fish_4');
        $form_s->fish_5 = $request->input('fish_5');
        $form_s->milk_1 = $request->input('milk_1');
        $form_s->milk_2 = $request->input('milk_2');
        $form_s->milk_3 = $request->input('milk_3');
        $form_s->milk_4 = $request->input('milk_4');
        $form_s->milk_5 = $request->input('milk_5');
        $form_s->others_1 = $request->input('others_1');
        $form_s->others_2 = $request->input('others_2');
        $form_s->others_3 = $request->input('others_3');
        $form_s->others_4 = $request->input('others_4');
        $form_s->others_5 = $request->input('others_5');
        $form_s->peanut_1 = $request->input('peanut_1');
        $form_s->peanut_2 = $request->input('peanut_2');
        $form_s->peanut_3 = $request->input('peanut_3');
        $form_s->peanut_4 = $request->input('peanut_4');
        $form_s->peanut_5 = $request->input('peanut_5');
        $form_s->sesame_1 = $request->input('sesame_1');
        $form_s->sesame_2 = $request->input('sesame_2');
        $form_s->sesame_3 = $request->input('sesame_3');
        $form_s->sesame_4 = $request->input('sesame_4');
        $form_s->sesame_5 = $request->input('sesame_5');
        $form_s->shellfish_molluscs_1 = $request->input('shellfish_molluscs_1');
        $form_s->shellfish_molluscs_2 = $request->input('shellfish_molluscs_2');
        $form_s->shellfish_molluscs_3 = $request->input('shellfish_molluscs_3');
        $form_s->shellfish_molluscs_4 = $request->input('shellfish_molluscs_4');
        $form_s->shellfish_molluscs_5 = $request->input('shellfish_molluscs_5');
        $form_s->soybeans_1 = $request->input('soybeans_1');
        $form_s->soybeans_2 = $request->input('soybeans_2');
        $form_s->soybeans_3 = $request->input('soybeans_3');
        $form_s->soybeans_4 = $request->input('soybeans_4');
        $form_s->soybeans_5 = $request->input('soybeans_5');
        $form_s->storage_id = $request->input('storage_id');
        $form_s->sulphites_1 = $request->input('sulphites_1');
        $form_s->sulphites_2 = $request->input('sulphites_2');
        $form_s->sulphites_3 = $request->input('sulphites_3');
        $form_s->sulphites_4 = $request->input('sulphites_4');
        $form_s->sulphites_5 = $request->input('sulphites_5');
        $form_s->tree_nuts_1 = $request->input('tree_nuts_1');
        $form_s->tree_nuts_2 = $request->input('tree_nuts_2');
        $form_s->tree_nuts_3 = $request->input('tree_nuts_3');
        $form_s->tree_nuts_4 = $request->input('tree_nuts_4');
        $form_s->tree_nuts_5 = $request->input('tree_nuts_5');
        $form_s->mustard_1 = $request->input('mustard_1');
        $form_s->mustard_2 = $request->input('mustard_2');
        $form_s->mustard_3 = $request->input('mustard_3');
        $form_s->mustard_4 = $request->input('mustard_4');
        $form_s->mustard_5 = $request->input('mustard_5');
        $form_s->storage_id = $request->input('storage_id');
        $form_s->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_s()->save($form_s);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormSRecord(Request $request) {
        $form_s = FormS::find($request->input('id'));
        $form_s->cereals_1 = $request->input('cereals_1');
        $form_s->cereals_2 = $request->input('cereals_2');
        $form_s->cereals_3 = $request->input('cereals_3');
        $form_s->cereals_4 = $request->input('cereals_4');
        $form_s->cereals_5 = $request->input('cereals_5');
        $form_s->comments = $request->input('comments');
        $form_s->eggs_1 = $request->input('eggs_1');
        $form_s->eggs_2 = $request->input('eggs_2');
        $form_s->eggs_3 = $request->input('eggs_3');
        $form_s->eggs_4 = $request->input('eggs_4');
        $form_s->eggs_5 = $request->input('eggs_5');
        $form_s->fish_1 = $request->input('fish_1');
        $form_s->fish_2 = $request->input('fish_2');
        $form_s->fish_3 = $request->input('fish_3');
        $form_s->fish_4 = $request->input('fish_4');
        $form_s->fish_5 = $request->input('fish_5');
        $form_s->milk_1 = $request->input('milk_1');
        $form_s->milk_2 = $request->input('milk_2');
        $form_s->milk_3 = $request->input('milk_3');
        $form_s->milk_4 = $request->input('milk_4');
        $form_s->milk_5 = $request->input('milk_5');
        $form_s->others_1 = $request->input('others_1');
        $form_s->others_2 = $request->input('others_2');
        $form_s->others_3 = $request->input('others_3');
        $form_s->others_4 = $request->input('others_4');
        $form_s->others_5 = $request->input('others_5');
        $form_s->peanut_1 = $request->input('peanut_1');
        $form_s->peanut_2 = $request->input('peanut_2');
        $form_s->peanut_3 = $request->input('peanut_3');
        $form_s->peanut_4 = $request->input('peanut_4');
        $form_s->peanut_5 = $request->input('peanut_5');
        $form_s->sesame_1 = $request->input('sesame_1');
        $form_s->sesame_2 = $request->input('sesame_2');
        $form_s->sesame_3 = $request->input('sesame_3');
        $form_s->sesame_4 = $request->input('sesame_4');
        $form_s->sesame_5 = $request->input('sesame_5');
        $form_s->shellfish_molluscs_1 = $request->input('shellfish_molluscs_1');
        $form_s->shellfish_molluscs_2 = $request->input('shellfish_molluscs_2');
        $form_s->shellfish_molluscs_3 = $request->input('shellfish_molluscs_3');
        $form_s->shellfish_molluscs_4 = $request->input('shellfish_molluscs_4');
        $form_s->shellfish_molluscs_5 = $request->input('shellfish_molluscs_5');
        $form_s->soybeans_1 = $request->input('soybeans_1');
        $form_s->soybeans_2 = $request->input('soybeans_2');
        $form_s->soybeans_3 = $request->input('soybeans_3');
        $form_s->soybeans_4 = $request->input('soybeans_4');
        $form_s->soybeans_5 = $request->input('soybeans_5');
        $form_s->storage_id = $request->input('storage_id');
        $form_s->sulphites_1 = $request->input('sulphites_1');
        $form_s->sulphites_2 = $request->input('sulphites_2');
        $form_s->sulphites_3 = $request->input('sulphites_3');
        $form_s->sulphites_4 = $request->input('sulphites_4');
        $form_s->sulphites_5 = $request->input('sulphites_5');
        $form_s->tree_nuts_1 = $request->input('tree_nuts_1');
        $form_s->tree_nuts_2 = $request->input('tree_nuts_2');
        $form_s->tree_nuts_3 = $request->input('tree_nuts_3');
        $form_s->tree_nuts_4 = $request->input('tree_nuts_4');
        $form_s->tree_nuts_5 = $request->input('tree_nuts_5');
        $form_s->mustard_1 = $request->input('mustard_1');
        $form_s->mustard_2 = $request->input('mustard_2');
        $form_s->mustard_3 = $request->input('mustard_3');
        $form_s->mustard_4 = $request->input('mustard_4');
        $form_s->mustard_5 = $request->input('mustard_5');
        $form_s->storage_id = $request->input('storage_id');
        $form_s->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_s()->save($form_s);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function createFormERecord(Request $request) {
        $form_e = new FormE();
        $form_e->rodents_chemical_list = json_encode($request->input('rodents')['chemicals_list']);
        $form_e->rodents_exterior_bait = (isset($request->input('rodents')['exterior_bait']) ? ($request->input('rodents')['exterior_bait'] == '1' ? true : false) : false);
        $form_e->rodents_exterior_traps = (isset($request->input('rodents')['exterior_traps']) ? ($request->input('rodents')['exterior_traps'] == '1' ? true : false) : false);
        $form_e->rodents_chemicals = (isset($request->input('rodents')['chemicals']) ? ($request->input('rodents')['chemicals'] == '1' ? true : false) : false);
        $form_e->rodents_exterior_other = (isset($request->input('rodents')['exterior_other']) ? ($request->input('rodents')['exterior_other'] == '1' ? true : false) : false);
        $form_e->rodents_inside_traps = (isset($request->input('rodents')['inside_traps']) ? ($request->input('rodents')['inside_traps'] == '1' ? true : false) : false);
        $form_e->rodents_inside_other = (isset($request->input('rodents')['inside_other']) ? ($request->input('rodents')['inside_other'] == '1' ? true : false) : false);
        $form_e->rodents_exterior_bait_type = (isset($request->input('rodents')['exterior_bait_type']) ? $request->input('rodents')['exterior_bait_type'] : null);
        $form_e->rodents_exterior_traps_type = (isset($request->input('rodents')['exterior_traps_type']) ? $request->input('rodents')['exterior_traps_type'] : null);
        $form_e->rodents_exterior_other_info = (isset($request->input('rodents')['exterior_other_info']) ? $request->input('rodents')['exterior_other_info'] : null);
        $form_e->rodents_inside_traps_type = (isset($request->input('rodents')['inside_traps_type']) ? $request->input('rodents')['inside_traps_type'] : null);
        $form_e->rodents_inside_other_info = (isset($request->input('rodents')['inside_other_info']) ? $request->input('rodents')['inside_other_info'] : null);

        $form_e->exterior_chemicals_list = json_encode($request->input('insects')['exterior_chemicals_list']);
        $form_e->inside_chemicals_list = json_encode($request->input('insects')['inside_chemicals_list']);

        $form_e->insects_exterior_bait = (isset($request->input('insects')['exterior_bait']) ? ($request->input('insects')['exterior_bait'] == '1' ? true : false) : false);
        $form_e->insects_exterior_traps = (isset($request->input('insects')['exterior_traps']) ? ($request->input('insects')['exterior_traps'] == '1' ? true : false) : false);
        $form_e->insects_exterior_chemicals = (isset($request->input('insects')['exterior_chemicals']) ? ($request->input('insects')['exterior_chemicals'] == '1' ? true : false) : false);
        $form_e->insects_exterior_other = (isset($request->input('insects')['exterior_other']) ? ($request->input('insects')['exterior_other'] == '1' ? true : false) : false);
        $form_e->insects_inside_traps = (isset($request->input('insects')['inside_traps']) ? ($request->input('insects')['inside_traps'] == '1' ? true : false) : false);
        $form_e->insects_inside_other = (isset($request->input('insects')['inside_other']) ? ($request->input('insects')['inside_other'] == '1' ? true : false) : false);
        $form_e->insects_inside_chemicals = (isset($request->input('insects')['inside_chemicals']) ? ($request->input('insects')['inside_chemicals'] == '1' ? true : false) : false);
        $form_e->insects_exterior_bait_type = (isset($request->input('insects')['exterior_bait_type']) ? $request->input('insects')['exterior_bait_type'] : null);
        $form_e->insects_exterior_traps_type = (isset($request->input('insects')['exterior_traps_type']) ? $request->input('insects')['exterior_traps_type'] : null);
        $form_e->insects_exterior_other_info = (isset($request->input('insects')['exterior_other_info']) ? $request->input('insects')['exterior_other_info'] : null);
        $form_e->insects_inside_traps_type = (isset($request->input('insects')['inside_traps_type']) ? $request->input('insects')['inside_traps_type'] : null);
        $form_e->insects_inside_other_info = (isset($request->input('insects')['inside_other_info']) ? $request->input('insects')['inside_other_info'] : null);

        $form_e->birds_exterior_devices = ($request->input('birds')['exterior_devices'] == '1' ? true : false);
        $form_e->birds_exterior_devices_info = (isset($request->input('birds')['exterior_devices_info']) ? $request->input('birds')['exterior_devices_info'] : null);
        $form_e->birds_inside_devices = ($request->input('birds')['inside_devices'] == '1' ? true : false);
        $form_e->birds_inside_devices_info = (isset($request->input('birds')['inside_devices_info']) ? $request->input('birds')['inside_devices_info'] : null);

        $form_e->other_information = (isset($request->input('other')['information']) ? $request->input('other')['information'] : null);

        $form_e->storage_id = $request->input('storage_id');
        $form_e->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_e()->save($form_e);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormERecord(Request $request) {
        $form_e = FormE::find($request->input('id'));
        $form_e->rodents_chemical_list = json_encode($request->input('rodents')['chemicals_list']);
        $form_e->rodents_exterior_bait = (isset($request->input('rodents')['exterior_bait']) ? ($request->input('rodents')['exterior_bait'] == '1' ? true : false) : false);
        $form_e->rodents_exterior_traps = (isset($request->input('rodents')['exterior_traps']) ? ($request->input('rodents')['exterior_traps'] == '1' ? true : false) : false);
        $form_e->rodents_chemicals = (isset($request->input('rodents')['chemicals']) ? ($request->input('rodents')['chemicals'] == '1' ? true : false) : false);
        $form_e->rodents_exterior_other = (isset($request->input('rodents')['exterior_other']) ? ($request->input('rodents')['exterior_other'] == '1' ? true : false) : false);
        $form_e->rodents_inside_traps = (isset($request->input('rodents')['inside_traps']) ? ($request->input('rodents')['inside_traps'] == '1' ? true : false) : false);
        $form_e->rodents_inside_other = (isset($request->input('rodents')['inside_other']) ? ($request->input('rodents')['inside_other'] == '1' ? true : false) : false);
        $form_e->rodents_exterior_bait_type = (isset($request->input('rodents')['exterior_bait_type']) ? $request->input('rodents')['exterior_bait_type'] : null);
        $form_e->rodents_exterior_traps_type = (isset($request->input('rodents')['exterior_traps_type']) ? $request->input('rodents')['exterior_traps_type'] : null);
        $form_e->rodents_exterior_other_info = (isset($request->input('rodents')['exterior_other_info']) ? $request->input('rodents')['exterior_other_info'] : null);
        $form_e->rodents_inside_traps_type = (isset($request->input('rodents')['inside_traps_type']) ? $request->input('rodents')['inside_traps_type'] : null);
        $form_e->rodents_inside_other_info = (isset($request->input('rodents')['inside_other_info']) ? $request->input('rodents')['inside_other_info'] : null);

        $form_e->exterior_chemicals_list = json_encode($request->input('insects')['exterior_chemicals_list']);
        $form_e->inside_chemicals_list = json_encode($request->input('insects')['inside_chemicals_list']);

        $form_e->insects_exterior_bait = (isset($request->input('insects')['exterior_bait']) ? ($request->input('insects')['exterior_bait'] == '1' ? true : false) : false);
        $form_e->insects_exterior_traps = (isset($request->input('insects')['exterior_traps']) ? ($request->input('insects')['exterior_traps'] == '1' ? true : false) : false);
        $form_e->insects_exterior_chemicals = (isset($request->input('insects')['exterior_chemicals']) ? ($request->input('insects')['exterior_chemicals'] == '1' ? true : false) : false);
        $form_e->insects_exterior_other = (isset($request->input('insects')['exterior_other']) ? ($request->input('insects')['exterior_other'] == '1' ? true : false) : false);
        $form_e->insects_inside_traps = (isset($request->input('insects')['inside_traps']) ? ($request->input('insects')['inside_traps'] == '1' ? true : false) : false);
        $form_e->insects_inside_other = (isset($request->input('insects')['inside_other']) ? ($request->input('insects')['inside_other'] == '1' ? true : false) : false);
        $form_e->insects_inside_chemicals = (isset($request->input('insects')['inside_chemicals']) ? ($request->input('insects')['inside_chemicals'] == '1' ? true : false) : false);
        $form_e->insects_exterior_bait_type = (isset($request->input('insects')['exterior_bait_type']) ? $request->input('insects')['exterior_bait_type'] : null);
        $form_e->insects_exterior_traps_type = (isset($request->input('insects')['exterior_traps_type']) ? $request->input('insects')['exterior_traps_type'] : null);
        $form_e->insects_exterior_other_info = (isset($request->input('insects')['exterior_other_info']) ? $request->input('insects')['exterior_other_info'] : null);
        $form_e->insects_inside_traps_type = (isset($request->input('insects')['inside_traps_type']) ? $request->input('insects')['inside_traps_type'] : null);
        $form_e->insects_inside_other_info = (isset($request->input('insects')['inside_other_info']) ? $request->input('insects')['inside_other_info'] : null);

        $form_e->birds_exterior_devices = ($request->input('birds')['exterior_devices'] == '1' ? true : false);
        $form_e->birds_exterior_devices_info = (isset($request->input('birds')['exterior_devices_info']) ? $request->input('birds')['exterior_devices_info'] : null);
        $form_e->birds_inside_devices = ($request->input('birds')['inside_devices'] == '1' ? true : false);
        $form_e->birds_inside_devices_info = (isset($request->input('birds')['inside_devices_info']) ? $request->input('birds')['inside_devices_info'] : null);

        $form_e->other_information = (isset($request->input('other')['information']) ? $request->input('other')['information'] : null);

        $form_e->storage_id = $request->input('storage_id');
        $form_e->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_e()->save($form_e);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormERecord(Request $request)
    {
        $form_e = FormE::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_e' => $form_e
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormP1Record(Request $request) {
        $form_p1 = new FormP1();
        $form_p1->storage_id = $request->input('storage_id');
        $form_p1->application_rate = $request->input('first')['application_rate'];
        $form_p1->bin_fill_date = $request->input('first')['bin_fill_date'];
        $form_p1->cross_section = $request->input('first')['cross_section'];
        $form_p1->harvest_date = $request->input('first')['harvest_date'];
        $form_p1->method_of_application = $request->input('first')['method_of_application'];
        $form_p1->phi_eahd_daa = ($request->input('first')['phi_eahd_daa'] == 'true' ? true : false);
        $form_p1->product_name = $request->input('first')['product_name'];
        $form_p1->production_site_assessed = ($request->input('first')['production_site_assessed'] == 'true' ? true : false);
        $form_p1->quantity_treated = $request->input('first')['quantity_treated'];
        $form_p1->variety = $request->input('first')['variety'];
        $form_p1->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_p1()->save($form_p1);

        $success = [
            'code' => 200,
            "message" => "New Record added successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function saveFormP1Record(Request $request) {
        $form_p1 = FormP1::find($request->input('id'));
        $form_p1->storage_id = $request->input('storage_id');
        $form_p1->application_rate = $request->input('first')['application_rate'];
        $form_p1->bin_fill_date = $request->input('first')['bin_fill_date'];
        $form_p1->cross_section = $request->input('first')['cross_section'];
        $form_p1->harvest_date = $request->input('first')['harvest_date'];
        $form_p1->method_of_application = $request->input('first')['method_of_application'];
        $form_p1->phi_eahd_daa = ($request->input('first')['phi_eahd_daa'] == 'true' ? true : false);
        $form_p1->product_name = $request->input('first')['product_name'];
        $form_p1->production_site_assessed = ($request->input('first')['production_site_assessed'] == 'true' ? true : false);
        $form_p1->quantity_treated = $request->input('first')['quantity_treated'];
        $form_p1->variety = $request->input('first')['variety'];
        $form_p1->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_p1()->save($form_p1);

        $success = [
            'code' => 200,
            "message" => "Record saved successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function getFormP1Record(Request $request)
    {
        $form_p1 = FormP1::where('id', $request->input('id'))->orderBy('created_at', 'DESC')->first();

        $success = [
            'code' => 200,
            'form_p1' => $form_p1
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function changeDeviationType(Request $request) {
        $incident = Incident::find($request->input('id'));

        if($incident->deviation_type == 2) {
            $incident->deviation_type = 1;
        } else {
            $incident->deviation_type = 2;
        }

        $log = new IncidentsLog();
        $log->incident_id = $incident->id;
        $log->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $log->organization_id = $org->id;
        $log->comments = "Deviation Type changed!";
        $log->save();


        $success = [
            'code' => 200,
            'isChanged' => $incident->save(),
            'message' => 'Deviation Type changed successfully!'
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function createFormARecord(Request $request) {
        $entity_id = $request->input('id');
        $file = $request->file('file')[0];

        $form_a = new FormA();
        $form_a->mime = $file->getClientMimeType();
        $form_a->size = $file->getClientSize();
        $form_a->storage_path = "gapapp_forma/" . $file->getFilename() . '.' . $file->guessClientExtension();
        $form_a->filename = $file->getFilename() . '.' . $file->guessClientExtension();
        $form_a->disk = "s3";
        $form_a->status = true;
        $form_a->entity_id = $entity_id;
        Storage::disk('s3')->put('gapapp_forma/' . $file->getFilename() . '.' . $file->guessClientExtension(), file_get_contents($file));
        $form_a->user_id = Auth::user()->id;
        $org = Organization::find(Auth::user()->organizations()->first()->id);
        $org->forms_a()->save($form_a);

        $success = [
            'code' => 200,
            'message' => 'Image Uploaded'
        ];

        return response()->json([
            'success' => $success
        ], 200);
    }

    public function confirmFormBRecord(Request $request) {
        $form_b = FormB::find($request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormCRecord(Request $request) {
        $form_c = FormC::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormDRecord(Request $request) {
        $form_d = FormD::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormERecord(Request $request) {
        $form_e = FormE::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormFRecord(Request $request) {
        $form_f = FormF::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormGRecord(Request $request) {
        $form_g = FormG::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormH1Record(Request $request) {
        $form_h1 = FormH1::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormH2Record(Request $request) {
        $form_h2 = FormH2::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormH3Record(Request $request) {
        $form_h3 = FormH3::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormIRecord(Request $request) {
        $form_i = FormI::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormJRecord(Request $request) {
        $form_j = FormJ::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormKRecord(Request $request) {
        $form_k = FormK::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormLRecord(Request $request) {
        $form_l = FormL::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormMRecord(Request $request) {
        $form_m = FormM::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormN1Record(Request $request) {
        $form_n1 = FormN1::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormN2Record(Request $request) {
        $form_n2 = FormN2::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormORecord(Request $request) {
        $form_o = FormO::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormP1Record(Request $request) {
        $form_p1 = FormP1::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormP2Record(Request $request) {
        $form_p2 = FormP2::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormQRecord(Request $request) {
        $form_q = FormQ::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormRRecord(Request $request) {
        $form_r = FormR::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormSRecord(Request $request) {
        $form_s = FormS::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }

    public function confirmFormTRecord(Request $request) {
        $form_t = FormT::where('id', $request->input('id'))->where('organization_id', $request->input('org'))->where('user_id', $request->input('user'))->update(array('is_completed' => true, 'confirmed_by_id' => Auth::user()->id));

        $success = [
            'code' => 200,
            "message" => "Record confirmed successfully!"
        ];

        return response()->json([
            'success' => $success
        ]);
    }
}
