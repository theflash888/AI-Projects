<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Models\Calendar;

class CalendarController extends Controller
{
    public function listEvents(Request $request) {
    	if($request->input('date')) {
    		$events = Calendar::where('date', '=', $request->input('date'))->get();
    		$success = [
    			'code' => 200,
    			'count' => $events->count(),
    			'events' => $events
    		];
    		return response()->json([
    			'success' => $success
    		], 200);
    	} else {
    		$error = [
    			'code' => 401,
    			'message' => 'date input invalid or not available'
    		];
    		return response()->json([ 'error' => $error], 401);
    	}
    }

    public function newEvent(Request $request) {
    	$calendar = new Calendar();
    	$calendar->date = $request->input('date');
    	$calendar->title = $request->input('title');
    	$calendar->type = $request->input('type');
    	if($request->input('description'))
    		$calendar->description = $request->input('description');
    	$calendar->organizations_id = 1;
    	$calendar->users_id = 1;
    	$calendar->save();
    	$success = [
    		'code' => 200,
    		'status' => 'created_event'
    	];
    	return response()->json([
    		'success' => $success
    	], 200);
    }
}
