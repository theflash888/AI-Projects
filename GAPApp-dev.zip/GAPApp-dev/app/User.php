<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Zizaco\Entrust\Traits\EntrustUserTrait;

class User extends Authenticatable
{
    use EntrustUserTrait;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    //protected $with = ['organizations.incidents'];

    public function organizations()
    {
        return $this->belongsToMany('App\Models\Organization');
    }

    public function currentOrganizations()
    {
        return $this->belongsTo('App\Models\Organization', 'organization_id');
    }

    public function incidents()
    {
        return $this->hasMany('App\Models\Incident');
    }

    public function calendar()
    {
        return $this->belongTo('App\Models\calendar', 'id');
    }
}
