<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * Incidents
 *
 * @ORM\Table(name="incidents", indexes={@ORM\Index(name="incidents_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="incidents_user_id_foreign", columns={"user_id"})})
 * @ORM\Entity
 */
class Incidents
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="date", type="string", length=10, nullable=false)
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="time", type="string", length=5, nullable=false)
     */
    private $time;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", length=65535, nullable=false)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="cause_deviation", type="text", length=65535, nullable=false)
     */
    private $causeDeviation;

    /**
     * @var string
     *
     * @ORM\Column(name="corrective_action", type="text", length=65535, nullable=false)
     */
    private $correctiveAction;

    /**
     * @var string
     *
     * @ORM\Column(name="prevention_recurrence", type="text", length=65535, nullable=true)
     */
    private $preventionRecurrence;

    /**
     * @var string
     *
     * @ORM\Column(name="modified_procedure", type="text", length=65535, nullable=true)
     */
    private $modifiedProcedure;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_trained", type="boolean", nullable=false)
     */
    private $isTrained = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="form_id", type="integer", nullable=false)
     */
    private $formId;

    /**
     * @var boolean
     *
     * @ORM\Column(name="resolved", type="boolean", nullable=false)
     */
    private $resolved = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="deviation_type", type="integer", nullable=false)
     */
    private $deviationType;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
