<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * IncidentImages
 *
 * @ORM\Table(name="incident_images", uniqueConstraints={@ORM\UniqueConstraint(name="incident_images_storage_path_unique", columns={"storage_path"})}, indexes={@ORM\Index(name="incident_images_incident_id_foreign", columns={"incident_id"}), @ORM\Index(name="incident_images_user_id_foreign", columns={"user_id"})})
 * @ORM\Entity
 */
class IncidentImages
{
    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", length=36, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="mime", type="string", length=255, nullable=false)
     */
    private $mime;

    /**
     * @var string
     *
     * @ORM\Column(name="filename", type="string", length=255, nullable=false)
     */
    private $filename;

    /**
     * @var integer
     *
     * @ORM\Column(name="size", type="bigint", nullable=false)
     */
    private $size;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_path", type="string", length=255, nullable=false)
     */
    private $storagePath;

    /**
     * @var string
     *
     * @ORM\Column(name="disk", type="string", length=10, nullable=false)
     */
    private $disk;

    /**
     * @var boolean
     *
     * @ORM\Column(name="status", type="boolean", nullable=false)
     */
    private $status;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var \Incidents
     *
     * @ORM\ManyToOne(targetEntity="Incidents")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="incident_id", referencedColumnName="id")
     * })
     */
    private $incident;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
