<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormT
 *
 * @ORM\Table(name="form_t", indexes={@ORM\Index(name="form_t_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_t_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_t_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormT
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="date", type="string", length=255, nullable=false)
     */
    private $date;

    /**
     * @var boolean
     *
     * @ORM\Column(name="general_security", type="boolean", nullable=false)
     */
    private $generalSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="storage_security", type="boolean", nullable=false)
     */
    private $storageSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="water_security", type="boolean", nullable=false)
     */
    private $waterSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="agriculture_security", type="boolean", nullable=false)
     */
    private $agricultureSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="information_security", type="boolean", nullable=false)
     */
    private $informationSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="personnel_security", type="boolean", nullable=false)
     */
    private $personnelSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="physical_security", type="boolean", nullable=false)
     */
    private $physicalSecurity = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="entry_security", type="boolean", nullable=false)
     */
    private $entrySecurity = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="actions", type="text", length=65535, nullable=true)
     */
    private $actions;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = 'CURRENT_TIMESTAMP';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
