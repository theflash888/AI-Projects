<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormG
 *
 * @ORM\Table(name="form_g", indexes={@ORM\Index(name="form_g_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_g_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_g_storage_id_foreign", columns={"storage_id"})})
 * @ORM\Entity
 */
class FormG
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="adequate_ventilation", type="string", length=3, nullable=true)
     */
    private $adequateVentilation;

    /**
     * @var string
     *
     * @ORM\Column(name="animals", type="string", length=3, nullable=true)
     */
    private $animals;

    /**
     * @var string
     *
     * @ORM\Column(name="control_measures", type="string", length=3, nullable=true)
     */
    private $controlMeasures;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_doors_close_fitting", type="string", length=3, nullable=true)
     */
    private $exteriorDoorsCloseFitting;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_doors_secured", type="string", length=3, nullable=true)
     */
    private $exteriorDoorsSecured;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_dumpster", type="string", length=3, nullable=true)
     */
    private $exteriorDumpster;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_half_perimeter", type="string", length=3, nullable=true)
     */
    private $exteriorHalfPerimeter;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_land_drainage", type="string", length=3, nullable=true)
     */
    private $exteriorLandDrainage;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_land_drainage_structure", type="string", length=3, nullable=true)
     */
    private $exteriorLandDrainageStructure;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_maintenance", type="text", length=65535, nullable=true)
     */
    private $exteriorMaintenance;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_maintenance_completed_by", type="string", length=255, nullable=true)
     */
    private $exteriorMaintenanceCompletedBy;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_maintenance_completed_date", type="string", length=255, nullable=true)
     */
    private $exteriorMaintenanceCompletedDate;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_maintenance_overseen_by", type="string", length=255, nullable=true)
     */
    private $exteriorMaintenanceOverseenBy;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_maintenance_overseen_date", type="string", length=255, nullable=true)
     */
    private $exteriorMaintenanceOverseenDate;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_no_areas_pests", type="string", length=3, nullable=true)
     */
    private $exteriorNoAreasPests;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_no_junk", type="string", length=3, nullable=true)
     */
    private $exteriorNoJunk;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_roof_cover", type="string", length=3, nullable=true)
     */
    private $exteriorRoofCover;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_weeds", type="string", length=3, nullable=true)
     */
    private $exteriorWeeds;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_weeds_controlled", type="string", length=3, nullable=true)
     */
    private $exteriorWeedsControlled;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_windows_closed", type="string", length=3, nullable=true)
     */
    private $exteriorWindowsClosed;

    /**
     * @var string
     *
     * @ORM\Column(name="fans_air_free", type="string", length=3, nullable=true)
     */
    private $fansAirFree;

    /**
     * @var string
     *
     * @ORM\Column(name="floor_drainage", type="string", length=3, nullable=true)
     */
    private $floorDrainage;

    /**
     * @var string
     *
     * @ORM\Column(name="floor_free_pests", type="string", length=3, nullable=true)
     */
    private $floorFreePests;

    /**
     * @var string
     *
     * @ORM\Column(name="floors_clean", type="string", length=3, nullable=true)
     */
    private $floorsClean;

    /**
     * @var string
     *
     * @ORM\Column(name="interior_maintenance", type="text", length=65535, nullable=true)
     */
    private $interiorMaintenance;

    /**
     * @var string
     *
     * @ORM\Column(name="interior_maintenance_completed_by", type="string", length=255, nullable=true)
     */
    private $interiorMaintenanceCompletedBy;

    /**
     * @var string
     *
     * @ORM\Column(name="interior_maintenance_completed_date", type="string", length=255, nullable=true)
     */
    private $interiorMaintenanceCompletedDate;

    /**
     * @var string
     *
     * @ORM\Column(name="interior_maintenance_overseen_by", type="string", length=255, nullable=true)
     */
    private $interiorMaintenanceOverseenBy;

    /**
     * @var string
     *
     * @ORM\Column(name="interior_maintenance_overseen_date", type="string", length=255, nullable=true)
     */
    private $interiorMaintenanceOverseenDate;

    /**
     * @var string
     *
     * @ORM\Column(name="material_designated", type="string", length=3, nullable=true)
     */
    private $materialDesignated;

    /**
     * @var string
     *
     * @ORM\Column(name="no_exterior_holes", type="string", length=3, nullable=true)
     */
    private $noExteriorHoles;

    /**
     * @var string
     *
     * @ORM\Column(name="no_holes", type="string", length=3, nullable=true)
     */
    private $noHoles;

    /**
     * @var string
     *
     * @ORM\Column(name="no_pipes", type="string", length=3, nullable=true)
     */
    private $noPipes;

    /**
     * @var string
     *
     * @ORM\Column(name="shatterproof", type="string", length=3, nullable=true)
     */
    private $shatterproof;

    /**
     * @var integer
     *
     * @ORM\Column(name="building_type", type="integer", nullable=false)
     */
    private $buildingType;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="confirmed_by_id", type="integer", nullable=true)
     */
    private $confirmedById;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="storage_id", referencedColumnName="id")
     * })
     */
    private $storage;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
