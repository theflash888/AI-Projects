<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormI
 *
 * @ORM\Table(name="form_i", indexes={@ORM\Index(name="form_i_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_i_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_i_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormI
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="employee", type="string", length=255, nullable=false)
     */
    private $employee;

    /**
     * @var string
     *
     * @ORM\Column(name="equipment", type="string", length=255, nullable=false)
     */
    private $equipment;

    /**
     * @var string
     *
     * @ORM\Column(name="activity_code", type="string", length=255, nullable=false)
     */
    private $activityCode;

    /**
     * @var string
     *
     * @ORM\Column(name="activity_other", type="string", length=255, nullable=true)
     */
    private $activityOther;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", length=65535, nullable=false)
     */
    private $description;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = 'CURRENT_TIMESTAMP';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
