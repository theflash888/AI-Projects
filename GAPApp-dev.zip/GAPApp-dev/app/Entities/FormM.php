<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormM
 *
 * @ORM\Table(name="form_m", indexes={@ORM\Index(name="form_m_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_m_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_m_storage_id_foreign", columns={"storage_id"}), @ORM\Index(name="form_m_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormM
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="device_number", type="string", length=255, nullable=false)
     */
    private $deviceNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="findings", type="string", length=255, nullable=false)
     */
    private $findings;

    /**
     * @var string
     *
     * @ORM\Column(name="action_taken", type="text", length=65535, nullable=false)
     */
    private $actionTaken;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="storage_id", referencedColumnName="id")
     * })
     */
    private $storage;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
