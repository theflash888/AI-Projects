<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormH2
 *
 * @ORM\Table(name="form_h2", indexes={@ORM\Index(name="form_h2_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_h2_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_h2_product_site_information_foreign", columns={"product_site_information"}), @ORM\Index(name="form_h2_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormH2
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="blend", type="string", length=255, nullable=false)
     */
    private $blend;

    /**
     * @var string
     *
     * @ORM\Column(name="commercial_rate", type="string", length=255, nullable=false)
     */
    private $commercialRate;

    /**
     * @var string
     *
     * @ORM\Column(name="current_crop", type="string", length=255, nullable=false)
     */
    private $currentCrop;

    /**
     * @var string
     *
     * @ORM\Column(name="date_planted", type="string", length=255, nullable=false)
     */
    private $datePlanted;

    /**
     * @var string
     *
     * @ORM\Column(name="fertilizer_lot_num", type="string", length=255, nullable=false)
     */
    private $fertilizerLotNum;

    /**
     * @var string
     *
     * @ORM\Column(name="manure_rate", type="string", length=255, nullable=false)
     */
    private $manureRate;

    /**
     * @var string
     *
     * @ORM\Column(name="operation_name", type="string", length=255, nullable=false)
     */
    private $operationName;

    /**
     * @var string
     *
     * @ORM\Column(name="previous_year_crops", type="string", length=255, nullable=false)
     */
    private $previousYearCrops;

    /**
     * @var string
     *
     * @ORM\Column(name="production_site_area", type="string", length=255, nullable=false)
     */
    private $productionSiteArea;

    /**
     * @var string
     *
     * @ORM\Column(name="seed_certificate", type="string", length=255, nullable=false)
     */
    private $seedCertificate;

    /**
     * @var string
     *
     * @ORM\Column(name="supplier_name", type="string", length=255, nullable=false)
     */
    private $supplierName;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=255, nullable=false)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="variety", type="string", length=255, nullable=false)
     */
    private $variety;

    /**
     * @var string
     *
     * @ORM\Column(name="what_is_applied", type="string", length=255, nullable=false)
     */
    private $whatIsApplied;

    /**
     * @var string
     *
     * @ORM\Column(name="earliest_harvest_date", type="string", length=255, nullable=false)
     */
    private $earliestHarvestDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="product_site_information", referencedColumnName="id")
     * })
     */
    private $productSiteInformation;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
