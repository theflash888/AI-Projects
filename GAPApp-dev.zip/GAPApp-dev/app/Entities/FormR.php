<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormR
 *
 * @ORM\Table(name="form_r", indexes={@ORM\Index(name="form_r_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_r_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_r_incident_id_foreign", columns={"incident_id"}), @ORM\Index(name="form_r_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormR
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="major_deviation", type="text", length=65535, nullable=false)
     */
    private $majorDeviation;

    /**
     * @var string
     *
     * @ORM\Column(name="cause_of_deviation", type="string", length=255, nullable=false)
     */
    private $causeOfDeviation;

    /**
     * @var string
     *
     * @ORM\Column(name="corrective_action", type="text", length=65535, nullable=false)
     */
    private $correctiveAction;

    /**
     * @var string
     *
     * @ORM\Column(name="prevention_of_recurrence", type="text", length=65535, nullable=false)
     */
    private $preventionOfRecurrence;

    /**
     * @var string
     *
     * @ORM\Column(name="modified_procedure", type="text", length=65535, nullable=false)
     */
    private $modifiedProcedure;

    /**
     * @var boolean
     *
     * @ORM\Column(name="employee_trained", type="boolean", nullable=false)
     */
    private $employeeTrained;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Incidents
     *
     * @ORM\ManyToOne(targetEntity="Incidents")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="incident_id", referencedColumnName="id")
     * })
     */
    private $incident;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
