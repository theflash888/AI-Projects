<?php

namespace App\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * FormK
 *
 * @ORM\Table(name="form_k", indexes={@ORM\Index(name="form_k_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_k_user_id_foreign", columns={"user_id"})})
 * @ORM\Entity
 */
class FormK
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="employees", type="string", length=255, nullable=false)
     */
    private $employees;

    /**
     * @var string
     *
     * @ORM\Column(name="topics", type="string", length=255, nullable=false)
     */
    private $topics;

    /**
     * @var string
     *
     * @ORM\Column(name="responsible", type="string", length=255, nullable=false)
     */
    private $responsible;

    /**
     * @var string
     *
     * @ORM\Column(name="signature", type="string", length=255, nullable=false)
     */
    private $signature;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = 'CURRENT_TIMESTAMP';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="confirmed_by_id", type="integer", nullable=true)
     */
    private $confirmedById;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
