<?php

namespace App\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OauthGrants
 *
 * @ORM\Table(name="oauth_grants")
 * @ORM\Entity
 */
class OauthGrants
{
    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", length=40, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;


}
