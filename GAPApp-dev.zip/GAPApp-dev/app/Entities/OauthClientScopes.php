<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthClientScopes
 *
 * @ORM\Table(name="oauth_client_scopes", indexes={@ORM\Index(name="oauth_client_scopes_client_id_index", columns={"client_id"}), @ORM\Index(name="oauth_client_scopes_scope_id_index", columns={"scope_id"})})
 * @ORM\Entity
 */
class OauthClientScopes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthClients
     *
     * @ORM\ManyToOne(targetEntity="OauthClients")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="client_id", referencedColumnName="id")
     * })
     */
    private $client;

    /**
     * @var \OauthScopes
     *
     * @ORM\ManyToOne(targetEntity="OauthScopes")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="scope_id", referencedColumnName="id")
     * })
     */
    private $scope;


}
