<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthClientGrants
 *
 * @ORM\Table(name="oauth_client_grants", indexes={@ORM\Index(name="oauth_client_grants_client_id_index", columns={"client_id"}), @ORM\Index(name="oauth_client_grants_grant_id_index", columns={"grant_id"})})
 * @ORM\Entity
 */
class OauthClientGrants
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthClients
     *
     * @ORM\ManyToOne(targetEntity="OauthClients")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="client_id", referencedColumnName="id")
     * })
     */
    private $client;

    /**
     * @var \OauthGrants
     *
     * @ORM\ManyToOne(targetEntity="OauthGrants")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="grant_id", referencedColumnName="id")
     * })
     */
    private $grant;


}
