<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthAuthCodeScopes
 *
 * @ORM\Table(name="oauth_auth_code_scopes", indexes={@ORM\Index(name="oauth_auth_code_scopes_auth_code_id_index", columns={"auth_code_id"}), @ORM\Index(name="oauth_auth_code_scopes_scope_id_index", columns={"scope_id"})})
 * @ORM\Entity
 */
class OauthAuthCodeScopes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthAuthCodes
     *
     * @ORM\ManyToOne(targetEntity="OauthAuthCodes")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="auth_code_id", referencedColumnName="id")
     * })
     */
    private $authCode;

    /**
     * @var \OauthScopes
     *
     * @ORM\ManyToOne(targetEntity="OauthScopes")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="scope_id", referencedColumnName="id")
     * })
     */
    private $scope;


}
