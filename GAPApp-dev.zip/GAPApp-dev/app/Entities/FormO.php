<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormO
 *
 * @ORM\Table(name="form_o", indexes={@ORM\Index(name="form_o_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_o_user_id_foreign", columns={"user_id"})})
 * @ORM\Entity
 */
class FormO
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="vehicle_inspected", type="boolean", nullable=false)
     */
    private $vehicleInspected = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="hazards", type="string", length=255, nullable=true)
     */
    private $hazards;

    /**
     * @var string
     *
     * @ORM\Column(name="actions", type="string", length=255, nullable=true)
     */
    private $actions;

    /**
     * @var string
     *
     * @ORM\Column(name="destination_and_customer", type="text", length=65535, nullable=false)
     */
    private $destinationAndCustomer;

    /**
     * @var string
     *
     * @ORM\Column(name="product_identifier", type="string", length=255, nullable=false)
     */
    private $productIdentifier;

    /**
     * @var string
     *
     * @ORM\Column(name="quantity_shipped", type="string", length=255, nullable=false)
     */
    private $quantityShipped;

    /**
     * @var string
     *
     * @ORM\Column(name="truck_id", type="string", length=255, nullable=false)
     */
    private $truckId;

    /**
     * @var string
     *
     * @ORM\Column(name="person_responsible", type="string", length=255, nullable=false)
     */
    private $personResponsible;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted;

    /**
     * @var integer
     *
     * @ORM\Column(name="confirmed_by_id", type="integer", nullable=false)
     */
    private $confirmedById;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
