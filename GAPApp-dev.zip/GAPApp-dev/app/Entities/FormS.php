<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormS
 *
 * @ORM\Table(name="form_s", indexes={@ORM\Index(name="form_s_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_s_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_s_storage_id_foreign", columns={"storage_id"}), @ORM\Index(name="form_s_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormS
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="cereals_1", type="string", length=255, nullable=true)
     */
    private $cereals1;

    /**
     * @var string
     *
     * @ORM\Column(name="cereals_2", type="string", length=255, nullable=true)
     */
    private $cereals2;

    /**
     * @var string
     *
     * @ORM\Column(name="cereals_3", type="string", length=255, nullable=true)
     */
    private $cereals3;

    /**
     * @var string
     *
     * @ORM\Column(name="cereals_4", type="string", length=255, nullable=true)
     */
    private $cereals4;

    /**
     * @var string
     *
     * @ORM\Column(name="cereals_5", type="string", length=255, nullable=true)
     */
    private $cereals5;

    /**
     * @var string
     *
     * @ORM\Column(name="comments", type="text", length=65535, nullable=true)
     */
    private $comments;

    /**
     * @var string
     *
     * @ORM\Column(name="eggs_1", type="string", length=255, nullable=true)
     */
    private $eggs1;

    /**
     * @var string
     *
     * @ORM\Column(name="eggs_2", type="string", length=255, nullable=true)
     */
    private $eggs2;

    /**
     * @var string
     *
     * @ORM\Column(name="eggs_3", type="string", length=255, nullable=true)
     */
    private $eggs3;

    /**
     * @var string
     *
     * @ORM\Column(name="eggs_4", type="string", length=255, nullable=true)
     */
    private $eggs4;

    /**
     * @var string
     *
     * @ORM\Column(name="eggs_5", type="string", length=255, nullable=true)
     */
    private $eggs5;

    /**
     * @var string
     *
     * @ORM\Column(name="fish_1", type="string", length=255, nullable=true)
     */
    private $fish1;

    /**
     * @var string
     *
     * @ORM\Column(name="fish_2", type="string", length=255, nullable=true)
     */
    private $fish2;

    /**
     * @var string
     *
     * @ORM\Column(name="fish_3", type="string", length=255, nullable=true)
     */
    private $fish3;

    /**
     * @var string
     *
     * @ORM\Column(name="fish_4", type="string", length=255, nullable=true)
     */
    private $fish4;

    /**
     * @var string
     *
     * @ORM\Column(name="fish_5", type="string", length=255, nullable=true)
     */
    private $fish5;

    /**
     * @var string
     *
     * @ORM\Column(name="milk_1", type="string", length=255, nullable=true)
     */
    private $milk1;

    /**
     * @var string
     *
     * @ORM\Column(name="milk_2", type="string", length=255, nullable=true)
     */
    private $milk2;

    /**
     * @var string
     *
     * @ORM\Column(name="milk_3", type="string", length=255, nullable=true)
     */
    private $milk3;

    /**
     * @var string
     *
     * @ORM\Column(name="milk_4", type="string", length=255, nullable=true)
     */
    private $milk4;

    /**
     * @var string
     *
     * @ORM\Column(name="milk_5", type="string", length=255, nullable=true)
     */
    private $milk5;

    /**
     * @var string
     *
     * @ORM\Column(name="others_1", type="text", length=65535, nullable=true)
     */
    private $others1;

    /**
     * @var string
     *
     * @ORM\Column(name="others_2", type="text", length=65535, nullable=true)
     */
    private $others2;

    /**
     * @var string
     *
     * @ORM\Column(name="others_3", type="text", length=65535, nullable=true)
     */
    private $others3;

    /**
     * @var string
     *
     * @ORM\Column(name="others_4", type="text", length=65535, nullable=true)
     */
    private $others4;

    /**
     * @var string
     *
     * @ORM\Column(name="others_5", type="text", length=65535, nullable=true)
     */
    private $others5;

    /**
     * @var string
     *
     * @ORM\Column(name="peanut_1", type="string", length=255, nullable=true)
     */
    private $peanut1;

    /**
     * @var string
     *
     * @ORM\Column(name="peanut_2", type="string", length=255, nullable=true)
     */
    private $peanut2;

    /**
     * @var string
     *
     * @ORM\Column(name="peanut_3", type="string", length=255, nullable=true)
     */
    private $peanut3;

    /**
     * @var string
     *
     * @ORM\Column(name="peanut_4", type="string", length=255, nullable=true)
     */
    private $peanut4;

    /**
     * @var string
     *
     * @ORM\Column(name="peanut_5", type="string", length=255, nullable=true)
     */
    private $peanut5;

    /**
     * @var string
     *
     * @ORM\Column(name="sesame_1", type="string", length=255, nullable=true)
     */
    private $sesame1;

    /**
     * @var string
     *
     * @ORM\Column(name="sesame_2", type="string", length=255, nullable=true)
     */
    private $sesame2;

    /**
     * @var string
     *
     * @ORM\Column(name="sesame_3", type="string", length=255, nullable=true)
     */
    private $sesame3;

    /**
     * @var string
     *
     * @ORM\Column(name="sesame_4", type="string", length=255, nullable=true)
     */
    private $sesame4;

    /**
     * @var string
     *
     * @ORM\Column(name="sesame_5", type="string", length=255, nullable=true)
     */
    private $sesame5;

    /**
     * @var string
     *
     * @ORM\Column(name="shellfish_molluscs_1", type="string", length=255, nullable=true)
     */
    private $shellfishMolluscs1;

    /**
     * @var string
     *
     * @ORM\Column(name="shellfish_molluscs_2", type="string", length=255, nullable=true)
     */
    private $shellfishMolluscs2;

    /**
     * @var string
     *
     * @ORM\Column(name="shellfish_molluscs_3", type="string", length=255, nullable=true)
     */
    private $shellfishMolluscs3;

    /**
     * @var string
     *
     * @ORM\Column(name="shellfish_molluscs_4", type="string", length=255, nullable=true)
     */
    private $shellfishMolluscs4;

    /**
     * @var string
     *
     * @ORM\Column(name="shellfish_molluscs_5", type="string", length=255, nullable=true)
     */
    private $shellfishMolluscs5;

    /**
     * @var string
     *
     * @ORM\Column(name="soybeans_1", type="string", length=255, nullable=true)
     */
    private $soybeans1;

    /**
     * @var string
     *
     * @ORM\Column(name="soybeans_2", type="string", length=255, nullable=true)
     */
    private $soybeans2;

    /**
     * @var string
     *
     * @ORM\Column(name="soybeans_3", type="string", length=255, nullable=true)
     */
    private $soybeans3;

    /**
     * @var string
     *
     * @ORM\Column(name="soybeans_4", type="string", length=255, nullable=true)
     */
    private $soybeans4;

    /**
     * @var string
     *
     * @ORM\Column(name="soybeans_5", type="string", length=255, nullable=true)
     */
    private $soybeans5;

    /**
     * @var string
     *
     * @ORM\Column(name="storage", type="string", length=255, nullable=true)
     */
    private $storage;

    /**
     * @var string
     *
     * @ORM\Column(name="sulphites_1", type="string", length=255, nullable=true)
     */
    private $sulphites1;

    /**
     * @var string
     *
     * @ORM\Column(name="sulphites_2", type="string", length=255, nullable=true)
     */
    private $sulphites2;

    /**
     * @var string
     *
     * @ORM\Column(name="sulphites_3", type="string", length=255, nullable=true)
     */
    private $sulphites3;

    /**
     * @var string
     *
     * @ORM\Column(name="sulphites_4", type="string", length=255, nullable=true)
     */
    private $sulphites4;

    /**
     * @var string
     *
     * @ORM\Column(name="sulphites_5", type="string", length=255, nullable=true)
     */
    private $sulphites5;

    /**
     * @var string
     *
     * @ORM\Column(name="tree_nuts_1", type="string", length=255, nullable=true)
     */
    private $treeNuts1;

    /**
     * @var string
     *
     * @ORM\Column(name="tree_nuts_2", type="string", length=255, nullable=true)
     */
    private $treeNuts2;

    /**
     * @var string
     *
     * @ORM\Column(name="tree_nuts_3", type="string", length=255, nullable=true)
     */
    private $treeNuts3;

    /**
     * @var string
     *
     * @ORM\Column(name="tree_nuts_4", type="string", length=255, nullable=true)
     */
    private $treeNuts4;

    /**
     * @var string
     *
     * @ORM\Column(name="tree_nuts_5", type="string", length=255, nullable=true)
     */
    private $treeNuts5;

    /**
     * @var string
     *
     * @ORM\Column(name="mustard_1", type="string", length=255, nullable=true)
     */
    private $mustard1;

    /**
     * @var string
     *
     * @ORM\Column(name="mustard_2", type="string", length=255, nullable=true)
     */
    private $mustard2;

    /**
     * @var string
     *
     * @ORM\Column(name="mustard_3", type="string", length=255, nullable=true)
     */
    private $mustard3;

    /**
     * @var string
     *
     * @ORM\Column(name="mustard_4", type="string", length=255, nullable=true)
     */
    private $mustard4;

    /**
     * @var string
     *
     * @ORM\Column(name="mustard_5", type="string", length=255, nullable=true)
     */
    private $mustard5;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="storage_id", referencedColumnName="id")
     * })
     */
    private $storage2;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
