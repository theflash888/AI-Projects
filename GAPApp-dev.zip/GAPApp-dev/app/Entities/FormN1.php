<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormN1
 *
 * @ORM\Table(name="form_n1", indexes={@ORM\Index(name="form_n1_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_n1_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_n1_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormN1
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="water_source", type="integer", nullable=false)
     */
    private $waterSource;

    /**
     * @var string
     *
     * @ORM\Column(name="chlorine_added", type="string", length=255, nullable=false)
     */
    private $chlorineAdded;

    /**
     * @var string
     *
     * @ORM\Column(name="chlorine_concentration", type="string", length=255, nullable=false)
     */
    private $chlorineConcentration;

    /**
     * @var string
     *
     * @ORM\Column(name="contact_time", type="string", length=255, nullable=false)
     */
    private $contactTime;

    /**
     * @var string
     *
     * @ORM\Column(name="method", type="string", length=255, nullable=false)
     */
    private $method;

    /**
     * @var string
     *
     * @ORM\Column(name="post_treatment", type="string", length=255, nullable=false)
     */
    private $postTreatment;

    /**
     * @var string
     *
     * @ORM\Column(name="pre_treatment", type="string", length=255, nullable=false)
     */
    private $preTreatment;

    /**
     * @var string
     *
     * @ORM\Column(name="volume", type="string", length=255, nullable=false)
     */
    private $volume;

    /**
     * @var string
     *
     * @ORM\Column(name="water_ph", type="string", length=255, nullable=false)
     */
    private $waterPh;

    /**
     * @var boolean
     *
     * @ORM\Column(name="recirculated_water", type="boolean", nullable=false)
     */
    private $recirculatedWater = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="water_changed", type="boolean", nullable=false)
     */
    private $waterChanged = '0';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
