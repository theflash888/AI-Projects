<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormH1
 *
 * @ORM\Table(name="form_h1", indexes={@ORM\Index(name="form_h1_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_h1_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_h1_product_site_information_foreign", columns={"product_site_information"}), @ORM\Index(name="form_h1_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormH1
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="actual_quantity_used", type="string", length=255, nullable=false)
     */
    private $actualQuantityUsed;

    /**
     * @var string
     *
     * @ORM\Column(name="area_treated", type="string", length=255, nullable=false)
     */
    private $areaTreated;

    /**
     * @var string
     *
     * @ORM\Column(name="current_crop", type="string", length=255, nullable=false)
     */
    private $currentCrop;

    /**
     * @var string
     *
     * @ORM\Column(name="date_planted", type="string", length=255, nullable=false)
     */
    private $datePlanted;

    /**
     * @var string
     *
     * @ORM\Column(name="eahd", type="string", length=255, nullable=false)
     */
    private $eahd;

    /**
     * @var boolean
     *
     * @ORM\Column(name="label_followed", type="boolean", nullable=false)
     */
    private $labelFollowed;

    /**
     * @var string
     *
     * @ORM\Column(name="method_of_application", type="string", length=255, nullable=false)
     */
    private $methodOfApplication;

    /**
     * @var string
     *
     * @ORM\Column(name="operation_name", type="string", length=255, nullable=false)
     */
    private $operationName;

    /**
     * @var string
     *
     * @ORM\Column(name="pcp", type="string", length=255, nullable=false)
     */
    private $pcp;

    /**
     * @var string
     *
     * @ORM\Column(name="phi_daa", type="string", length=255, nullable=false)
     */
    private $phiDaa;

    /**
     * @var string
     *
     * @ORM\Column(name="previous_year_crops", type="string", length=255, nullable=false)
     */
    private $previousYearCrops;

    /**
     * @var string
     *
     * @ORM\Column(name="product_trade_name", type="string", length=255, nullable=false)
     */
    private $productTradeName;

    /**
     * @var string
     *
     * @ORM\Column(name="production_site_area", type="string", length=255, nullable=false)
     */
    private $productionSiteArea;

    /**
     * @var string
     *
     * @ORM\Column(name="rate_applied", type="string", length=255, nullable=false)
     */
    private $rateApplied;

    /**
     * @var string
     *
     * @ORM\Column(name="seed_certificate", type="string", length=255, nullable=true)
     */
    private $seedCertificate;

    /**
     * @var string
     *
     * @ORM\Column(name="variety", type="string", length=255, nullable=false)
     */
    private $variety;

    /**
     * @var string
     *
     * @ORM\Column(name="weather_condition", type="string", length=255, nullable=false)
     */
    private $weatherCondition;

    /**
     * @var string
     *
     * @ORM\Column(name="person_responsible", type="string", length=255, nullable=false)
     */
    private $personResponsible;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="product_site_information", referencedColumnName="id")
     * })
     */
    private $productSiteInformation;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
