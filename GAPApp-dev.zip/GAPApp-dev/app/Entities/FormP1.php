<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormP1
 *
 * @ORM\Table(name="form_p1", indexes={@ORM\Index(name="form_p1_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_p1_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_p1_storage_id_foreign", columns={"storage_id"}), @ORM\Index(name="form_p1_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormP1
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="application_rate", type="string", length=255, nullable=false)
     */
    private $applicationRate;

    /**
     * @var string
     *
     * @ORM\Column(name="bin_fill_date", type="string", length=255, nullable=false)
     */
    private $binFillDate;

    /**
     * @var string
     *
     * @ORM\Column(name="cross_section", type="string", length=255, nullable=false)
     */
    private $crossSection;

    /**
     * @var string
     *
     * @ORM\Column(name="harvest_date", type="string", length=255, nullable=false)
     */
    private $harvestDate;

    /**
     * @var string
     *
     * @ORM\Column(name="method_of_application", type="string", length=255, nullable=false)
     */
    private $methodOfApplication;

    /**
     * @var boolean
     *
     * @ORM\Column(name="phi_eahd_daa", type="boolean", nullable=false)
     */
    private $phiEahdDaa;

    /**
     * @var string
     *
     * @ORM\Column(name="product_name", type="string", length=255, nullable=false)
     */
    private $productName;

    /**
     * @var boolean
     *
     * @ORM\Column(name="production_site_assessed", type="boolean", nullable=false)
     */
    private $productionSiteAssessed;

    /**
     * @var string
     *
     * @ORM\Column(name="quantity_treated", type="string", length=255, nullable=false)
     */
    private $quantityTreated;

    /**
     * @var string
     *
     * @ORM\Column(name="variety", type="string", length=255, nullable=false)
     */
    private $variety;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="storage_id", referencedColumnName="id")
     * })
     */
    private $storage;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
