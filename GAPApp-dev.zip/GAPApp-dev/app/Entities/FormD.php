s<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormD
 *
 * @ORM\Table(name="form_d", indexes={@ORM\Index(name="form_d_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_d_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_d_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormD
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="aprons_rubber", type="string", length=255, nullable=false)
     */
    private $apronsRubber;

    /**
     * @var string
     *
     * @ORM\Column(name="aprons_used", type="string", length=255, nullable=false)
     */
    private $apronsUsed;

    /**
     * @var string
     *
     * @ORM\Column(name="clean_footwear", type="string", length=255, nullable=false)
     */
    private $cleanFootwear;

    /**
     * @var string
     *
     * @ORM\Column(name="employee_adhere", type="string", length=255, nullable=false)
     */
    private $employeeAdhere;

    /**
     * @var string
     *
     * @ORM\Column(name="employee_aprons", type="string", length=255, nullable=false)
     */
    private $employeeAprons;

    /**
     * @var string
     *
     * @ORM\Column(name="employee_authorized", type="string", length=255, nullable=false)
     */
    private $employeeAuthorized;

    /**
     * @var string
     *
     * @ORM\Column(name="employees_aware", type="string", length=255, nullable=false)
     */
    private $employeesAware;

    /**
     * @var string
     *
     * @ORM\Column(name="employees_trained", type="string", length=255, nullable=false)
     */
    private $employeesTrained;

    /**
     * @var string
     *
     * @ORM\Column(name="false_fingernails", type="string", length=255, nullable=false)
     */
    private $falseFingernails;

    /**
     * @var string
     *
     * @ORM\Column(name="gloves_aprons", type="string", length=255, nullable=false)
     */
    private $glovesAprons;

    /**
     * @var string
     *
     * @ORM\Column(name="gloves_removed", type="string", length=255, nullable=false)
     */
    private $glovesRemoved;

    /**
     * @var string
     *
     * @ORM\Column(name="gloves_rubber", type="string", length=255, nullable=false)
     */
    private $glovesRubber;

    /**
     * @var string
     *
     * @ORM\Column(name="gloves_substitute", type="string", length=255, nullable=false)
     */
    private $glovesSubstitute;

    /**
     * @var string
     *
     * @ORM\Column(name="gloves_used", type="string", length=255, nullable=false)
     */
    private $glovesUsed;

    /**
     * @var string
     *
     * @ORM\Column(name="hands_reusable_gloves", type="string", length=255, nullable=false)
     */
    private $handsReusableGloves;

    /**
     * @var string
     *
     * @ORM\Column(name="hands_washed", type="string", length=255, nullable=false)
     */
    private $handsWashed;

    /**
     * @var string
     *
     * @ORM\Column(name="hands_washed_dried", type="string", length=255, nullable=false)
     */
    private $handsWashedDried;

    /**
     * @var string
     *
     * @ORM\Column(name="items_removed_pocket", type="string", length=255, nullable=false)
     */
    private $itemsRemovedPocket;

    /**
     * @var string
     *
     * @ORM\Column(name="jewellery_worn", type="string", length=255, nullable=false)
     */
    private $jewelleryWorn;

    /**
     * @var string
     *
     * @ORM\Column(name="long_hair_touching", type="string", length=255, nullable=false)
     */
    private $longHairTouching;

    /**
     * @var string
     *
     * @ORM\Column(name="loose_buttons_fixed", type="string", length=255, nullable=false)
     */
    private $looseButtonsFixed;

    /**
     * @var string
     *
     * @ORM\Column(name="major_minor", type="string", length=255, nullable=false)
     */
    private $majorMinor;

    /**
     * @var string
     *
     * @ORM\Column(name="no_water", type="string", length=255, nullable=false)
     */
    private $noWater;

    /**
     * @var string
     *
     * @ORM\Column(name="person_responsible", type="string", length=255, nullable=false)
     */
    private $personResponsible;

    /**
     * @var string
     *
     * @ORM\Column(name="person_responsible_name", type="string", length=255, nullable=true)
     */
    private $personResponsibleName;

    /**
     * @var string
     *
     * @ORM\Column(name="person_transmit", type="string", length=255, nullable=false)
     */
    private $personTransmit;

    /**
     * @var string
     *
     * @ORM\Column(name="personal_cleanliness", type="string", length=255, nullable=false)
     */
    private $personalCleanliness;

    /**
     * @var string
     *
     * @ORM\Column(name="personal_cleanliness_other", type="string", length=255, nullable=true)
     */
    private $personalCleanlinessOther;

    /**
     * @var string
     *
     * @ORM\Column(name="reusable_aprons", type="string", length=255, nullable=false)
     */
    private $reusableAprons;

    /**
     * @var string
     *
     * @ORM\Column(name="ring_gloves", type="string", length=255, nullable=false)
     */
    private $ringGloves;

    /**
     * @var string
     *
     * @ORM\Column(name="trained_precautions", type="string", length=255, nullable=false)
     */
    private $trainedPrecautions;

    /**
     * @var string
     *
     * @ORM\Column(name="wipe_hand_sanitizer", type="string", length=255, nullable=false)
     */
    private $wipeHandSanitizer;

    /**
     * @var string
     *
     * @ORM\Column(name="wounds_treated", type="string", length=255, nullable=false)
     */
    private $woundsTreated;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
