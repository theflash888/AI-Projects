<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormB
 *
 * @ORM\Table(name="form_b", indexes={@ORM\Index(name="form_b_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_b_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_b_storage_id_foreign", columns={"storage_id"}), @ORM\Index(name="form_b_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormB
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="date", type="string", length=255, nullable=false)
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="ceiling_storage", type="string", length=3, nullable=false)
     */
    private $ceilingStorage;

    /**
     * @var string
     *
     * @ORM\Column(name="ceiling_storage_action", type="text", length=65535, nullable=true)
     */
    private $ceilingStorageAction;

    /**
     * @var string
     *
     * @ORM\Column(name="floor_clean", type="string", length=3, nullable=false)
     */
    private $floorClean;

    /**
     * @var string
     *
     * @ORM\Column(name="floor_clean_action", type="text", length=65535, nullable=true)
     */
    private $floorCleanAction;

    /**
     * @var string
     *
     * @ORM\Column(name="free_animals", type="string", length=3, nullable=false)
     */
    private $freeAnimals;

    /**
     * @var string
     *
     * @ORM\Column(name="free_animals_action", type="text", length=65535, nullable=true)
     */
    private $freeAnimalsAction;

    /**
     * @var string
     *
     * @ORM\Column(name="furnace_exhausting", type="string", length=3, nullable=false)
     */
    private $furnaceExhausting;

    /**
     * @var string
     *
     * @ORM\Column(name="furnace_exhausting_action", type="text", length=65535, nullable=true)
     */
    private $furnaceExhaustingAction;

    /**
     * @var string
     *
     * @ORM\Column(name="production_equipment", type="string", length=3, nullable=false)
     */
    private $productionEquipment;

    /**
     * @var string
     *
     * @ORM\Column(name="production_equipment_action", type="text", length=65535, nullable=true)
     */
    private $productionEquipmentAction;

    /**
     * @var string
     *
     * @ORM\Column(name="leaky_area", type="string", length=3, nullable=false)
     */
    private $leakyArea;

    /**
     * @var string
     *
     * @ORM\Column(name="leaky_area_action", type="text", length=65535, nullable=true)
     */
    private $leakyAreaAction;

    /**
     * @var string
     *
     * @ORM\Column(name="lights_shatterproof", type="string", length=3, nullable=false)
     */
    private $lightsShatterproof;

    /**
     * @var string
     *
     * @ORM\Column(name="lights_shatterproof_action", type="text", length=65535, nullable=true)
     */
    private $lightsShatterproofAction;

    /**
     * @var string
     *
     * @ORM\Column(name="no_smoking", type="string", length=3, nullable=false)
     */
    private $noSmoking;

    /**
     * @var string
     *
     * @ORM\Column(name="no_smoking_action", type="text", length=65535, nullable=true)
     */
    private $noSmokingAction;

    /**
     * @var string
     *
     * @ORM\Column(name="other", type="string", length=3, nullable=false)
     */
    private $other;

    /**
     * @var string
     *
     * @ORM\Column(name="other_action", type="text", length=65535, nullable=true)
     */
    private $otherAction;

    /**
     * @var string
     *
     * @ORM\Column(name="potatoes_dark", type="string", length=3, nullable=false)
     */
    private $potatoesDark;

    /**
     * @var string
     *
     * @ORM\Column(name="potatoes_dark_action", type="text", length=65535, nullable=true)
     */
    private $potatoesDarkAction;

    /**
     * @var string
     *
     * @ORM\Column(name="potatoes_treated", type="string", length=3, nullable=false)
     */
    private $potatoesTreated;

    /**
     * @var string
     *
     * @ORM\Column(name="potatoes_treated_action", type="text", length=65535, nullable=true)
     */
    private $potatoesTreatedAction;

    /**
     * @var string
     *
     * @ORM\Column(name="proper_condition", type="string", length=3, nullable=false)
     */
    private $properCondition;

    /**
     * @var string
     *
     * @ORM\Column(name="proper_condition_action", type="text", length=65535, nullable=true)
     */
    private $properConditionAction;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_in_use", type="string", length=3, nullable=false)
     */
    private $storageInUse;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_in_use_action", type="text", length=65535, nullable=true)
     */
    private $storageInUseAction;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_secured", type="string", length=3, nullable=false)
     */
    private $storageSecured;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_secured_action", type="text", length=65535, nullable=true)
     */
    private $storageSecuredAction;

    /**
     * @var string
     *
     * @ORM\Column(name="treated_seed", type="string", length=3, nullable=false)
     */
    private $treatedSeed;

    /**
     * @var string
     *
     * @ORM\Column(name="treated_seed_action", type="text", length=65535, nullable=true)
     */
    private $treatedSeedAction;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_cleaning_desc", type="text", length=65535, nullable=true)
     */
    private $storageCleaningDesc;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="storage_id", referencedColumnName="id")
     * })
     */
    private $storage;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
