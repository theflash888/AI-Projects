<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthSessionScopes
 *
 * @ORM\Table(name="oauth_session_scopes", indexes={@ORM\Index(name="oauth_session_scopes_session_id_index", columns={"session_id"}), @ORM\Index(name="oauth_session_scopes_scope_id_index", columns={"scope_id"})})
 * @ORM\Entity
 */
class OauthSessionScopes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthScopes
     *
     * @ORM\ManyToOne(targetEntity="OauthScopes")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="scope_id", referencedColumnName="id")
     * })
     */
    private $scope;

    /**
     * @var \OauthSessions
     *
     * @ORM\ManyToOne(targetEntity="OauthSessions")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="session_id", referencedColumnName="id")
     * })
     */
    private $session;


}
