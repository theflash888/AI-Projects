<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormH3
 *
 * @ORM\Table(name="form_h3", indexes={@ORM\Index(name="form_h3_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_h3_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_h3_production_site_foreign", columns={"production_site"}), @ORM\Index(name="form_h3_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormH3
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="operation_name", type="string", length=255, nullable=false)
     */
    private $operationName;

    /**
     * @var string
     *
     * @ORM\Column(name="variety", type="string", length=255, nullable=false)
     */
    private $variety;

    /**
     * @var string
     *
     * @ORM\Column(name="product_name", type="string", length=255, nullable=false)
     */
    private $productName;

    /**
     * @var string
     *
     * @ORM\Column(name="pcp", type="string", length=255, nullable=false)
     */
    private $pcp;

    /**
     * @var string
     *
     * @ORM\Column(name="rate_applied", type="string", length=255, nullable=false)
     */
    private $rateApplied;

    /**
     * @var string
     *
     * @ORM\Column(name="quantity_treated", type="string", length=255, nullable=false)
     */
    private $quantityTreated;

    /**
     * @var string
     *
     * @ORM\Column(name="lot_id", type="string", length=255, nullable=false)
     */
    private $lotId;

    /**
     * @var string
     *
     * @ORM\Column(name="daa", type="string", length=255, nullable=false)
     */
    private $daa;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="production_site", referencedColumnName="id")
     * })
     */
    private $productionSite;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
