<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthClientEndpoints
 *
 * @ORM\Table(name="oauth_client_endpoints", uniqueConstraints={@ORM\UniqueConstraint(name="oauth_client_endpoints_client_id_redirect_uri_unique", columns={"client_id", "redirect_uri"})}, indexes={@ORM\Index(name="IDX_18F6C30A19EB6921", columns={"client_id"})})
 * @ORM\Entity
 */
class OauthClientEndpoints
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="redirect_uri", type="string", length=255, nullable=false)
     */
    private $redirectUri;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthClients
     *
     * @ORM\ManyToOne(targetEntity="OauthClients")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="client_id", referencedColumnName="id")
     * })
     */
    private $client;


}
