<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormQ
 *
 * @ORM\Table(name="form_q", indexes={@ORM\Index(name="form_q_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_q_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_q_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormQ
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="date_harvested", type="string", length=255, nullable=false)
     */
    private $dateHarvested;

    /**
     * @var string
     *
     * @ORM\Column(name="field_block_tag", type="string", length=255, nullable=false)
     */
    private $fieldBlockTag;

    /**
     * @var string
     *
     * @ORM\Column(name="harvest_date", type="string", length=255, nullable=false)
     */
    private $harvestDate;

    /**
     * @var string
     *
     * @ORM\Column(name="incoming_pack", type="string", length=255, nullable=false)
     */
    private $incomingPack;

    /**
     * @var string
     *
     * @ORM\Column(name="lot_id", type="string", length=255, nullable=false)
     */
    private $lotId;

    /**
     * @var string
     *
     * @ORM\Column(name="market_product_storage", type="string", length=255, nullable=false)
     */
    private $marketProductStorage;

    /**
     * @var string
     *
     * @ORM\Column(name="name_produced", type="string", length=255, nullable=false)
     */
    private $nameProduced;

    /**
     * @var string
     *
     * @ORM\Column(name="outgoing_pack_id", type="string", length=255, nullable=false)
     */
    private $outgoingPackId;

    /**
     * @var boolean
     *
     * @ORM\Column(name="packaging_checked", type="boolean", nullable=false)
     */
    private $packagingChecked;

    /**
     * @var boolean
     *
     * @ORM\Column(name="phi_eahd", type="boolean", nullable=false)
     */
    private $phiEahd;

    /**
     * @var string
     *
     * @ORM\Column(name="primary_package", type="string", length=255, nullable=false)
     */
    private $primaryPackage;

    /**
     * @var string
     *
     * @ORM\Column(name="product_variety", type="string", length=255, nullable=false)
     */
    private $productVariety;

    /**
     * @var boolean
     *
     * @ORM\Column(name="production_site_assesed", type="boolean", nullable=false)
     */
    private $productionSiteAssesed;

    /**
     * @var string
     *
     * @ORM\Column(name="secondary_package", type="string", length=255, nullable=false)
     */
    private $secondaryPackage;

    /**
     * @var string
     *
     * @ORM\Column(name="wax_lot", type="string", length=255, nullable=false)
     */
    private $waxLot;

    /**
     * @var string
     *
     * @ORM\Column(name="quantity", type="string", length=255, nullable=false)
     */
    private $quantity;

    /**
     * @var string
     *
     * @ORM\Column(name="packing_repacking", type="string", length=255, nullable=false)
     */
    private $packingRepacking;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
