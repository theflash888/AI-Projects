<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormA
 *
 * @ORM\Table(name="form_a", uniqueConstraints={@ORM\UniqueConstraint(name="form_a_storage_path_unique", columns={"storage_path"})}, indexes={@ORM\Index(name="form_a_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_a_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_a_entity_id_foreign", columns={"entity_id"})})
 * @ORM\Entity
 */
class FormA
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="mime", type="string", length=255, nullable=false)
     */
    private $mime;

    /**
     * @var string
     *
     * @ORM\Column(name="filename", type="string", length=255, nullable=false)
     */
    private $filename;

    /**
     * @var integer
     *
     * @ORM\Column(name="size", type="bigint", nullable=false)
     */
    private $size;

    /**
     * @var string
     *
     * @ORM\Column(name="storage_path", type="string", length=255, nullable=false)
     */
    private $storagePath;

    /**
     * @var string
     *
     * @ORM\Column(name="disk", type="string", length=10, nullable=false)
     */
    private $disk;

    /**
     * @var boolean
     *
     * @ORM\Column(name="status", type="boolean", nullable=false)
     */
    private $status;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="entity_id", referencedColumnName="id")
     * })
     */
    private $entity;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
