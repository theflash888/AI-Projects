s<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthSessions
 *
 * @ORM\Table(name="oauth_sessions", indexes={@ORM\Index(name="oauth_sessions_client_id_owner_type_owner_id_index", columns={"client_id", "owner_type", "owner_id"}), @ORM\Index(name="IDX_BA1C1E0F19EB6921", columns={"client_id"})})
 * @ORM\Entity
 */
class OauthSessions
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="owner_type", type="string", nullable=false)
     */
    private $ownerType = 'user';

    /**
     * @var string
     *
     * @ORM\Column(name="owner_id", type="string", length=255, nullable=false)
     */
    private $ownerId;

    /**
     * @var string
     *
     * @ORM\Column(name="client_redirect_uri", type="string", length=255, nullable=true)
     */
    private $clientRedirectUri;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthClients
     *
     * @ORM\ManyToOne(targetEntity="OauthClients")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="client_id", referencedColumnName="id")
     * })
     */
    private $client;


}
