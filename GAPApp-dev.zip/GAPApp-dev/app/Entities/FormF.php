<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormF
 *
 * @ORM\Table(name="form_f", indexes={@ORM\Index(name="form_f_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_f_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_f_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormF
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="animal_access", type="boolean", nullable=false)
     */
    private $animalAccess;

    /**
     * @var boolean
     *
     * @ORM\Column(name="appendix_a", type="boolean", nullable=false)
     */
    private $appendixA;

    /**
     * @var boolean
     *
     * @ORM\Column(name="appendix_b", type="boolean", nullable=false)
     */
    private $appendixB;

    /**
     * @var boolean
     *
     * @ORM\Column(name="appendix_h", type="boolean", nullable=false)
     */
    private $appendixH;

    /**
     * @var string
     *
     * @ORM\Column(name="appendix_or", type="string", length=255, nullable=true)
     */
    private $appendixOr;

    /**
     * @var boolean
     *
     * @ORM\Column(name="chemical_application", type="boolean", nullable=false)
     */
    private $chemicalApplication;

    /**
     * @var boolean
     *
     * @ORM\Column(name="cistern", type="boolean", nullable=false)
     */
    private $cistern;

    /**
     * @var boolean
     *
     * @ORM\Column(name="cleaned", type="boolean", nullable=false)
     */
    private $cleaned;

    /**
     * @var string
     *
     * @ORM\Column(name="commodity", type="string", length=255, nullable=true)
     */
    private $commodity;

    /**
     * @var boolean
     *
     * @ORM\Column(name="cooling", type="boolean", nullable=false)
     */
    private $cooling;

    /**
     * @var boolean
     *
     * @ORM\Column(name="drenching", type="boolean", nullable=false)
     */
    private $drenching;

    /**
     * @var boolean
     *
     * @ORM\Column(name="dump_tank", type="boolean", nullable=false)
     */
    private $dumpTank;

    /**
     * @var boolean
     *
     * @ORM\Column(name="equipment_container", type="boolean", nullable=false)
     */
    private $equipmentContainer;

    /**
     * @var boolean
     *
     * @ORM\Column(name="final_rinse", type="boolean", nullable=false)
     */
    private $finalRinse;

    /**
     * @var boolean
     *
     * @ORM\Column(name="fluming", type="boolean", nullable=false)
     */
    private $fluming;

    /**
     * @var boolean
     *
     * @ORM\Column(name="hand_washing", type="boolean", nullable=false)
     */
    private $handWashing;

    /**
     * @var boolean
     *
     * @ORM\Column(name="hose", type="boolean", nullable=false)
     */
    private $hose;

    /**
     * @var boolean
     *
     * @ORM\Column(name="humidity", type="boolean", nullable=false)
     */
    private $humidity;

    /**
     * @var boolean
     *
     * @ORM\Column(name="ice", type="boolean", nullable=false)
     */
    private $ice;

    /**
     * @var boolean
     *
     * @ORM\Column(name="other", type="boolean", nullable=false)
     */
    private $other;

    /**
     * @var boolean
     *
     * @ORM\Column(name="other_cleaning", type="boolean", nullable=false)
     */
    private $otherCleaning;

    /**
     * @var string
     *
     * @ORM\Column(name="other_method", type="string", length=255, nullable=true)
     */
    private $otherMethod;

    /**
     * @var boolean
     *
     * @ORM\Column(name="other_possible", type="boolean", nullable=false)
     */
    private $otherPossible;

    /**
     * @var string
     *
     * @ORM\Column(name="other_possible_hazard", type="string", length=255, nullable=true)
     */
    private $otherPossibleHazard;

    /**
     * @var boolean
     *
     * @ORM\Column(name="pit", type="boolean", nullable=false)
     */
    private $pit;

    /**
     * @var boolean
     *
     * @ORM\Column(name="pressure_wash", type="boolean", nullable=false)
     */
    private $pressureWash;

    /**
     * @var boolean
     *
     * @ORM\Column(name="recycled", type="boolean", nullable=false)
     */
    private $recycled;

    /**
     * @var boolean
     *
     * @ORM\Column(name="runoff", type="boolean", nullable=false)
     */
    private $runoff;

    /**
     * @var boolean
     *
     * @ORM\Column(name="spray", type="boolean", nullable=false)
     */
    private $spray;

    /**
     * @var boolean
     *
     * @ORM\Column(name="stored", type="boolean", nullable=false)
     */
    private $stored;

    /**
     * @var boolean
     *
     * @ORM\Column(name="tap", type="boolean", nullable=false)
     */
    private $tap;

    /**
     * @var boolean
     *
     * @ORM\Column(name="treated", type="boolean", nullable=false)
     */
    private $treated;

    /**
     * @var boolean
     *
     * @ORM\Column(name="washing", type="boolean", nullable=false)
     */
    private $washing;

    /**
     * @var string
     *
     * @ORM\Column(name="water_first_used", type="string", length=255, nullable=false)
     */
    private $waterFirstUsed;

    /**
     * @var string
     *
     * @ORM\Column(name="water_prior_test", type="string", length=255, nullable=false)
     */
    private $waterPriorTest;

    /**
     * @var string
     *
     * @ORM\Column(name="water_second_test", type="string", length=255, nullable=false)
     */
    private $waterSecondTest;

    /**
     * @var integer
     *
     * @ORM\Column(name="water_source", type="integer", nullable=false)
     */
    private $waterSource;

    /**
     * @var boolean
     *
     * @ORM\Column(name="well", type="boolean", nullable=false)
     */
    private $well;

    /**
     * @var boolean
     *
     * @ORM\Column(name="wetting", type="boolean", nullable=false)
     */
    private $wetting;

    /**
     * @var boolean
     *
     * @ORM\Column(name="working_condition", type="boolean", nullable=false)
     */
    private $workingCondition;

    /**
     * @var string
     *
     * @ORM\Column(name="actions", type="string", length=2, nullable=false)
     */
    private $actions;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
