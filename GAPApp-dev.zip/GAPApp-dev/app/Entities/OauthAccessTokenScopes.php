<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OauthAccessTokenScopes
 *
 * @ORM\Table(name="oauth_access_token_scopes", indexes={@ORM\Index(name="oauth_access_token_scopes_access_token_id_index", columns={"access_token_id"}), @ORM\Index(name="oauth_access_token_scopes_scope_id_index", columns={"scope_id"})})
 * @ORM\Entity
 */
class OauthAccessTokenScopes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \OauthAccessTokens
     *
     * @ORM\ManyToOne(targetEntity="OauthAccessTokens")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="access_token_id", referencedColumnName="id")
     * })
     */
    private $accessToken;

    /**
     * @var \OauthScopes
     *
     * @ORM\ManyToOne(targetEntity="OauthScopes")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="scope_id", referencedColumnName="id")
     * })
     */
    private $scope;


}
