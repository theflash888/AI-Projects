<?php
namespace App\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * FormE
 *
 * @ORM\Table(name="form_e", indexes={@ORM\Index(name="form_e_organization_id_foreign", columns={"organization_id"}), @ORM\Index(name="form_e_user_id_foreign", columns={"user_id"}), @ORM\Index(name="form_e_storage_id_foreign", columns={"storage_id"}), @ORM\Index(name="form_e_confirmed_by_id_foreign", columns={"confirmed_by_id"})})
 * @ORM\Entity
 */
class FormE
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="birds_exterior_devices", type="boolean", nullable=false)
     */
    private $birdsExteriorDevices;

    /**
     * @var boolean
     *
     * @ORM\Column(name="birds_inside_devices", type="boolean", nullable=false)
     */
    private $birdsInsideDevices;

    /**
     * @var string
     *
     * @ORM\Column(name="birds_exterior_devices_info", type="string", length=255, nullable=true)
     */
    private $birdsExteriorDevicesInfo;

    /**
     * @var string
     *
     * @ORM\Column(name="birds_inside_devices_info", type="string", length=255, nullable=true)
     */
    private $birdsInsideDevicesInfo;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rodents_exterior_bait", type="boolean", nullable=false)
     */
    private $rodentsExteriorBait;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rodents_exterior_traps", type="boolean", nullable=false)
     */
    private $rodentsExteriorTraps;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rodents_chemicals", type="boolean", nullable=false)
     */
    private $rodentsChemicals;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rodents_exterior_other", type="boolean", nullable=false)
     */
    private $rodentsExteriorOther;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rodents_inside_traps", type="boolean", nullable=false)
     */
    private $rodentsInsideTraps;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rodents_inside_other", type="boolean", nullable=false)
     */
    private $rodentsInsideOther;

    /**
     * @var string
     *
     * @ORM\Column(name="rodents_exterior_bait_type", type="string", length=255, nullable=true)
     */
    private $rodentsExteriorBaitType;

    /**
     * @var string
     *
     * @ORM\Column(name="rodents_exterior_traps_type", type="string", length=255, nullable=true)
     */
    private $rodentsExteriorTrapsType;

    /**
     * @var string
     *
     * @ORM\Column(name="rodents_exterior_other_info", type="string", length=255, nullable=true)
     */
    private $rodentsExteriorOtherInfo;

    /**
     * @var string
     *
     * @ORM\Column(name="rodents_inside_traps_type", type="string", length=255, nullable=true)
     */
    private $rodentsInsideTrapsType;

    /**
     * @var string
     *
     * @ORM\Column(name="rodents_inside_other_info", type="string", length=255, nullable=true)
     */
    private $rodentsInsideOtherInfo;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_exterior_bait", type="boolean", nullable=false)
     */
    private $insectsExteriorBait;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_exterior_traps", type="boolean", nullable=false)
     */
    private $insectsExteriorTraps;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_exterior_chemicals", type="boolean", nullable=false)
     */
    private $insectsExteriorChemicals;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_exterior_other", type="boolean", nullable=false)
     */
    private $insectsExteriorOther;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_inside_traps", type="boolean", nullable=false)
     */
    private $insectsInsideTraps;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_inside_chemicals", type="boolean", nullable=false)
     */
    private $insectsInsideChemicals;

    /**
     * @var boolean
     *
     * @ORM\Column(name="insects_inside_other", type="boolean", nullable=false)
     */
    private $insectsInsideOther;

    /**
     * @var string
     *
     * @ORM\Column(name="insects_exterior_bait_type", type="string", length=255, nullable=true)
     */
    private $insectsExteriorBaitType;

    /**
     * @var string
     *
     * @ORM\Column(name="insects_exterior_traps_type", type="string", length=255, nullable=true)
     */
    private $insectsExteriorTrapsType;

    /**
     * @var string
     *
     * @ORM\Column(name="insects_exterior_other_info", type="string", length=255, nullable=true)
     */
    private $insectsExteriorOtherInfo;

    /**
     * @var string
     *
     * @ORM\Column(name="insects_inside_traps_type", type="string", length=255, nullable=true)
     */
    private $insectsInsideTrapsType;

    /**
     * @var string
     *
     * @ORM\Column(name="insects_inside_other_info", type="string", length=255, nullable=true)
     */
    private $insectsInsideOtherInfo;

    /**
     * @var string
     *
     * @ORM\Column(name="exterior_chemicals_list", type="text", length=65535, nullable=true)
     */
    private $exteriorChemicalsList;

    /**
     * @var string
     *
     * @ORM\Column(name="inside_chemicals_list", type="text", length=65535, nullable=true)
     */
    private $insideChemicalsList;

    /**
     * @var string
     *
     * @ORM\Column(name="rodents_chemical_list", type="text", length=65535, nullable=true)
     */
    private $rodentsChemicalList;

    /**
     * @var string
     *
     * @ORM\Column(name="other_information", type="text", length=65535, nullable=true)
     */
    private $otherInformation;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = '0000-00-00 00:00:00';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_completed", type="boolean", nullable=false)
     */
    private $isCompleted = '0';

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="confirmed_by_id", referencedColumnName="id")
     * })
     */
    private $confirmedBy;

    /**
     * @var \Organizations
     *
     * @ORM\ManyToOne(targetEntity="Organizations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="organization_id", referencedColumnName="id")
     * })
     */
    private $organization;

    /**
     * @var \EntitiesName
     *
     * @ORM\ManyToOne(targetEntity="EntitiesName")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="storage_id", referencedColumnName="id")
     * })
     */
    private $storage;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;


}
