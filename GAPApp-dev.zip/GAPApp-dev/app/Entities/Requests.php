<?php
namespace App\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * Requests
 *
 * @ORM\Table(name="requests")
 * @ORM\Entity
 */
class Requests
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="token", type="string", length=10, nullable=false)
     */
    private $token;

    /**
     * @var string
     *
     * @ORM\Column(name="org_name", type="string", length=255, nullable=false)
     */
    private $orgName;

    /**
     * @var string
     *
     * @ORM\Column(name="org_type", type="string", length=10, nullable=false)
     */
    private $orgType;

    /**
     * @var string
     *
     * @ORM\Column(name="org_first_name", type="string", length=255, nullable=false)
     */
    private $orgFirstName;

    /**
     * @var string
     *
     * @ORM\Column(name="org_last_name", type="string", length=255, nullable=false)
     */
    private $orgLastName;

    /**
     * @var string
     *
     * @ORM\Column(name="org_audit_company", type="string", length=255, nullable=false)
     */
    private $orgAuditCompany;

    /**
     * @var string
     *
     * @ORM\Column(name="org_audit_cycle", type="string", length=255, nullable=false)
     */
    private $orgAuditCycle;

    /**
     * @var string
     *
     * @ORM\Column(name="org_fns_coordinator", type="string", length=255, nullable=false)
     */
    private $orgFnsCoordinator;

    /**
     * @var string
     *
     * @ORM\Column(name="contact_email", type="string", length=255, nullable=false)
     */
    private $contactEmail;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt = 'CURRENT_TIMESTAMP';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt = '0000-00-00 00:00:00';


}
