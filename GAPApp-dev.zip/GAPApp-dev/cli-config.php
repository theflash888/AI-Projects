<?php
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Tools\Console\ConsoleRunner;
use Doctrine\ORM\Tools\Setup;

require_once "vendor/autoload.php";

$modelsPath = realpath('app/Entities/xml');
$config = Setup::createAnnotationMetadataConfiguration(array($modelsPath), true);
$config->setMetadataDriverImpl(
   new Doctrine\ORM\Mapping\Driver\XmlDriver( $modelsPath )
);

// database configuration parameters
$connection = [
    'driver' => 'pdo_mysql',
    'host' => 'localhost',
    'dbname' => 'gapapp_database',
    'user' => 'root',
    'password' => 'devsql'
];
$em = EntityManager::create($connection, $config);
$conn = $em->getConnection();
$conn->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
return ConsoleRunner::createHelperSet($em);
