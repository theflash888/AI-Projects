@extends('dashboard.home')

@section('dashboard-content')
	@if(!Request::is('dashboard/report'))
	<div class="row">
		<div class="large-12 columns">
			<md-content style="margin: 20px 0; padding: 20px;" ng-controller="ReportSearchController">
				<form name="ReportSearchRange" >
					<div layout="row">
						<div flex>
							<span>Start Date:</span>
							<md-datepicker required ng-model="report.startdate" md-placeholder="Enter date"></md-datepicker>
						</div>
						<div flex>
							<span>End Date:</span>
							<md-datepicker required ng-model="report.enddate" md-placeholder="Enter date"></md-datepicker>
						</div>
						<div>
							<md-button class="md-raised md-primary" ng-disabled="ReportSearchRange.$invalid" ng-click="startReportSearch('{{ $form }}')" style="padding: 0 20px;">Find Records</md-button>
							@if($startDate && $endDate)
							<md-button class="md-raised md-primary DownloadReport" ng-click="downloadReport('{{ $form }}', '{{ $startDate }}', '{{ $endDate }}')" style="padding: 0 20px;">Download Report</md-button>
							@endif
						</div>
					</div>
				</form>
			</md-content>
		</div>
	</div>
	@endif
	@if($form && ($form == "H1" || $form == "Q"))
	<div class="row animated fadeIn FullWidth">
	@else
<div class="row animated fadeIn">
	@endif
		<div class="large-12 columns">
			@if($form)
				@include ('dashboard.reports.templates.form_' . $form)
			@else
				@include ('dashboard/reports/reports_new')
			@endif
		</div>
	</div>
@stop
