@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> If using chlorine to treat water, complete the following chart to control and monitor your chlorine treatment at least daily or more frequently based on your operation’s needs. Refer to Appendix B: Chlorination of Water for Fluming and Cleaning Fresh Fruits and Vegetables and Cleaning Equipment – An Example for an example of chlorinating instructions.</p>
	<br>
	@if($startDate && $endDate)
		{? $form_n1 = \App\Models\FormN1::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
	@else
		{? $form_n1 = $org->forms_N1 ?}
	@endif
  @foreach($form_n1 as $n1)
  <table style="width: 100%;">
      <tr>
          <td style="width: 50%;">
              <p style="margin: 0;">
                <b>Water Source:</b>
                @if($n1->water_source == 1)
                    Municipal Water
                @elseif($n1->water_source == 2)
                    Well Water and Tertiary Water
                @elseif($n1->water_source == 3)
                    Pond/Reservoir/Dugout Fed by Groundwater (spring/wells) or Rainwater
                @elseif($n1->water_source == 4)
                    Pond/Dugout Fed by Stream, Ditch or Run-Off
                @elseif($n1->water_source == 5)
                    River, Stream, Creek, Canal, Flooding
                @endif
              </p>
          </td>
          <td style="width: 50%;">
              <b>Concentration of Chlorine:</b> {{ $n1->chlorine_concentration }}</b>
          </td>
      </tr>
      <tr>
          <td style="width: 50%;">
              <p style="margin: 0;">
                <b>Method (e.g., injection):</b> {{ $n1->method }}
              </p>
          </td>
          <td style="width: 50%;">
              <b>Volume of Water:</b> {{ $n1->volume }}
          </td>
      </tr>
      <tr>
          <td style="width: 50%;">
              <p style="margin: 0;">
                <b>Re-circulated Water:</b>@if($n1->recirculated_water == 1) <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> Yes No @else Yes <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> No @endif
              </p>
          </td>
          <td style="width: 50%;">
              <b>Contact Time: </b>{{ $n1->contact_time }}
          </td>
      </tr>
      <tr>
          <td style="width: 50%;">
              <p style="margin: 0;">
                <b>Month/Date: </b>{{ substr($n1->created_at, 0, -9) }}
              </p>
          </td>
      </tr>
  </table>
  <br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100%;">
		<thead>
			<tr>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date/Time</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Pre-treatment Concentration of Chlorine (ppm) or ORP</th>
				<th width="10%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Amount of Chlorine Added</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Post-treatment Concentration of Chlorine (ppm) or ORP</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">pH of Water</th>
        <th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Water Changed</th>
        <th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Person Responsible</th>
			</tr>
		</thead>
		<tbody>
        <tr>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n1->created_at }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n1->pre_treatment }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n1->chlorine_added }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n1->post_treatment }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n1->water_ph }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;"> <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">{{ ($n1->water_changed == 1) ? "✔" : "&#10005;" }}</span></td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n1->author->first }} {{ $n1->author->last }}</td>
        </tr>
		</tbody>
	</table>
  @endforeach
	</div>
@endforeach
