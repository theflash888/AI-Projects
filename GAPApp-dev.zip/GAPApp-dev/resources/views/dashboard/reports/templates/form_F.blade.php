@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Complete and/or update annually for all water sources.  Check off (ü) those items that apply.  </p>
	<br>
	@if($startDate && $endDate)
                {? $form_f = \App\Models\FormF::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_f = $org->forms_F ?}
            @endif

            @foreach($form_f as $f)
            <table>
              <tr>
                <td style="width: 500px;"><b>Completed by:</b> {{ $f->author->first }} {{ $f->author->last }}</td>
                <td style="width: 50%;"><b>Date:</b> {{ $f->created_at }}</td>
              </tr>
            </table>
            <br>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;">
                <thead>
                    <tr>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Water Source</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Re-cycled</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Stored</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Commodity</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Use</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Method</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Items to Access</th>
                        <th colspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Water tests</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Corrective Actions</th>
                        <th rowspan="2" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Cleaning and Treatment</th>
                    </tr>
                    <tr>
                        <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">When will the water first be used?</th>
                        <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Dates</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          @if($f->water_source == 1)
                          Municipal Water
                          @elseif($f->water_source == 2)
                          Well Water and Tertiary Water
                          @elseif($f->water_source == 3)
                          Pond/Reservoir/Dugout Fed by Groundwater (spring/wells) or Rainwater
                          @elseif($f->water_source == 4)
                          Pond/Dugout Fed by Stream, Ditch or Run-Off
                          @elseif($f->water_source == 5)
                          River, Stream, Creek, Canal, Flooding
                          @endif
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($f->recycled == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($f->stored == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $f->commodity }}</td>
                        <td style="padding: 0px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          <ul style="list-style: none; margin: 0;">
                            <li>@if($f->fluming == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Fluming</li>
                            <li>@if($f->cooling == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Hydro-cooling/cooling</li>
                            <li>@if($f->washing == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Washing</li>
                            <li>@if($f->drenching == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Drenching</li>
                            <li>@if($f->final_rinse == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Drenching</li>
                            <li>@if($f->chemical_application == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif FOR POTATOES ONLY: Chemical application (during packing)</li>
                            <li>@if($f->wetting == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Wetting packing accessories</li>
                            <li>@if($f->humidity == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Humidity/Misting</li>
                            <li>@if($f->hand_washing == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Hand washing</li>
                            <li>@if($f->equipment_container == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Cleaning equipment containers/building</li>
                            <li>@if($f->ice == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Ice</li>
                          </ul>
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          <ul style="list-style: none;">
                            <li>@if($f->pit == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Pit</li>
                            <li>@if($f->spray == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Spray</li>
                            <li>@if($f->hose == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Hose</li>
                            <li>@if($f->tap == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Tap</li>
                            <li>@if($f->dump_tank == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Dump tank</li>
                            <li>@if($f->pressure_wash == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Pressure wash</li>
                            <li>@if($f->other == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Other: {{ $f->other_method }}</li>
                          </ul>
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          <ul style="list-style: none;">
                            <li>@if($f->animal_access == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Animals access</li>
                            <li>@if($f->runoff == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Runoff</li>
                            <li>@if($f->working_condition == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Working condition of well/pipes</li>
                            <li>@if($f->other_possible == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Other possible hazards assessed (describe): {{ $f->other_possible_hazard }}</li>
                          </ul>
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          {{ substr($f->water_first_used, 0, -14) }}
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          <p>
                            Prior to use test {{ substr($f->water_prior_test, 0, -14) }}
                          </p>
                          <br>
                          <p>
                            2nd water test {{ substr($f->water_second_test, 0, -14) }}
                          </p>

                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          {{ $f->actions }}
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                          <ul style="list-style: none;">
                            <li>@if($f->cleaned == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Cleaned</li>
                            <li>@if($f->treated == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Treated</li>
                            <li>@if($f->cistern == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Cistern</li>
                            <li>@if($f->well == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Well</li>
                            <li>@if($f->other_cleaning == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif Other</li>
                          </ul>
                          <br>
                          <ul style="list-style: none;">
                            <li>@if($f->appendix_a == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif A</li>
                            <li>@if($f->appendix_b == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif B</li>
                            <li>@if($f->appendix_h == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif H</li>
                            <li>OR: {{ $f->appendix_or }}</li>
                          </ul>
                        </td>
                    </tr>
                </tbody>
            </table>
     @endforeach
	</div>
@endforeach
