@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Fill out the chart below to assess the potential risks of allergens in your operation. Column I indicates the allergens from a practice used in the production of the product. Column II indicates the allergens from something in the production site (e.g., rotational crop). Column III indicates the allergens that may be found in the product, from addition or cross-contamination. Column IV indicates the allergens present in other products that are run on the same equipment/area but at a different time. Column V indicates whether any allergens are present in a building/vehicle.</p>
  <p>
    <i>Each box of the table must be filled with a YES or a NO. If YES, describe (if applicable) any control measures used in the last row. All allergens listed are those identified by Health Canada and enforced for labelling by the Canadian Food Inspection Agency.</i>
  </p>
	<br>
  @if($startDate && $endDate)
                {? $form_s = \App\Models\FormS::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_s = $org->forms_S ?}
            @endif

            @foreach($form_s as $s)
	<table style="width: 100%;">
	   <tr>
	      <td style="width: 50%">
	         <p>
	           <b>Completed by: </b> {{ $s->author->first }} {{ $s->author->last }}
	         </p>
	      </td>
        <td style="width: 50%">
            <p>
              <b>Date: </b> {{ substr($s->created_at, 0, -9) }}
            </p>
        </td>
	   </tr>
	</table>
  <p style="margin: 0;">
     <b>Production Site ID/Building ID #/Name: </b> {{ $s->production->name }}
  </p>
  <br>
  <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-bottom: 0;">
      <thead>
          <tr>
              <th style="width: 50%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 12px;">

              </th>
              <th style="width: 10%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 12px;">
                Column I
              </th>
              <th style="width: 10%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 12px;">
                Column II
              </th>
              <th style="width: 10%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 12px;">
                Column III
              </th>
              <th style="width: 10%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 12px;">
                Column IV
              </th>
              <th style="width: 10%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 12px;">
                Column V
              </th>
          </tr>
          <tr>
              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                Component
              </th>
              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                Present from a production practice
              </th>
              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                Present in the production site
              </th>
              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                Present in the product
              </th>
              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                Present in other products handled on the same line/area
              </th>
              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                Present in the same building/ vehicle
              </th>
          </tr>
      </thead>
      <tbody>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Peanut or its</b> derivatives, e.g., Peanut - pieces, protein, oil, butter, flour, and mandelona nuts (an almond flavoured peanut product) etc. Peanut may also be known as ground nut.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->peanut_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->peanut_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->peanut_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->peanut_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->peanut_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Tree Nuts</b> e.g., almonds, Brazil nuts, cashews, hazelnuts (filberts), macadamia nuts, pecans, pine nuts (pinyon, pinon), pistachios and walnuts or their derivatives, e.g., nut butters and oils etc.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->tree_nuts_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->tree_nuts_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->tree_nuts_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->tree_nuts_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->tree_nuts_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Sesame or its</b> derivatives, e.g., paste and oil etc.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sesame_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sesame_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sesame_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sesame_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sesame_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Milk or its derivatives</b>, e.g., milk caseinate, whey and yogurt powder etc.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->milk_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->milk_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->milk_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->milk_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->milk_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Fish or its</b> derivatives, e.g., fish protein and extracts etc.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->fish_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->fish_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->fish_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->fish_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->fish_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Shellfish</b> (including crab, crayfish, lobster, prawn and shrimp) and <b>Molluscs</b> (including snails, clams, mussels, oysters, cockle and scallops) <b>or their</b> derivative, e.g., extracts etc.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->shellfish_molluscs_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->shellfish_molluscs_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->shellfish_molluscs_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->shellfish_molluscs_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->shellfish_molluscs_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Cereals containing gluten</b> and their derivatives (specify which cereal (wheat, rye, barley, oats, spelt, kamut or their hybridised strains)).
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->cereals_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->cereals_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->cereals_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->cereals_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->cereals_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Soybeans or its</b> derivatives, e.g., lecithin, oil, tofu and protein isolates etc.
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->soybeans_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->soybeans_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->soybeans_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->soybeans_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->soybeans_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Sulphites</b>, e.g., sulphur dioxide and sodium metabisulphites etc. If yes, what is the amount in ppm? ____________________
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sulphites_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sulphites_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sulphites_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sulphites_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->sulphites_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Mustard</b> and products thereof
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->mustard_1) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->mustard_2) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                {{ strtoupper($s->mustard_3) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->mustard_4) }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; font-size: 14px;">
                  {{ strtoupper($s->mustard_5) }}
              </td>
          </tr>
          <tr>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  <b>Others</b> (as considered necessary for the customer)
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  {{ $s->others_1 }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  {{ $s->others_2 }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  {{ $s->others_3 }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  {{ $s->others_4 }}
              </td>
              <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
                  {{ $s->others_5 }}
              </td>
          </tr>
      </tbody>
  </table>
  <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-top: 0; margin: 0;">
      <tr>
          <td style="width: 50%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
            Comments and/or Additional Control Measures (if applicable)
          </td>
          <td style="width: 50%; padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; font-size: 14px;">
            {{ $s->comments }}
          </td>
      </tr>
  </table>
  @endforeach
	</div>
@endforeach
