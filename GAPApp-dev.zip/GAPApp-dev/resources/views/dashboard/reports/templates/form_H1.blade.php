@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> Includes all applications from pre-planting through to, and including, harvest/storage. One Form must be completed for EACH PRODUCTION SITE.</p>
	<br>
    @if($startDate && $endDate)
                {? $form_h1 = \App\Models\FormH1::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_h1 = $org->forms_H1 ?}
            @endif

            @foreach($form_h1 as $h1)
						<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
							<tbody>
					        	<tr>
					            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					            		<b>Operation Name:</b>
					            		<p style="text-align: center; margin: 5px;">{{ $h1->operation_name }}</p>
					            	</td>
					            	<td width="25%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					            		<b>Previous Year Crop(s):</b>
					            		<p style="text-align: center; margin: 5px;">{{ $h1->previous_year_crops }}</p>
					            	</td>
					            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					            		<b>FOR POTATOES ONLY:</b>
					            		<p style="text-align: center; margin: 5px;"><b>Seed Certification #:</b> {{ $h1->seed_certificate }}</p>
					            	</td>
					            	<td width="40%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
										<b>Current Crop:</b>
										<p style="text-align: center; margin: 5px;">{{ $h1->current_crop }}</p>
									</td>
					        	</tr>
					        	<tr>
					            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					            		<b>Production Site Information (e.g., Field/Block # or Name/ID/Legal Description):</b>
					            		<p style="text-align: center; margin: 5px;">{{ $h1->production->name }}</p>
					            	</td>
					            	<td width="25%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					            		<b>Production Site Area(e.g., # of  acres/hectares):</b>
					            		<p style="text-align: center; margin: 5px;">{{ $h1->production_site_area }}</p>
					            	</td>
					            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					            		<b>Date Planted:</b>
					            		<p style="text-align: center; margin: 5px;">{{ substr($h1->date_planted, 0, -14) }}</p>
					            	</td>
					            	<td width="40%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
										<b>Variety</b>
										<p style="text-align: center; margin: 5px;">{{ $h1->variety }}</p>
									</td>
					        	</tr>
							</tbody>
						</table>
						<br>
    <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
        <thead>
            <tr>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Application Date</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Product/Trade Name</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">PCP #</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Actual Quantity Used</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Rate Applied Per Unit</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Label Instructions Followed</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Area Treated</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Method of Application</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Earliest Allowable Harvest Date (EAHD)</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">PHI/DAA</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Weather Conditions</th>
                <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Signature of Applicator or if Custom Application Invoice is Attached</th>
            </tr>
        </thead>
				<tbody>
						<tr>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ substr($h1->created_at, 0, -9) }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->product_trade_name }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->pcp }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->actual_quantity_used }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->rate_applied }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;"><span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($h1->label_followed == 1) ✔ @else &#10005; @endif</span></td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->area_treated }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->method_of_application }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ substr($h1->eahd, 0, -14) }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->phi_daa }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->weather_condition }}</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 0;">{{ $h1->author->first }} {{ $h1->author->last }}</td>
						</tr>
				</tbody>
    </table>
    @endforeach
	</div>
@endforeach
