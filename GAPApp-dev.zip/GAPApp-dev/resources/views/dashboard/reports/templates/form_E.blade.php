@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 10%;
	}
	.MainTable tr th:nth-child(2) {
		width: 80%;
	}
	.MainTable tr th:nth-child(3) {
		width: 10%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> For each type of pest being controlled, specify the pest control method used. This Form is to be completed annually.</p>
	<br>
	@if($startDate && $endDate)
                {? $form_e = \App\Models\FormE::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_e = $org->forms_E ?}
            @endif

              @foreach($form_e as $e)
            <table>
              <tr>
                <td style="width: 500px;"><b>Completed by:</b> {{ $e->author->first }} {{ $e->author->last }}</td>
                <td style="width: 50%;"><b>Date:</b> {{ $e->created_at }}</td>
              </tr>
            </table>
						<p>
							<b>Building ID # / Name:</b> {{ $e->author->first }} {{ $e->author->last }}
						</p>
            <br>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;" class="MainTable">
                <thead>
                    <tr>
                        <th width="10" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                          Pest
                        </th>
                        <th width="80" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                          Control Method and Description
                        </th>
                        <th width="10" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                          Person Responsible
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            Birds
                        </td>
                        <td style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                            <h4 style="margin: 0 !important;">Around building exterior</h4>
                            <table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->birds_exterior_devices == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Deterrent or other devices (specify)</span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->birds_exterior_devices_info }}
                                  </td>
                                </tr>
                            </table>
														<hr style="background-color: rgba(0, 0, 0, 0.7) !important;">
														<h4 style="margin: 0 !important;">Inside building</h4>
                            <table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important;">
                                      @if($e->birds_inside_devices == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Deterrent or other devices (specify)</span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->birds_inside_devices_info }}
                                  </td>
                                </tr>
                            </table>
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            {{ $e->author->first }} {{ $e->author->last }}
                        </td>
                    </tr>

										<tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            Rodents
                        </td>
                        <td style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                            <h4 style="margin: 0 !important;">Around building exterior (perimeter)</h4>
                            <table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->rodents_exterior_bait == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Bait (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->rodents_exterior_bait_type }}
                                  </td>
                                </tr>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->rodents_exterior_traps == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->rodents_exterior_traps_type }}
                                  </td>
                                </tr>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 10px;">
                                      @if($e->rodents_chemicals == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Chemicals (specify below) </span>
                                  </td>
                                </tr>
                            </table>
														<br>

														<table style="margin: 0 10px; border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" >
																<thead>
																		<tr>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					Name of Chemical
																				</th>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					PCP #
																				</th>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					Concentration
																				</th>
																		</tr>
																</thead>
																<tbody>

																		<tr>
																				<td>

																				</td>
																				<td>

																				</td>
																				<td>

																				</td>
																		</tr>
																</tbody>
														</table>
														<table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->rodents_exterior_other == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Other (specify) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->rodents_exterior_other_info }}
                                  </td>
                                </tr>
                            </table>
														<hr style="background-color: rgba(0, 0, 0, 0.7) !important;">
														<h4 style="margin: 0 !important;">Inside building</h4>
                            <table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important;">
                                      @if($e->rodents_inside_traps == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->rodents_inside_traps_type }}
                                  </td>
                                </tr>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important;">
                                      @if($e->rodents_inside_other == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->rodents_inside_other_info }}
                                  </td>
                                </tr>
                            </table>
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            {{ $e->author->first }} {{ $e->author->last }}
                        </td>
                    </tr>

										<tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            Insects
                        </td>
                        <td style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                            <h4 style="margin: 0 !important;">Around building exterior</h4>
                            <table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->insects_exterior_bait == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Bait (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->insects_exterior_bait_type }}
                                  </td>
                                </tr>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->insects_exterior_traps == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->insects_exterior_traps_type }}
                                  </td>
                                </tr>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 10px;">
                                      @if($e->insects_inside_chemicals == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Chemicals (specify below) </span>
                                  </td>
                                </tr>
                            </table>
														<br>
														<table style="margin: 0 10px; border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" >
																<thead>
																		<tr>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					Name of Chemical
																				</th>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					PCP #
																				</th>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					Concentration
																				</th>
																		</tr>
																</thead>
																<tbody>
																		<tr>
																				<td>

																				</td>
																				<td>

																				</td>
																				<td>

																				</td>
																		</tr>
																</tbody>
														</table>
														<br>
														<table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important; line-height: 5px;">
                                      @if($e->insects_exterior_other == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Other (specify) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->insects_exterior_other_type }}
                                  </td>
                                </tr>
                            </table>
														<br>
														<hr style="background-color: rgba(0, 0, 0, 0.7) !important;">
														<h4 style="margin: 0 !important;">Inside building</h4>
                            <table>
                                <tr>
                                  <td style="padding: 0 !important; margin: 0 !important;">
                                      @if($e->insects_inside_traps == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (e.g., glue boards, sticky traps) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->insects_inside_traps_type }}
                                  </td>
                                </tr>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important;">
                                      @if($e->insects_inside_chemicals == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (specify type) </span>
                                  </td>
                                </tr>
														</table>
														<br>
														<table style="margin: 0 10px; border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" >
																<thead>
																		<tr>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					Name of Chemical
																				</th>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					PCP #
																				</th>
																				<th style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
																					Concentration
																				</th>
																		</tr>
																</thead>
																<tbody>
																		<tr>
																				<td>

																				</td>
																				<td>

																				</td>
																				<td>

																				</td>
																		</tr>
																</tbody>
														</table>
														<table>
																<tr>
                                  <td style="padding: 0 !important; margin: 0 !important;">
                                      @if($e->insects_inside_other == 1) <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @endif <span style="display: inline-block; vertical-align: middle;">Traps (specify type) </span>
                                  </td>
                                  <td style="text-align: right !important; padding-left: 50px;">
																		{{ $e->insects_inside_other_info }}
                                  </td>
                                </tr>
                            </table>
                        </td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            {{ $e->author->first }} {{ $e->author->last }}
                        </td>
                    </tr>

										<tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            Other <br> (specify)
                        </td>
                        <td style="padding: 0 10px !important; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
														{{ $e->other_information }}
												</td>
												<td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                            {{ $e->author->first }} {{ $e->author->last }}
                        </td>
                </tbody>
            </table>
						<br>
     @endforeach
	</div>
@endforeach
