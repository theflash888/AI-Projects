@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> Instructions: An inspection of both the interior and exterior of your buildings (e.g., packinghouse, storages) (except agricultural chemical storage buildings) must be conducted monthly [when in use and where possible (e.g., not a sealed storage)] and the following checklist completed. Place N/A if certain structures are not applicable to your operation.</p>
  <br>
  @if($startDate && $endDate)
                {? $form_g = \App\Models\FormG::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_g = $org->forms_G ?}
            @endif

            @foreach($form_g as $g)
            <table>
              <tr>
                <td style="width: 500px;"><b>Completed by:</b> {{ $g->author->first }} {{ $g->author->last }}</td>
                <td style="width: 50%;"><b>Date:</b> {{ $g->created_at }}</td>
              </tr>
              <tr>
                <td style="width: 500px;"><b>Building ID #/Name:</b> {{ $g->storage->name }}</td>
              </tr>
            </table>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;">
                <tr>
                    <td style="width: 50%; padding: 0; border: 1px solid rgba(0, 0, 0, 0.5); vertical-align: top;">
												@if($g->building_type == 1 || $g->building_type == 3)
                        <div style="padding: 0 10px;">
                            <h4 style="text-align: center; margin: 5px;">Interior of Building <br> (Permanent Structures)</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->no_holes == "yes") ✔ @elseif($g->no_holes == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      No holes/crevices/leaks in the building (e.g., walls,  windows, screens)                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->shatterproof == "yes") ✔ @elseif($g->shatterproof == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Lighting is shatterproof and adequate (e.g., packinghouse is bright while potatoe storages are dark)
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->no_pipes == "yes") ✔ @elseif($g->no_pipes == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      No pipes or condensation leaking
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->floor_drainage == "yes") ✔ @elseif($g->floor_drainage == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Floor drainage is good (floor sloped, drain covers clear)
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->floors_clean == "yes") ✔ @elseif($g->floors_clean == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Floors, walls and ceilings are clean and free from garbage, spills, rodent droppings, etc.
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->floor_free_pests == "yes") ✔ @elseif($g->floor_free_pests == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Floor is free of crevices that could harbour pests or debris
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->fans_air_free == "yes") ✔ @elseif($g->fans_air_free == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Fans and/or air filters are dust-free, clean and working properly
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->animals == "yes") ✔ @elseif($g->animals == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Animals (wild or domestic), pests (insects, rodents, etc.) and bird nests are not present
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->material_designated == "yes") ✔ @elseif($g->material_designated == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      All materials are in designated areas (e.g., packaging materials and product)
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->adequate_ventilation == "yes") ✔ @elseif($g->adequate_ventilation == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Adequate ventilation
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->control_measures == "yes") ✔ @elseif($g->control_measures == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Control measures are in place to prevent cross-contamination from other activities/items (e.g., employee movement, dedicated areas/equipment, etc.)
                                    </td>
                                </tr>
                            </table>
                            </div>
														@endif
                          </td>
                          <td style="width: 50%; margin: 0; vertical-align: top;">
														@if($g->building_type == 2 || $g->building_type == 3)
                            <div style="padding: 0 10px;">
                                <h4 style="text-align: center; margin: 5px;">Exterior of Building <br> (Permanent Structures)</h4>
                                <table>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->no_exterior_holes == "yes") ✔ @elseif($g->no_exterior_holes == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          No holes/crevices/leaks in the building (e.g., walls, windows, screens)
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_windows_closed == "yes") ✔ @elseif($g->exterior_windows_closed == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          All windows can be closed OR have close-fitting screens are in good condition
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_half_perimeter == "yes") ✔ @elseif($g->exterior_half_perimeter == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          ½ meter wide perimeter strip of stone or crushed gravel OR short grass around building
                                        </td>
                                    </tr>
																		<tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_no_junk == "yes") ✔ @elseif($g->exterior_no_junk == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          No junk piled within 3 m of building (e.g., old or unused machinery, garbage)
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_weeds == "yes") ✔ @elseif($g->exterior_weeds == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Weeds are controlled
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_land_drainage == "yes") ✔ @elseif($g->exterior_land_drainage == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        Land drainage around building is good
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_dumpster == "yes") ✔ @elseif($g->exterior_dumpster == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        Dumpsters are emptied as needed to prevent pest infestation, and surroundings are free of debris
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_doors_close_fitting == "yes") ✔ @elseif($g->exterior_doors_close_fitting == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        All doors are close-fitting
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_doors_secured == "yes") ✔ @elseif($g->exterior_doors_secured == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        Doors that can be secured (i.e., to lock storages when unsupervised)
                                        </td>
                                    </tr>
                                </table>
                                <hr>
                                <h4 style="text-align: center; margin: 5px;">Exterior of Building <br> (Non-Permanent Structures)</h4>
                                <table>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_roof_cover == "yes") ✔ @elseif($g->exterior_roof_cover == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        Roof or Cover (i.e., tarp)
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_land_drainage_structure == "yes") ✔ @elseif($g->exterior_land_drainage_structure == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        Land drainage around structure is good
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_no_areas_pests == "yes") ✔ @elseif($g->exterior_no_areas_pests == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        No areas where pests can live/feed/hide within 3 m of structure (e.g., old or unused machinery, garbage)
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($g->exterior_weeds_controlled == "yes") ✔ @elseif($g->exterior_weeds_controlled == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                        Weeds are controlled
                                        </td>
                                    </tr>
                                </table>
                              </div>
															@endif
                          </td>
                      </tr>
                    </table>
                    <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-bottom: none !important;">
                        <tr>
                            <td style="width: 50%; padding: 0; border: 1px solid rgba(0, 0, 0, 0.5); vertical-align: top;">
															@if($g->building_type == 1 || $g->building_type == 3)
                                <div style="padding: 0 10px;">
                                    <h4 style="text-align: center; margin: 5px;">Maintenance Required</h4>
                                    <p>
                                      <b>If any of the above has NOT been checked off, please describe the maintenance required.</b>
                                    </p>
                                    <p>
                                      {{ $g->interior_maintenance }}
                                    </p>
                                    <hr>
                                    <p>
                                      <b>Date and name of person work was completed by:</b>
                                    </p>
                                    <p>
                                      {{ $g->interior_maintenance_completed_by }} {{ substr($g->interior_maintenance_completed_date, 0, -14) }}
                                    </p>
                                    <hr>
                                    <p>
                                      <b>Date and name of person work was completed by:</b>
                                    </p>
                                    <p>
                                      {{ $g->interior_maintenance_overseen_by }} {{ substr($g->interior_maintenance_overseen_date, 0, -14) }}
                                    </p>
                                </div>
																@endif
                            </td>
                            <td style="width: 50%; padding: 0; border: 1px solid rgba(0, 0, 0, 0.5); vertical-align: top;">
																@if($g->building_type == 2 || $g->building_type == 3)
                                <div style="padding: 0 10px;">
                                    <h4 style="text-align: center; margin: 5px;">Maintenance Required</h4>
                                    <p>
                                      <b>If any of the above has NOT been checked off, please describe the maintenance required.</b>
                                    </p>
                                    <p>
                                      {{ $g->exterior_maintenance }}
                                    </p>
                                    <hr>
                                    <p>
                                      <b>Date and name of person work was completed by:</b>
                                    </p>
                                    <p>
                                      {{ $g->exterior_maintenance_completed_by }} {{ substr($g->exterior_maintenance_completed_date, 0, -14) }}
                                    </p>
                                    <hr>
                                    <p>
                                      <b>Date and name of person work was completed by:</b>
                                    </p>
                                    <p>
                                      {{ $g->exterior_maintenance_overseen_by }} {{ substr($g->exterior_maintenance_overseen_date, 0, -14) }}
                                    </p>
                                </div>
																@endif
                            </td>
                        </tr>
                    </table>
     @endforeach
	</div>
@endforeach
