@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> List all minor deviations, complaints and their related cause(s), corrective action(s), preventative measures and modified procedures. </p>
	<br>
	@if($startDate && $endDate)
                {? $form_r2 = \App\Models\FormR2::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_r2 = $org->forms_R2 ?}
            @endif

            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;">
                  <thead>
                        <tr>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date/Time of Deviation or Complaint and Person Notified</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Major Deviation/Complaint and Description</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Cause of Deviation/Complaint</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Corrective Action(s)</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Signature of Person Responsible for Re-Training/Carrying out Deviation Procedure</th>
                        </tr>
                  </thead>
                  <tbody>


            @foreach($form_r2 as $r2)
                  <tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $r2->created_at }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $r2->major_deviation }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $r2->cause_of_deviation }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $r2->corrective_action }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $r2->author->first }} {{ $r2->author->last }}</td>
                  </tr>
     @endforeach
     </tbody>
            </table>
	</div>
@endforeach
