@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div> 
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Traps and control methods must be monitored a minimum of once a month (when in use) and the findings and action taken (if applicable) recorded below. Each trap or area controlled (e.g., for insects) must be recorded. Make additional copies as necessary.</p>
	<br>
	@if($startDate && $endDate)
		{? $form_m = \App\Models\FormM::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
	@else
		{? $form_m = $org->forms_M ?}
	@endif
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
		<thead>
			<tr>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Device Number (same as Form A) or Area Controlled (e.g., insect traps)</th>
				<th width="40%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Findings</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Action Taken (cleaned area or traps, disposed of in garbage, chemical treatment, changed traps, etc.)</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Person Responsible</th>
			</tr>
		</thead>
		<tbody>		
			@foreach($form_m as $m)
                    <tr>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$m->created_at}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$m->device_number}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$m->findings}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$m->action_taken}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$m->author->first}} {{$m->author->last}}</td>
                    </tr>
                    @endforeach
		</tbody>
	</table>
	</div>
@endforeach