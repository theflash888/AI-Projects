@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> Includes all applications during packing.</p>
	<br>
	@if($startDate && $endDate)
                {? $form_h3 = \App\Models\FormH3::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_h3 = $org->forms_H3 ?}
            @endif

              @foreach($form_h3 as $h3)
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100%;">
		<tbody>
        	<tr>
            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Operation Name:</b>
            		<p style="text-align: center; margin: 5px;">{{ $h3->operation_name }}</p>
            	</td>
            	<td width="25%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Production Site Information (e.g., Field # or Name/ID #/Legal Description):</b>
            		<p style="text-align: center; margin: 5px;">{{ $h3->production->name }}</p>
            	</td>
            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Variety:</b>
            		<p style="text-align: center; margin: 5px;">{{ $h3->variety }}</p>
            	</td>
        	</tr>
		</tbody>
	</table>
  <br>
  <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100%; text-align: left;">
			<thead>
					<tr>
							<th style="width: 12%; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Date
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Product/Trade Name
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								PCP #
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Rate Applied Per Unit (cwt/tonne)
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Quantity Treated
							</th>
              <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Lot ID
							</th>
              <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								DAA
							</th>
              <th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Signature of Applicator or if Custom Application Invoice is Attached
							</th>
					</tr>
			</thead>
			<tbody>
					<tr>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ substr($h3->created_at, 0, -9) }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->product_name }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->pcp }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->rate_applied }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->quantity_treated }}
							</td>
              <td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->lot_id }}
							</td>
              <td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->daa }}
							</td>
              <td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h3->author->first }} {{ $h3->author->last }}
							</td>
					</tr>
			</tbody>
	</table>
	<br>
	@endforeach
	</div>
@endforeach
