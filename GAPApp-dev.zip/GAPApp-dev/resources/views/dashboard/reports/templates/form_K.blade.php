@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div> 
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Document when the Employee Personal Hygiene and Food Handling Practices Policy (Forms C Employee Personal Hygiene and Food Handling Practices Policy – Production Site and D Employee Personal Hygiene and Food Handling Practices Policy - Packinghouse/Product Storage) and minor and major deviations training session is held for all employees handling product/packaging materials/food contact surfaces.  In cases where employee names and signatures are not recorded, indicate in the final column where further records are available (e.g., payroll records, contractor records) to track training of employees.</p>
	<br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
		<thead>
			<tr>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Number of Employees Trained or Employee Name</th>
				<th width="20%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Topic Covered [Form C or D, minor and major deviations, or other (describe)]</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Person Responsible for Training</th>
				<th width="40%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Casual Employee (C), Contract Employee (CE), Payroll Record (P) or Employee Signature</th>
			</tr>
		</thead>
		<tbody>
			@if($startDate && $endDate)
				{? $form_k = \App\Models\FormK::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
			@else
				{? $form_k = $org->forms_K ?}
			@endif
			
			@foreach($form_k as $k)
                    <tr>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$k->created_at}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$k->employees}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$k->topics}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$k->responsible}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$k->signature}}</td>
                    </tr>
                    @endforeach
		</tbody>
	</table>
	</div>
@endforeach