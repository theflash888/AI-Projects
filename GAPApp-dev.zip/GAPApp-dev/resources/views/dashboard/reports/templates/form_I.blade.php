@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div> 
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><i>Use this Form to record production site AND building equipment cleaning, maintenance AND calibration.</i></p>
	<br>
	<p><b>Instructions:</b> An inspection of your building equipment (e.g., cutting blades, brushes, packing/repacking lines, conveyors, belts, chlorinator, sprayer) must be conducted at least weekly (when in use). Check for leaks, broken, loose, corroded or damaged parts, soil, mud, build-up, etc. and any cleaning, maintenance and calibration needed. Hand-held cutting and trimming tools that come into direct contact with product must be inspected and cleaned daily with this activity recorded daily. See Section 8: Equipment for requirements for production site equipment. Record required activities below and give a brief description of why and how you are performing the activity. </p>
	<br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
		<thead>
			<tr>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Employee Completing Job</th>
				<th width="20%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Equipment Activity Performed On</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Activity Code*</th>
				<th width="40%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Brief Description of Activity</th>
			</tr>
		</thead>
		<tbody>
			@if($startDate && $endDate)
				{? $form_i = \App\Models\FormI::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
			@else
				{? $form_i = $org->forms_I ?}
			@endif
			
			@foreach($form_i as $i)
                    <tr>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->created_at}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->employee}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->equipment}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                          @if($i->activity_code == 6)
                            {{ $i->activity_code }} - 
                            {{ $i->activity_other }}
                          @else
                            {{ $i->activity_code }} -
                            {{ ($i->activity_code == 1) ? "Calibration" : null }}
                            {{ ($i->activity_code == 2) ? "Maintenance" : null }}
                            {{ ($i->activity_code == 3) ? "Repair" : null }}
                            {{ ($i->activity_code == 4) ? "Cleaning" : null }}
                            {{ ($i->activity_code == 5) ? "Inspection" : null }}
                          @endif
                        </td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->description}}</td>
                    </tr>
                    @endforeach
		</tbody>
	</table>
	</div>
@endforeach