@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> Instructions: This Form is intended to assist you in setting your policy, to itemize the policy components and to be used as a training tool and possible handout to employees. All items need to be addressed during the training session for employees. Write N/A beside those not applicable to your operation.</p>
	<br>
	@if($startDate && $endDate)
                {? $form_c = \App\Models\FormC::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_c = $org->forms_C ?}
            @endif

            @foreach($form_c as $c)
            <table>
              <tr>
                <td style="width: 500px;"><b>Completed by:</b> {{ $c->author->first }} {{ $c->author->last }}</td>
                <td style="width: 50%;"><b>Date:</b> {{ $c->created_at }}</td>
              </tr>
            </table>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-bottom: none !important;">
                <tr>
                    <td style="width: 50%; padding: 0; border: 1px solid rgba(0, 0, 0, 0.5);">
                        <div style="padding: 0 10px;">
                            <h4 style="text-align: center; margin: 5px;">Employee Illness, Disease and Injury</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->person_transmit == "yes") ✔ @elseif($c->person_transmit == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Persons able to transmit or suffering from a contagious disease and/or illness transferable to food (e.g., Hepatitis A, Salmonella, E. coli O157:H7) and those with a temporary illness (e.g., bad cold, diarrhea and vomiting) are advised to see a doctor
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->employees_trained == "yes") ✔ @elseif($c->employees_trained == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees are trained on the role and responsibility they play in preventing the contamination of product
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->wounds_treated == "yes") ✔ @elseif($c->wounds_treated == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Open wounds are treated and covered with a waterproof covering (e.g., rubber gloves)
                                    </td>
                                </tr>
                            </table>
                            <hr>
                            <h4 style="text-align: center; margin: 5px;">Employee Biosecurity</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->employees_aware == "yes") ✔ @elseif($c->employees_aware == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees are aware of their surroundings and the people they come in contact with, in and around the production site
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->person_responsible == "yes") ✔ @elseif($c->person_responsible == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees inform person responsible (name of person responsible: <u>{{ $c->person_responsible_name }}</u> of unknown visitors
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->trained_precautions == "yes") ✔ @elseif($c->trained_precautions == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees are trained in precautions they need to take when moving between production areas (e.g., from livestock areas/field to storage/packinghouse)
                                    </td>
                                </tr>
                            </table>
                            <hr>
                            <h4 style="text-align: center; margin: 5px;">Employee Glove and Apron Use</h4>
                            <table style="width: 100%;">
                                <tr>
                                    <td style="width: 50%; text-align: center;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->gloves_used == "yes") ✔ @elseif($c->gloves_used == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span> Gloves are used
                                    </td>
                                    <td style="width: 50%; text-align: center;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->aprons_used == "yes") ✔ @elseif($c->aprons_used == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span> Aprons are used
                                    </td>
                                </tr>
                            </table>
                            <p style="font-size: 12px; margin: 5px;">
                              If gloves and aprons are not used, proceed to the next sub-section
                            </p>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->gloves_rubber == "yes") ✔ @elseif($c->gloves_rubber == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Gloves are made of rubber, nitrile, polyethylene, polyvinyl chloride, polyurethane or cloth (canvas/leather gloves may be used for potatoes and bulb and root vegetables ONLY)
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->hands_washed == "yes") ✔ @elseif($c->hands_washed == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                    Hands are washed and dried, before gloves are put on and after they are removed
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->aprons_rubber == "yes") ✔ @elseif($c->aprons_rubber == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Aprons are made of rubber
                                    </td>
                                </tr>
                              </table>
                            </div>
                          </td>
                          <td style="width: 50%; margin: 0; vertical-align: top;">
                            <div style="padding: 0 10px;">
                                <h4 style="text-align: center; margin: 5px;">Employee Hand Washing</h4>
                                <table>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->hands_washed_dried == "yes") ✔ @elseif($c->hands_washed_dried == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Hands are washed and dried:
                                          <ul style="margin: 0;">
                                            <li>Before beginning work each day</li>
                                            <li>Before entering the production site</li>
                                            <li>Before putting on gloves (if used)</li>
                                            <li>After every visit to the washroom</li>
                                            <li>After a break or meal</li>
                                            <li>After smoking</li>
                                            <li>After hand-to-face contact (e.g., coughing, sneezing, blowing nose)</li>
                                            <li>After applying sunscreen and insect repellent</li>
                                            <li>After handling any materials other than the product (e.g., fuelling equipment, spraying)</li>
                                          </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->no_water == "yes") ✔ @elseif($c->no_water == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          If no water is available, hand wipes and hand sanitizer are used
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->wipe_hand_sanitizer == "yes") ✔ @elseif($c->wipe_hand_sanitizer == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Hand wipe and hand sanitizer use:
                                          <ul style="margin: 0;">
                                            <li>Use hand wipes to facilitate soil/organic matter/ juice etc.  removal  AND</li>
                                            <li>Use one squirt of waterless, antibacterial, alcohol-based product</li>
                                          </ul>
                                        </td>
                                    </tr>
																		<tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->gloves_substitute == "yes") ✔ @elseif($c->gloves_substitute == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Gloves are not worn as a substitute for hand washing
                                        </td>
                                    </tr>
                                </table>
                                <hr>
                                <h4 style="text-align: center; margin: 5px;">Production Practices</h4>
                                <table>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->trained_harvest == "yes") ✔ @elseif($c->trained_harvest == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Employees are trained to harvest into clean containers
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->trained_visually == "yes") ✔ @elseif($c->trained_visually == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Employees are trained to visually inspect product during harvest to look for evidence of unusual animal or bird activity (i.e., excrement) and discards product if it has been contaminated
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->trained_touched == "yes") ✔ @elseif($c->trained_touched == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Employees are trained not to harvest product that has touched the ground (FOR TREE AND VINE FRUIT ONLY)
                                        </td>
                                    </tr>
                                </table>
                              </div>
                          </td>
                      </tr>
                    </table>
                    <div style="page-break-after: always; margin: 0 !important;"></div>
                    <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-top: none !important;">
                      <tr>
                          <td style="width: 50%; border: 1px solid rgba(0, 0, 0, 0.4);">
                              <div style="padding: 0 10px;">
                              <table style="margin: 0 !important;">
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->employee_aprons == "yes") ✔ @elseif($c->employee_aprons == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees wear aprons when they hold product against their upper body (e.g., to trim product)
                                    </td>
                                </tr>

                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->employee_aprons == "yes") ✔ @elseif($c->employee_aprons == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Gloves and aprons are replaced when ripped or worn out
                                    </td>
                                </tr>

                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->reusable_aprons == "yes") ✔ @elseif($c->reusable_aprons == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Reusable aprons are washed daily
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->reusable_aprons == "yes") ✔ @elseif($c->reusable_aprons == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Gloves are removed when leaving the work area and replaced upon return.
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->reusable_gloves_washed == "yes") ✔ @elseif($c->reusable_gloves_washed == "no") &#10005; @else <span style="font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      If reusable, gloves are washed (using proper hand washing technique) after being put back on and when changing tasks that could potentially contaminate the product. If made of cloth, gloves are laundered daily [excludes canvas/leather gloves used to handle potatoes and bulb and root vegetables (e.g., carrots, onions, garlic, rutabagas)]
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </td>
                    <td style="width: 50%; vertical-align: top;">
                        <table>
                          <tr style="vertical-align: top;">
                              <td valign="top" style="width: 20px;">
                                  <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->trained_fallen == "yes") ✔ @elseif($c->trained_fallen == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                              </td>
                              <td style="text-align: left;">
                                Employees are trained not to harvest product that has fallen on the ground (FOR SMALL FRUIT ONLY)
                              </td>
                          </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-top: none !important;">
                <tr>
                    <td>
                        <h4 style="text-align: center; margin: 5px;">Other</h4>
                        <table>
                          <tr>
                          <td style="width: 50%; vertical-align: top;">
                              <div style="padding: 0 10px;">
                              <table>
                                <tr style="vertical-align: top;">
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->major_minor == "yes") ✔ @elseif($c->major_minor == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees know the difference between and how to handle major and minor food safety deviations
                                    </td>
                                </tr>
                              </table>
                              </div>
                    </td>
                </tr>
                <tr>
                <td style="width: 50%; vertical-align: top;">
                    <div style="padding: 0 10px;">
                    <table>
                      <tr style="vertical-align: top;">
                          <td valign="top" style="width: 20px;">
                              <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($c->employee_adhere == "yes") ✔ @elseif($c->employee_adhere == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                          </td>
                          <td style="text-align: left;">
                            Employees adhere to the following:
                            <ul style="margin: 0;">
                              <li>Always use toilet facilities</li>
                              <li>Always dispose of toilet paper in toilet (i.e., not in garbage can)</li>
                              <li>Never spit</li>
                              <li>Eat food, drinks, gum, candy or use tobacco products (including chewing tobacco and snuff) only in areas designated for this purpose (e.g., outside, in lunchroom)</li>
                              <li>Put personal effects in designated areas (e.g., lunches, clothing, shoes, smoking materials)</li>
                              <li>Dispose of waste in designated containers</li>
                            </ul>
                          </td>
                      </tr>
                    </table>
                    </div>
          </td>
      </tr>
            </table>
     @endforeach
	</div>
@endforeach
