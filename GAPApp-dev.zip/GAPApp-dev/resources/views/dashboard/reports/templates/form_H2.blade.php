@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> Includes all applications from pre-planting through to, and including, harvest. One Form must be completed for EACH PRODUCTION SITE.</p>
	<p><i>Note: Mulch and Row Cover Applications DO NOT need to be recorded for Bulb and Root Vegetables.</i></p>
	<br>
	@if($startDate && $endDate)
                {? $form_h2 = \App\Models\FormH2::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_h2 = $org->forms_H2 ?}
            @endif

              @foreach($form_h2 as $h2)
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
		<tbody>
        	<tr>
            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Operation Name:</b>
            		<p style="text-align: center; margin: 5px;">{{ $h2->operation_name }}</p>
            	</td>
            	<td width="25%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Previous Year Crop(s):</b>
            		<p style="text-align: center; margin: 5px;">{{ $h2->previous_year_crops }}</p>
            	</td>
            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>FOR POTATOES ONLY:</b>
            		<p style="text-align: center; margin: 5px;"><b>Seed Certification #:</b> {{ $h2->seed_certificate }}</p>
            	</td>
            	<td width="40%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					<b>Current Crop:</b>
					<p style="text-align: center; margin: 5px;">{{ $h2->current_crop }}</p>
				</td>
        	</tr>
        	<tr>
            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Production Site Information (e.g., Field/Block # or Name/ID/Legal Description):</b>
            		<p style="text-align: center; margin: 5px;">{{ $h2->production->name }}</p>
            	</td>
            	<td width="25%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Production Site Area(e.g., # of  acres/hectares):</b>
            		<p style="text-align: center; margin: 5px;">{{ $h2->production_site_area }}</p>
            	</td>
            	<td width="30%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
            		<b>Date Planted:</b>
            		<p style="text-align: center; margin: 5px;">{{ substr($h2->date_planted, 0, -14) }}</p>
            	</td>
            	<td width="40%" style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
					<b>Variety</b>
					<p style="text-align: center; margin: 5px;">{{ $h2->variety }}</p>
				</td>
        	</tr>
		</tbody>
	</table>
	<br>

	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; border-bottom: 0; width: 100%; text-align: left;">
			<tr>
					<td style="padding: 5px 20px;">
							COMMERCIAL FERTILIZER APPLICATION
					</td>
			</tr>
	</table>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100%; text-align: left;">
			<thead>
					<tr>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Date
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Blend
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Rate
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Fertilizer Lot # (if applicable)
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Applicator's Name
							</th>
					</tr>
			</thead>
			<tbody>
					<tr>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ substr($h2->created_at, 0, -9) }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h2->blend }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h2->commercial_rate }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h2->fertilizer_lot_num }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								{{ $h2->author->first }} {{ $h2->author->last }}
							</td>
					</tr>
			</tbody>
	</table>
	<br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; border-bottom: 0; width: 100%; text-align: left;">
			<tr>
					<td style="padding: 5px 20px;">
							MANURE*/COMPOST/COMPOST TEA/OTHER BY-PRODUCTS#/PULP SLUDGE/SOIL AMENDMENT/MULCH AND ROW COVER APPLICATIONS (except for plastic)
					</td>
			</tr>
	</table>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100%; text-align: left;">
			<thead>
					<tr>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px; width: 14%;">
								Date
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								What is Applied
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Type **
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Supplier's Name
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Rate
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Earliest Allowable Harvest Date* (according to appropriate time delay)
							</th>
							<th style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
								Applicator's Name
							</th>
					</tr>
			</thead>
			<tbody>
					<tr>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ substr($h2->created_at, 0, -9) }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ $h2->what_is_applied }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ $h2->type }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ $h2->supplier_name }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ $h2->manure_rate }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ substr($h2->earliest_harvest_date, 0, -14) }}
							</td>
							<td style="color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; padding: 5px 20px;">
									{{ $h2->author->first }} {{ $h2->author->last }}
							</td>
					</tr>
			</tbody>
	</table>
	<p>
		<b>* Manure (cattle, hog, poultry, horse, etc.)<br>
		* Other by-product (seafood waste, vegetable culls, etc.)</b>
	</p>
	@endforeach
	</div>
@endforeach
