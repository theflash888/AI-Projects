@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> This Form is intended to assist you in setting out your policy, to itemize the policy components and to be used as a training tool and possible handout to employees. All items need to be addressed during the training session for employees. Write N/A beside those not applicable to your operation. (This form is also inteded for employees who are handling market ready packaging materials.)</p>
	@if($startDate && $endDate)
                {? $form_d = \App\Models\FormD::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_d = $org->forms_D ?}
            @endif

            @foreach($form_d as $d)
            <table>
              <tr>
                <td style="width: 500px;"><b>Completed by:</b> {{ $d->author->first }} {{ $d->author->last }}</td>
                <td style="width: 50%;"><b>Date:</b> {{ $d->created_at }}</td>
              </tr>
            </table>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-bottom: none !important;">
                <tr>
                    <td style="width: 50%; padding: 0; border: 1px solid rgba(0, 0, 0, 0.5); vertical-align: top; border-bottom: 0;">
                        <div style="padding: 0 10px;">
                            <h4 style="text-align: center; margin: 5px;">Employee Illness, Disease and Injury</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->person_transmit == "yes") ✔ @elseif($d->person_transmit == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Persons able to transmit or suffering from a contagious disease and/or illness transferable to food (e.g., Hepatitis A, Salmonella, E. coli O157:H7) and those with a temporary illness (e.g., bad cold, diarrhea and vomiting) are advised to see a doctor                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->employees_trained == "yes") ✔ @elseif($d->employees_trained == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees are trained on the role and responsibility they play in preventing the contamination of product
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->wounds_treated == "yes") ✔ @elseif($d->wounds_treated == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Open wounds are treated and covered with a waterproof covering (e.g., rubber gloves)
                                    </td>
                                </tr>
                            </table>
                            <hr>
                            <h4 style="text-align: center; margin: 5px;">Employee Cleanliness, Footwear and Hair</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->personal_cleanliness == "yes") ✔ @elseif($d->personal_cleanliness == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      A degree of personal cleanliness is maintained which includes starting each day wearing clean clothing and (specify other): {{ $d->personal_cleanliness_other }}
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->clean_footwear == "yes") ✔ @elseif($d->clean_footwear == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Clean footwear is always worn (no dirt or other foreign matter)
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->long_hair_touching == "yes") ✔ @elseif($d->long_hair_touching == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Long hair touching the shoulders is restrained  (e.g., hat, hairnet, tied)
                                    </td>
                                </tr>
                            </table>
                            <hr>
                            <h4 style="text-align: center; margin: 5px;">Production Practices</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->employee_authorized == "yes") ✔ @elseif($d->employee_authorized == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Employees adhere to the following:
                                      <ul style="margin: 0;">
                                        <li>Only authorized employees handle market product</li>
                                        <li>Only authorized employees may enter controlled- access areas</li>
                                      </ul>
                                    </td>
                                </tr>
                            </table>
                            <hr>
                            <h4 style="text-align: center; margin: 5px;">Employee Jewellery and Other Personal Effects</h4>
                            <table>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->jewellery_worn == "yes") ✔ @elseif($d->jewellery_worn == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Bracelets, necklaces or other jewellery (except for rings) are not worn
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->ring_gloves == "yes") ✔ @elseif($d->ring_gloves == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      Rings are covered with gloves
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" style="width: 20px;">
                                        <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->false_fingernails == "yes") ✔ @elseif($d->false_fingernails == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                    </td>
                                    <td style="text-align: left;">
                                      False fingernails, false eyelashes or other such effects are not worn
                                    </td>
                                </tr>
                            </table>
                            </div>
                          </td>
                          <td style="width: 50%; margin: 0; vertical-align: top;">
                            <div style="padding: 0 10px;">
                                <h4 style="text-align: center; margin: 5px;">Employee Hand Washing</h4>
                                <table>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->hands_washed_dried == "yes") ✔ @elseif($d->hands_washed_dried == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Hands are washed and dried:
                                          <ul style="margin: 0;">
                                            <li>Before beginning work each day</li>
                                            <li>Before putting on gloves (if used)</li>
                                            <li>After every visit to the washroom</li>
                                            <li>After a break or meal</li>
                                            <li>After smoking</li>
                                            <li>After hand-to-face contact (e.g., coughing, sneezing, blowing nose)</li>
                                            <li>After applying insect repellent</li>
                                            <li>After handling any materials other than the product (e.g., fuelling equipment, spraying)</li>
                                          </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->hands_reusable_gloves == "yes") ✔ @elseif($d->hands_reusable_gloves == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Hands and reusable gloves are washed using proper hand washing techniques:
                                          <ul style="margin: 0;">
                                            <li>Wet hands, lather soap for approximately 20 seconds</li>
                                            <li>Scrub well (especially fingernails and knuckles)  Use fingernail brushes if needed/required</li>
                                            <li>Rinse</li>
                                            <li>Dry hands and wrists with paper towel</li>
                                          </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->no_water == "yes") ✔ @elseif($d->no_water == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          If no water is available, hand wipes and hand sanitizer are used
                                        </td>
                                    </tr>
																		<tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->wipe_hand_sanitizer == "yes") ✔ @elseif($d->wipe_hand_sanitizer == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Hand wipe and sanitizer use:
                                          <ul style="margin: 0;">
                                            <li>Use hand wipes to facilitate soil/organic matter/juice etc. removal AND</li>
                                            <li>Use one squirt of waterless, antibacterial, alcohol-based product</li>
                                          </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->gloves_substitute == "yes") ✔ @elseif($d->gloves_substitute == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Gloves are not worn as a substitute for hand washing
                                        </td>
                                    </tr>
                                </table>
                                <hr>
                                <h4 style="text-align: center; margin: 5px;">Employee Biosecurity</h4>
                                <table>
                                    <tr>
                                        <td valign="top" style="width: 20px;">
                                            <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->employees_aware == "yes") ✔ @elseif($d->employees_aware == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                        </td>
                                        <td style="text-align: left;">
                                          Employees are aware of surroundings and the people they come in contact with, in and around the packinghouse/product storage
                                        </td>
                                    </tr>
                                </table>
                              </div>
                          </td>
                      </tr>
                    </table>
                    <div style="page-break-after: always; margin: 0 !important;"></div>
                    <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important; border-top: none !important;">
                        <tr>
                            <td style="width: 50%; padding: 0; border: 1px solid rgba(0, 0, 0, 0.5); vertical-align: top; border-top: 0;">
                                <div style="padding: 0 10px;">
                                    <table>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->items_removed_pocket == "yes") ✔ @elseif($d->items_removed_pocket == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Items are removed from shirt pockets (e.g., pens, etc.)                                 </td>
                                        </tr>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->loose_buttons_fixed == "yes") ✔ @elseif($d->loose_buttons_fixed == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Loose buttons on shirts/jackets are fixed
                                            </td>
                                        </tr>
                                    </table>
                                    <hr>
                                    <h4 style="text-align: center; margin: 5px;">Employee Glove and Apron Use</h4>
                                    <table style="width: 100%;">
                                        <tr>
                                            <td style="width: 50%; text-align: center;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->gloves_used == "yes") ✔ @elseif($d->gloves_used == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span> Gloves are used
                                            </td>
                                            <td style="width: 50%; text-align: center;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->aprons_used == "yes") ✔ @elseif($d->aprons_used == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span> Aprons are used
                                            </td>
                                        </tr>
                                    </table>
                                    <p style="font-size: 12px; margin: 5px;">
                                      If gloves and aprons are not used, proceed to the next sub-section
                                    </p>
                                    <table>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->gloves_rubber == "yes") ✔ @elseif($d->gloves_rubber == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Gloves are made of rubber, nitrile, polyethylene, polyvinyl chloride or polyurethane
                                            </td>
                                        </tr>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->hands_washed == "yes") ✔ @elseif($d->hands_washed == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Hands are washed and dried, before gloves are put on and after they are removed
                                            </td>
                                        </tr>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->aprons_rubber == "yes") ✔ @elseif($d->aprons_rubber == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Aprons are made of rubber
                                            </td>
                                        </tr>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->employee_aprons == "yes") ✔ @elseif($d->employee_aprons == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Employees wear aprons when they hold product against their upper body (e.g., to trim product)
                                            </td>
                                        </tr>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->gloves_aprons == "yes") ✔ @elseif($d->gloves_aprons == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Gloves and aprons are replaced when ripped or worn out
                                            </td>
                                        </tr>
                                        <tr>
                                            <td valign="top" style="width: 20px;">
                                                <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->gloves_removed == "yes") ✔ @elseif($d->gloves_removed == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                            </td>
                                            <td style="text-align: left;">
                                              Gloves are removed when leaving the work area and replaced upon return  or, if reusable, gloves are washed (using proper hand washing technique) after being put back on and when changing tasks that could potentially contaminate the product.
                                            </td>
                                        </tr>
                                    </table>
                                    </div>
                                  </td>
                                  <td style="width: 50%; margin: 0; vertical-align: top;">
                                    <div style="padding: 0 10px;">
                                        <table>
                                            <tr>
                                                <td valign="top" style="width: 20px;">
                                                    <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->person_responsible == "yes") ✔ @elseif($d->person_responsible == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                                </td>
                                                <td style="text-align: left;">
                                                  Employees inform person responsible (name of person responsible: {{ $d->person_responsible_name }} of unknown visitors
                                                </td>
                                            </tr>
                                            <tr>
                                                <td valign="top" style="width: 20px;">
                                                    <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->trained_precautions == "yes") ✔ @elseif($d->trained_precautions == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                                </td>
                                                <td style="text-align: left;">
                                                  Employees are trained in precautions they need to take when moving between production areas (e.g., from livestock areas/field to storage/packinghouse)
                                                </td>
                                            </tr>
                                        </table>
                                        <hr>
                                        <h4 style="text-align: center; margin: 5px;">Other</h4>
                                        <table>
                                            <tr>
                                                <td valign="top" style="width: 20px;">
                                                    <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->major_minor == "yes") ✔ @elseif($d->major_minor == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                                </td>
                                                <td style="text-align: left;">
                                                  Employees know the difference between and how to handle major and minor food safety deviations
                                                </td>
                                            </tr>
                                            <tr>
                                                <td valign="top" style="width: 20px;">
                                                    <span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($d->employee_adhere == "yes") ✔ @elseif($d->employee_adhere == "no") &#10005; @else <span style="vertical-algin: middle; margin-top: -8px; font-size: 12px;">N/A</span> @endif</span>
                                                </td>
                                                <td style="text-align: left;">
                                                  Employees adhere to the following:
                                                  <ul style="margin: 0;">
                                                    <li>Always use toilet facilities</li>
                                                    <li>Always dispose of toilet paper in toilet (i.e., not in garbage can)</li>
                                                    <li>Never spit</li>
                                                    <li>Eat food, drinks, gum, candy or use tobacco products (including chewing tobacco and snuff) only in areas designated for this purpose (e.g., outside, in lunchroom)</li>
                                                    <li>Put personal effects in designated areas (e.g.,  lunches, clothing, shoes, smoking materials)</li>
                                                    <li>Dispose of waste in designated containers</li>
                                                  </ul>
                                                </td>
                                            </tr>
                                        </table>
                                      </div>
                                  </td>
                              </tr>
                            </table>

     @endforeach
	</div>
@endforeach
