@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p>Instructions: This Form must be completed prior to using storages for the first time in a season (use one Form per storage for harvested and market product). If an item is not applicable, indicate N/A.</p>
	<br>
	@if($startDate && $endDate)
                {? $form_b = \App\Models\FormB::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_b = $org->forms_B ?}
            @endif

            @foreach($form_b as $b)
            <table>
            	<tr>
            		<td style="width: 500px;"><b>Completed by:</b> {{ $b->author->first }} {{ $b->author->last }}</td>
            		<td style="width: 50%;"><b>Date:</b> {{ $b->created_at }}</td>
            	</tr>
            </table>
            <p><b>Storage ID # / Name:</b> {{ $b->production->name }}</p>
            <br>
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;" class="MainTable">
            	<thead>
            		<tr>
            			<th width="40" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Requirement</th>
            			<th width="5" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Yes</th>
            			<th width="5" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">No</th>
            			<th width="50" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Action Taken if Answered "No"</th>
            		</tr>
            	</thead>
            	<tbody>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Storage is secured (e.g., with a lock) when unsupervised?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->storage_secured == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->storage_secured == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->storage_secured == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->storage_secured == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->storage_secured_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Lights in the storage area are shatterproof or covered?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->lights_shatterproof == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->lights_shatterproof == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->lights_shatterproof == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->lights_shatterproof == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->lights_shatterproof_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Product in storage is kept in proper conditions (e.g., on pallets)?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->proper_condition == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->proper_condition == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->proper_condition == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->proper_condition == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->proper_condition_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Product is stored away from leaky areas (e.g., from roofs, pipes, condensation)?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->leaky_area == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->leaky_area == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->leaky_area == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->leaky_area == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->leaky_area_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">When the storage is in use, production site equipment  and fertilizers are stored and repaired elsewhere? Agricultural chemicals are never stored in product storages?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->production_equipment == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->production_equipment == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->production_equipment == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->production_equipment == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->production_equipment_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Treated seed is stored according to the label directions (i.e., stored away from product)?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->treated_seed == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->treated_seed == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->treated_seed == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->treated_seed == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->treated_seed_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Oil/gas furnace is exhausting outside the storage?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->furnace_exhausting == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->furnace_exhausting == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->furnace_exhausting == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->furnace_exhausting == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->furnace_exhausting_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">When the storage is in use, oil/fuel storage tanks are stored elsewhere or contained to prevent contamination of product?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->storage_in_use == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->storage_in_use == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->storage_in_use == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->storage_in_use == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->storage_in_use_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Floor of the storage is clean and free from contaminants (e.g., oil, wood, plastic, glass, metal, garbage, chemicals)?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->floor_clean == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->floor_clean == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->floor_clean == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->floor_clean == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->floor_clean_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Walls/ceilings of storage are clean and in good condition (e.g., free from contamination from oil, wood, plastic, glass, metal, garbage, chemicals)?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->ceiling_storage == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->ceiling_storage == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->ceiling_storage == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->ceiling_storage == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->ceiling_storage_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">The storage is a no-smoking zone?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->no_smoking == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->no_smoking == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->no_smoking == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->no_smoking == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->no_smoking_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Storage is free from animals (wild or domestic) or evidence of animals (droppings) and other pests (birds, insects, rodents)?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->free_animals == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->free_animals == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->free_animals == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->free_animals == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->free_animals_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">FOR POTATOES ONLY: <br> Potatoes in storage are kept in the dark?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->potatoes_dark == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->potatoes_dark == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->potatoes_dark == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->potatoes_dark == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->potatoes_dark_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">FOR POTATOES ONLY: <br> Potatoes are free from direct contact with pressure treated wood?</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->potatoes_treated == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->potatoes_treated == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->potatoes_treated == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->potatoes_treated == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->potatoes_treated_action }}</td>
            		</tr>
            		<tr>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Other (specify):</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->other == "yes") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->other == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">@if($b->other == "no") <span style="font-family: DejaVu Sans, sans-serif; vertical-align: middle;">✔</span> @elseif($b->other == "na") N/A @endif</td>
            			<td  style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">{{ $b->other_action }}</td>
            		</tr>
            	</tbody>
            </table>
           	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left; width: 100%; border-top: 0; margin: 0 !important;">
           		<tbody>
            		<tr>
            			<td width="50" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">How and when was the storage cleaned? (describe):</td>
            			<td width="50" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $b->storage_cleaning_desc }}</td>
            		</tr>
            	</tbody>
            </table>
     @endforeach
	</div>
@endforeach
