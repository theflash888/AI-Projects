@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Instructions: During fluming, washing, or drenching (e.g., dump tank, pit), if water potability is not maintained for tomatoes/apples immersed in water, complete the following chart to record your water and product temperatures. <b>Monitor each load of product to ensure that the product is at least 5.5˚C or 10˚F colder than the water (i.e., water is at least 5.5˚C or 10˚F warmer than the product).</b></p>
	<br>
	@if($startDate && $endDate)
		{? $form_n2 = \App\Models\FormN2::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
	@else
		{? $form_n2 = $org->forms_N2 ?}
	@endif
  @foreach($form_n2 as $n2)
  <table style="width: 100%;">
      <tr>
          <td style="width: 50%;">
              <p style="margin: 0;">
                <b>Water Source:</b>
                @if($n2->water_source == 1)
                    Municipal Water
                @elseif($n2->water_source == 2)
                    Well Water and Tertiary Water
                @elseif($n2->water_source == 3)
                    Pond/Reservoir/Dugout Fed by Groundwater (spring/wells) or Rainwater
                @elseif($n2->water_source == 4)
                    Pond/Dugout Fed by Stream, Ditch or Run-Off
                @elseif($n2->water_source == 5)
                    River, Stream, Creek, Canal, Flooding
                @endif
              </p>
          </td>
          <td style="width: 50%;">
              <b>Method (e.g., injection):</b>
							@if($n2->method == 1)
							Pit
							@elseif($n2->method == 2)
							Spray
							@elseif($n2->method == 3)
							Hose
							@elseif($n2->method == 4)
							Tap
							@elseif($n2->method == 5)
							Dump Tank
							@elseif($n2->method == 6)
							Pressure Wash
							@elseif($n2->method == 7)
							Other: {{ $n2->method_other }}
							@endif
          </td>
      </tr>
      <tr>
          <td style="width: 50%;">
              <p style="margin: 0;">
                <b>Product:</b> {{ $n2->product }}
              </p>
          </td>
          <td style="width: 50%;">
              <b>Month: </b>
              @if($n2->month == 1)
                January
              @elseif($n2->month == 2)
                February
              @elseif($n2->month == 3)
                March
              @elseif($n2->month == 4)
                April
              @elseif($n2->month == 5)
                May
              @elseif($n2->month == 6)
                June
              @elseif($n2->month == 7)
                July
              @elseif($n2->month == 8)
                August
              @elseif($n2->month == 9)
                September
              @elseif($n2->month == 10)
                October
              @elseif($n2->month == 11)
                November
              @elseif($n2->month == 12)
                December
              @endif
          </td>
      </tr>
  </table>
  <br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100%;">
		<thead>
			<tr>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date/Time</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Temperature of Water (˚C/˚F)</th>
				<th width="10%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Temperature of Product (˚C/˚F)</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Difference between the 2 temperatures</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Corrective Action Taken (e.g., cool product, hold, dispose of, etc.)</th>
        <th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Person Responsible</th>
			</tr>
		</thead>
		<tbody>
        <tr>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n2->created_at }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n2->water_temp }} {{ ($n2->temp_type == 'C') ? "˚C" : "˚F" }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n2->product_temp }} {{ ($n2->temp_type == 'C') ? "˚C" : "˚F" }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n2->difference }} {{ ($n2->temp_type == 'C') ? "˚C" : "˚F" }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n2->action_taken }}</td>
            <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $n2->author->first }} {{ $n2->author->last }}</td>
        </tr>
		</tbody>
	</table>
  @endforeach
	</div>
@endforeach
