@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div> 
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Record cleaning and maintenance of both exterior and interior washrooms and hand washing facilities. Complete at least weekly (while in use) and daily during peak season for each facility. Write N/A in column if not applicable to facility. Cleaning includes toilet, sink, floor, paper towel dispenser, all handles (e.g., toilet handle, door knob, tap), etc. </p>
	<br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
		<thead>
			<tr>
				<th width="8%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Assessment of Facilities (e.g., do toilets need emptying, are extra supplies needed, etc.) Check (P) if assessment OK or after corrective action(s) taken (e.g., pumped toilets, stocked extra toilet paper, etc.)</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Disposable Paper Towels</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Soap</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Water Source Operating (Hot and/or Cold Water)</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Toilet Paper</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Hand Sanitizer/ Wipes</th>
				<th width="5%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Garbage Emptied</th>
				<th width="10%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Employee Responsible for Cleaning (sign to confirm all cleaning completed) OR Person Confirming Cleaning Completed by a Company </th>
			</tr>
		</thead>
		<tbody>
			@if($startDate && $endDate)
				{? $form_j = \App\Models\FormJ::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
			@else
				{? $form_j = $org->forms_J ?}
			@endif
			
			@foreach($form_j as $j)
                    <tr>
                    	<td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$j->created_at}}</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->assessment == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->paper_towel == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->soap == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->water_source == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->toilet_paper == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->hand_sanitizer == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($j->garbage_emptied == '1') Yes @else No @endif</td>
                        <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$j->author->first}} {{ $j->author->last }}</td>
                    </tr>
                    @endforeach
		</tbody>
	</table>
	</div>
@endforeach