@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> This form is intended to assess whether potential food defense/security risk factors exist.  Consider if there could be a risk in the following categories and implement appropriate security measures. If additional risks were identified, describe them below. Detailed information can be found in Appendix T: Food Defense: Assessment of Possible Risks and List of Security Measures if further assistance is required. </p>
	<br>
	@if($startDate && $endDate)
                {? $form_t = \App\Models\FormT::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_t = $org->forms_T ?}
            @endif

            @foreach($form_t as $t)
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;">
                  <tr>
                        <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">Inside Security Risk Assessment</th>
                  </tr>
                  <tr>
                        <td style="text-align: left; padding: 0 10px;">
                              <p><i>To protect product from intentional contamination, assess possible inside risks (e.g., packing/repacking area/facility security, agricultural chemical storage security, product security, information security, etc.).</i></p>
                              <p><b>The following potential risk factors have been assessed and appropriate security measures have been implemented:</b></p>
                              <table style="width: 100%;">
                                    <tr>
                                          <td style="width: 5%;"><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->general_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td style="width: 95%;">General security (e.g., signs, observations, areas etc.)</td>
                                    </tr>
                                    <tr>
                                          <td><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->storage_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td>Storage/Building Security</td>
                                    </tr>
                                    <tr>
                                          <td><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->water_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td>Water/Ice Security</td>
                                    </tr>
                                    <tr>
                                          <td><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->agriculture_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td>Agricultural Chemical/Cleaning and Maintenance Materials Control Security</td>
                                    </tr>
                                    <tr>
                                          <td><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->information_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td>Information Security</td>
                                    </tr>
                              </table>
                              <br>
                              <p><u>Personnel Security Risks</u></p>
                              <p><i>To prevent personnel security risks, ensure that only authorized personnel (e.g., employees, visitors, etc.) are within the operation and employees are trained on food defense/security measures </i></p>
                              <br>
                              <p><b>The following potential risk factors have been assessed and appropriate security measures have been implemented:</b></p>
                              <table style="width: 100%;">
                                    <tr>
                                          <td style="width: 5%;"><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->personnel_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td style="width: 95%;">Personnel Security (e.g., check references, check IDs, security training, etc.)</td>
                                    </tr>
                              </table>
                        </td>
                  </tr>
                  <tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;" style="text-align: left; padding: 0 10px;">
                              <b>Outside Security Risk Assessment</b>
                        </td>
                  </tr>
                  <tr>
                        <td style="text-align: left; padding: 0 10px;">
                              <p><i>To prevent unauthorized access by people, entry of unapproved inputs, or intentional contamination of product assess possible outside risks (e.g., production site/building security, mail handling security, etc.)</i></p>
                              <br>
                              <p><b>The following potential risk factors have been assessed and appropriate security measures have been implemented:</b></p>
                              <table style="width: 100%;">
                                    <tr>
                                          <td style="width: 5%;"><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->physical_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td style="width: 95%;">Physical Security (e.g., door locks, lighting etc.)</td>
                                    </tr>
                                    <tr>
                                          <td><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($t->entry_security == 1) ✔ @else  &#10005; @endif</span></td>
                                          <td>Entry of inputs/product (e.g., loading/unloading etc.)</td>
                                    </tr>
                              </table>
                        </td>
                  </tr>
                  <tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: left;">
                              <p>If other risks have been identified, list those below, along with the corrective actions taken:</p>
                              <br>
                              <p>{{ $t->actions }}</p>
                        </td>
                  </tr>
            </table>
     @endforeach
	</div>
@endforeach
