@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div> 
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> Complete for all product being transported to someone else’s premises</p>
	<br>
    <br>
    <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
                    <thead><tr>
                    </tr><tr>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" rowspan="2">Date</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" colspan="2">Vehicle<br>Inspected?</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" rowspan="2">Product Identifier<br>(Lot ID/Pack<br>ID/Row/House/<br>Zone/Pallet/Bin<br>Tag)<br>(Same as on<br>Form P or Q)</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" rowspan="2">Quantity Shipped</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" rowspan="2">Trunk/<br>Trailer<br>ID#</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" rowspan="2">Destination<br>and<br>Customer</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;" rowspan="2">Person<br>Responsible<br>(Loader)</th>
                    </tr>
                    <tr>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">✓ if OK or<br>record hazard*<br>and<br>corrective<br>action**</th>
                        <th style="padding: 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">✓ If<br>covered</th>
                    </tr>
                    </thead>
                    <tbody>
    @if($startDate && $endDate)
                {? $form_o = \App\Models\FormO::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_o = $org->forms_O ?}
            @endif
            
            @foreach($form_o as $o)
	           <tr>
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $o->created_at }}</td>
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">@if($o->hazards && $o->actions) {{ $o->hazards }} <br> {{ $o->actions }} @else OK @endif</td>
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;"></td>
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $o->product_identifier }}</td> 
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $o->quantity_shipped }}</td> 
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $o->truck_id }}</td> 
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $o->destination_and_customer }}</td>
                    <td style="padding: 10px 0; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $o->person_responsible }}</td>
               </tr>
                
            @endforeach
    </tbody></table>
	</div>
@endforeach