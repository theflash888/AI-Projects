@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<p><b>Instructions:</b> All visitors must sign in prior to entering controlled-access areas (within buildings).</p>
	<br>
	<div style="border: 1px solid rgba(0, 0, 0, 0.7); padding: 20px;">
		<h4 style="text-align: center;">VISITOR POLICY</h4>
		<p><b>All visitors must:</b></p>
		<ul style="margin: 0 20px;">
			<li>Remain in the area they are given permission to be in (e.g., contractor remains in work area only)</li>
			<li>Wash hands before entering controlled-access areas</li>
			<li>Wear appropriate protective and/or food safety-related clothing</li>
			<li>Shoes must be cleaned, changed or covered prior to entering if they are visibly dirty or soiled</li>
			<li>Sign in below to indicate they are informed of and understand the visitor policy</li>
		</ul>
	</div>
	<br>
	<table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">
		<thead>
			<tr>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date</th>
				<th width="15%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Visitor's Name</th>
				<th width="35%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Company Name, Purpose of Visit</th>
				<th width="35%" style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Location on Premises</th>
			</tr>
		</thead>
		<tbody>
			@if($startDate && $endDate)
				{? $form_l = \App\Models\FormL::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
			@else
				{? $form_l = $org->forms_L ?}
			@endif

			@foreach($form_l as $i)
                    <tr>
                        <td style="padding: 10px 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->created_at}}</td>
                        <td style="padding: 10px 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->visitor}}</td>
												<td style="padding: 10px 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{$i->company_purpose}}</td>
                        <td style="padding: 10px 10px; color: rgba(0, 0, 0, 0.6); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;"><?php $toEnd = count($i->location); ?>@foreach($i->location as $loc) {{ \App\Models\EntityName::find($loc)->first()->name }}@if (0 === --$toEnd) @else, @endif @endforeach</td>
                    </tr>
                    @endforeach
		</tbody>
	</table>
	</div>
@endforeach
