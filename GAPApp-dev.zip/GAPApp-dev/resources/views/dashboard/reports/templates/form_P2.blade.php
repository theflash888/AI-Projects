@foreach(Auth::user()->organizations as $org)
<meta http-equiv="Content-Type" content="application/pdf; charset=utf-8"/>
<style>
	.MainTable {
		width: 100%;
	}
	.MainTable tr th:first-child {
		width: 50%;
	}
	.MainTable tr th:nth-child(2),
	.MainTable tr th:nth-child(3) {
		width: 8%;
	}
	.MainTable tr th:nth-child(4) {
		width: 40%;
	}
</style>
<div class="ReportsContent">
<div class="row animated fadeIn align-right">
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3 style="margin: 0 !important; text-align: right;">{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
			</div>
		</div>
	</div>
	<div class="row animated fadeIn align-justify">
		<div class="large-12 columns DBTitle">
			<h1 style="margin: 0 !important;">{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
	</div>
	<br>
	<p><b>Instructions:</b> Complete for any harvested product that is: <br>
  <ul style="margin-left: 40px;">
    <li>Put into harvested product packaging materials</li>
    <li>Harvested in bulk</li>
    <li>Put into storage</li>
  </ul>
</p>
	<br>
	@if($startDate && $endDate)
                {? $form_p2 = \App\Models\FormP2::whereBetween('created_at', [$startDate, $endDate])->orderBy('created_at', 'DESC')->get() ?}
            @else
                {? $form_p2 = $org->forms_P2 ?}
            @endif
            
            <table style="border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center; width: 100% !important;">
                  <thead>
                        <tr>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Product and Variety</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">*PHI/EAHD/DAA met  (Forms H1 and H2 verified) and Initial</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">** Production site was assessed </th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Harvest Date</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Field/Block #/Pallet/Bin Tag (Same as Forms H1 and H2)</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Packaging Materials Used</th>
                              <th style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">Date Product Put into Storage</th>
                        </tr>
                  </thead>
                  <tbody>
                        
                  
            @foreach($form_p2 as $p2)
                  <tr>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $p2->product_variety }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;"><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($p2->phi_eahd_daa == 1) ✔ @else  &#10005; @endif</span></td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;"><span style="vertical-align: top; font-family: DejaVu Sans, sans-serif; vertical-align: middle;">@if($p2->production_assessed == 1) ✔ @else  &#10005; @endif</span></td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ substr($p2->harvest_date, 0, -14) }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $p2->field_block }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $p2->packaging_material }}</td>
                        <td style="padding: 10px 5px; color: rgba(0, 0, 0, 0.8); border-collapse: collapse; border: 1px solid rgba(0, 0, 0, 0.5); text-align: center;">{{ $p2->packaging_material }}</td>
                  </tr>
     @endforeach
     </tbody>
            </table>
	</div>
@endforeach
