@extends('dashboard.home')

@section('dashboard-content')
	@foreach(Auth::user()->organizations as $org)
	<div class="row">
		<div class="large-12 columns AuditForm">
      <md-toolbar md-scroll-shrink style="background: rgba(50, 115, 186, 1); border-top-left-radius: 5px; border-top-right-radius: 5px;">
        <div style="font-size: 19px;" class="md-toolbar-tools">CanadaGAP Audit for the Production, Packing and Storage of Fruits and Vegetables and Greenhouse Product</div>
      </md-toolbar>
        <form name="AuditForm" ng-controller="AuditFormController">
            <md-content class="md-padding" style="padding: 10px 30px;">
                <!-- INITIALIZE AUDIT -->
                <section>
                    <div layout="row">
                      <p style="margin: 20px;">
                        Date of Audit:
                      </p>
                      <md-datepicker style="margin: 10px 0;" ng-model="audit.init.audit_date" md-placeholder="Enter date"></md-datepicker>
                      <md-input-container flex-gt-sm>
                        <label>Start Time</label>
                        <input ng-model="audit.init.start_time" type="time" name="start_time">
                      </md-input-container>
                      <md-input-container flex-gt-sm>
                        <label>End Time</label>
                        <input ng-model="audit.init.end_time" type="time" name="end_time">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Legal Operating Name (For Use on Certificate)</label>
                        <input ng-model="audit.init.legal_op_name" type="text" name="legal_op_name">
                      </md-input-container>
                      <md-input-container flex-gt-sm>
                        <label>Name of Person(S) Responsible for the Operation</label>
                        <input ng-model="audit.init.person_responsible" type="text" name="person_responsible">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Audit Completed by</label>
                        <input ng-model="audit.init.completed_by" type="text" name="completed_by">
                      </md-input-container>
                    </div>
                    <br>
                    <p>
                      Certification Body Information (FOR CB USE ONLY)
                    </p>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Certification Body</label>
                        <input ng-model="audit.init.certification_body" type="text" name="certification_body">
                      </md-input-container>
                    </div>
                    <br>
                    <div layout="row">
                      <p style="padding-right: 20px;">
                        Certificate Option:
                      </p>
                      <md-checkbox ng-model="audit.init.certificate_option.A1" name="A1" flex-gt-sm>A1</md-checkbox>
                      <md-checkbox ng-model="audit.init.certificate_option.A2" name="A2" flex-gt-sm>A2</md-checkbox>
                      <md-checkbox ng-model="audit.init.certificate_option.A3" name="A3" flex-gt-sm>A3</md-checkbox>
                      <md-checkbox ng-model="audit.init.certificate_option.B" name="B" flex-gt-sm>B</md-checkbox>
                      <md-checkbox ng-model="audit.init.certificate_option.C" name="C" flex-gt-sm>C</md-checkbox>
                    </div>
                    <br>
                    <div layout="row">
                      <p style="margin: 20px;">
                        Date of Previoud Audit:
                      </p>
                      <md-datepicker style="margin: 10px 0;" ng-model="audit.init.previous_audit_date" md-placeholder="Enter date"></md-datepicker>
                      <md-input-container flex-gt-sm>
                        <label>Certification Body conductiong Previous Audit</label>
                        <input ng-model="audit.init.cert_body_prev_audit" type="text" name="cert_body_prev_audit">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Declaration From Auditor of the Number of Times they have consecutively audited this operation</label>
                        <input ng-model="audit.init.num_of_consecutive" type="text" name="num_of_consecutive">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Number of audits to date at this operation (This number does not include the current audit)</label>
                        <input ng-model="audit.init.num_audit_todate" type="text" name="num_audit_todate">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Auditor Signature</label>
                        <input ng-model="audit.init.auditor_signature" type="text" name="auditor_signature">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Previous CanadaGAP Certificate(s) (Include certification options(s) and Applicable crops and Activities)</label>
                        <input ng-model="audit.init.prev_gap_cert" type="text" name="prev_gap_cert">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <p style="margin: 20px;">
                        Date of Issue:
                      </p>
                      <md-datepicker style="margin: 10px 0;" ng-model="audit.init.issue_date" md-placeholder="Enter date"></md-datepicker>
                      <p style="margin: 20px;">
                        Expiry Date:
                      </p>
                      <md-datepicker style="margin: 10px 0;" ng-model="audit.init.expiry_date" md-placeholder="Enter date"></md-datepicker>
                    </div>
                </section>
                <!-- INITIALIZE AUDIT -->

                <!-- OPERATION INFORMATION -->
                <section>
                    <md-subheader class="md-primary">Operation Information</md-subheader>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Legal Operating Name</label>
                        <input ng-model="audit.operation.legal_op_name" type="text" name="legal_op_name">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Name of Person(s) responsible for the Operation</label>
                        <input ng-model="audit.operation.op_person_responsible" type="text" name="op_person_responsible">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Name of Audited Location (For Multi-Site Certification)</label>
                        <input ng-model="audit.operation.audited_location_name" type="text" name="audited_location_name">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Food Safety Program Contact(s) (If different from above)</label>
                        <input ng-model="audit.operation.fs_program_contact" type="text" name="fs_program_contact">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Address</label>
                        <input ng-model="audit.operation.address" type="text" name="address">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>EAN.UCC Global Location Number (GLN) (If Available)</label>
                        <input ng-model="audit.operation.gln" type="text" name="gln">
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Phone Number</label>
                        <input ng-model="audit.operation.phone_number" type="text" name="phone_number">
                      </md-input-container>
                      <md-input-container flex-gt-sm>
                        <label>Fax Number</label>
                        <input ng-model="audit.operation.fax_number" type="text" name="fax_number">
                      </md-input-container>
                      <md-input-container flex-gt-sm>
                        <label>Email</label>
                        <input ng-model="audit.operation.email" type="text" name="email">
                      </md-input-container>
                    </div>
                    <br>
                    <p>
                      Check Type of Operation: <br>
                      Certificate Option:
                    </p>
                    <div layout="row">
                        <md-checkbox ng-model="audit.opration.production">Production</md-checkbox>
                        <md-checkbox ng-model="audit.opration.storage">Storage</md-checkbox>
                        <md-checkbox ng-model="audit.opration.packing">Packing</md-checkbox>
                        <md-checkbox ng-model="audit.opration.other">Other (Specify) (Eg. Icing Facility)</md-checkbox>
                        <md-checkbox ng-model="audit.opration.prod_pack">Production/Packing</md-checkbox>
                    </div>
                    <br>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Which Commodities and Activites (Eg. Harvesting of Peaches, Packing of Tomatoes, Etc) were observed during the Audit? What sites are applicable to this Audit (Eg. Production Sites, Storages, Packing Lines)</label>
                        <input ng-model="audit.operation.email" type="text" name="email">
                      </md-input-container>
                    </div>
                    <br>
                    <p>Do you know of any reason why you should not conduct this audit due to a conflict of interest with the operation being audited (Eg. Direct Ownership, Family Relationships, Financial Interest)?</p>
                    <md-checkbox ng-model="audit.opration.not_conduct_yes">Yes</md-checkbox>
                    <md-checkbox ng-model="audit.opration.not_conduct_no">No</md-checkbox>
                    <div layout="row" ng-show="audit.opration.not_conduct_no">
                      <md-input-container flex-gt-sm>
                        <label>Reason</label>
                        <textarea ng-model="audit.operation.not_conduct_reason" md-maxlength="200" rows="5" md-select-on-focus ng-disabled="!audit.opration.not_conduct_no"></textarea>
                      </md-input-container>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Signature of Auditor</label>
                        <input ng-model="audit.operation.signature_auditor" type="text" name="signature_auditor">
                      </md-input-container>
                      <p style="margin: 20px;">
                        Date:
                      </p>
                      <md-datepicker style="margin: 10px 0;" ng-model="audit.init.operation.date" md-placeholder="Enter date"></md-datepicker>
                    </div>
                </section>
                <!-- OPERATION INFORMATION -->

                <!-- INSTRUCTIONS -->
                <section>
                    <h2>CanadaGAP Audit Checklist©</h2>
                    <h3>Instructions to the Auditor</h3>
                    <p>
                      The CanadaGAP audit checklist is intended for the production, packing and storage of fresh fruit and vegetables and greenhouse product. The audit checklist is based on the CanadaGAPmanuals.The sections, forms and appendices mentioned throughout the audit checklist refer to these documents. Note that CanadaGAPprovides these materials as "templates"; alternate/customized/individualized record-keeping forms, etc. are acceptable as long as all the required information is captured.
                    </p>
                    <br>
                    <ul style="margin-left: 30px;">
                        <li>For each question below, mark the appropriate response by typing an 'X' in the check box beside Y (yes), N (no), N/A (not applicable), or INC (incomplete). Where there are check boxes within questions, mark in the box if the required element is present - write N/A if it is not applicable.</li>
                        <li>Enter detailed comments and observations in the column for (Auditor's Key) Comments/Observations. Extra room is provided at the end of each section. If INC is chosen, a comment must be written in the column under (Auditor's Key) Comments/Observations.</li>
                        <li>Additional guidance for the auditor is included under (Auditor's Key) Comments/Observations and is italicized and shaded in gray.</li>
                        <li>The Comments/Observations box allows for text to be written continuously. To create a list or separate lines, click "alt" + "enter" and a new line will be started within the box.</li>
                        <li>To run the spell check function, click on the ‘spell check’ button on the bottom of the scoring page.</li>
                        <li>The Executive Summary can be found in a separate worksheet (tab) located at the bottom of this document.</li>
                        <li>If any of the automatic fail items are observed (highlighted in yellow in the checklist), score the audit as an automatic failure. Describe the reason for the failure in the Executive Summary (tab below). You may continue the audit if the auditee wishes you to do so; otherwise, end the audit.</li>
                        <li>The checkboxes in the Comments/Observations (right) column are designed to help auditors document observations. These boxes DO NOT correspond directly to the score and, other than where specific guidance on scoring is provided (Auditor's Key), these boxes should not be used for determining the number of points given.</li>
                        <li>When a record is required, it is indicated in the middle column of the checklist, otherwise the question is scored based on auditor observation.</li>
                        <li>For questions that have record requirements, answering Y (yes) means the records are fully complete and accurate.</li>
                        <li>When scoring questions with multiple components or sub questions (in the left column), assign points to each sub question based on the total (e.g., if the question is out of 6 and there are 6 checkboxes or sub questions, then assign 1 point to each; if it is out of 6 and there are three sub questions then assign 2 points to each).</li>
                    </ul>
                    <br>
                    <p>
                      For those questions out of 4, 6, 8, 10 use the following criteria to assign marks:
                    </p>
                    <br>
                    <p>
                      <b>NOTE: THE ABOVE BULLET RE: SCORING MULTIPLE COMPONENTS IN THE LEFT COLUMN TAKES PRECEDENCE OVER THIS CRITERIA</b>
                    </p>
                    <br>
                    <ul style="margin-left: 30px;">
                        <li>Full marks: the records are complete, contain all essential elements, and are fully filled out at the required frequency</li>
                        <li>75% of marks: A few minor mistakes. No contamination is likely, there are enough records to indicate that procedures are being followed correctly</li>
                        <li>Half marks: more frequent mistakes. A whole minor element missing from all records that is not likely to lead to contamination</li>
                        <li>25% of marks: Missing major elements that correspond to potential food safety risk, consistently not filling out the forms correctly</li>
                        <li>No marks: No records at all</li>
                    </ul>
                    <br>
                    <h2>Scoring</h2>
                    <p>
                      <b>Instructions:</b> Score each question in the audit. If the entire question is N/A, that question gets no score and is not included in the total score for the section. For each section, the auditor tallies the maximum attainable score (for all applicable questions) and fills in the right hand column below. <b>The auditor then totals the auditee's actual score for each question and fills in the middle column</b>. For example, for Section B, Commodity Starter Products, if the auditee only grows small fruit and fully meets the requirements, the auditor would score 2 out of a total of 2 for the section (not a total of 4 because the second question becomes N/A). Each subtotal is then multiplied by the applicable factor (see next page, column 3).
                    </p>
                </section>
                <!-- INSTRUCTIONS -->

                <!-- SCORING TABLE -->
                <section>
                  <table class="ScoringTable">
                          <tbody><tr>
                              <th>Section</th>
                              <th>Auditee's Actual Score	</th>
                              <th>Maximum Attainable Score</th>
                          </tr>
                          <tr>
                              <td>
                                  <p>	A. On-Farm Food Safety Review<br>
                                      B. Commodity Starter Products<br>
                                      C. Premises<br>
                                      D. Equipment<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      4<br>
                                      4<br>
                                      30<br>
                                      38<br>
                                  </p>

                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 1</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 76</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>E. Agronomic Inputs (Questions 1-12)</p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">74</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 2a</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 74</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>E. Agronomic Inputs (Questions 13-14)</p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">8</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 2b</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 8</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>F. Agricultural Water</p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">32</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 3</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 32</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>	G. Cleaning and Maintenance Materials<br>
                                      H. Waste Management<br>
                                    I. Personal Hygiene Facilities<br>
                                      J. Employee Training<br>
                                      K. Visitor Policy<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      6<br>
                                      12<br>
                                      36<br>
                                      24<br>
                                      6<br>
                                  </p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 4</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 84</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>	L. Water (for Fluming and Cleaning) and Ice	</p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">76</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 5</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 76</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>	M. Pest Program for Buildings<br>
                                      N. Packaging Materials<br>
                                    O. Growing and Harvesting<br>
                                      P. Sorting, Grading and Packing and Storing	<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      24<br>
                                      22<br>
                                      24<br>
                                      14<br>
                                  </p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 6</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 84</p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p>	Q. Storage of Product<br>
                                      R. Transportation<br>
                                    S. Identification and Traceability<br>
                                      T. Deviations and Crisis Management	<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      8<br>
                                      8<br>
                                      10<br>
                                      16<br>
                                  </p>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <p><b>Subtotal 7</b></p>
                              </td>
                              <td>
                                  <p style="text-align:right;">
                                      0.0<br>
                                  </p>
                              </td>
                              <td>
                                  <p style="text-align:right;">Total: 42</p>
                              </td>
                          </tr>
                      </tbody></table>
                      <br>
                      <p>
                        For each subtotal in the above table, calculate the auditee's score as a percentage and fill the percentage in in column 2 below (e.g., auditee's actual score divided by the maximum attainable score x 100). Multiply the percentage by the factor in column 3 to get a final score for each subtotal. Add up all the subtotal final scores to get the Auditee's final score out of 100.
                      </p>
                      <table class="ScoringTable">
                            <tbody><tr>
                                <th>Subtotals</th>
                                <th>Percentage</th>
                                <th>Conversion Factor</th>
                                <th>Final Score</th>
                            </tr>
                            <tr>
                                <td>Subtotal 1</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.15	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 2a</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.10	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 2b</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.05	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 3</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.05	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 4</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.20	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 5</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.15	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 6</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.20	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td>Subtotal 7</td>
                                <td style="text-align:right;">0.00</td>
                                <td>Multiply column 1 by 0.10	</td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                            <tr>
                                <td><b>Final Score (Out of 100)</b></td>
                                <td style="text-align:right;">0.00</td>
                            </tr>
                        </tbody></table>
                </section>
                <!-- SCORING TABLE -->

                <!-- FINAL SCORE -->
                <section>
                    <h4>Auditee's Final Score: 0.00 % Note: A passing score is 80%</h4>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Audit Report Completed by </label>
                        <input ng-model="audit.final_score.completed_by" type="text" name="completed_by">
                      </md-input-container>
                      <p style="margin: 20px;">
                        Date:
                      </p>
                      <md-datepicker style="margin: 10px 0;" ng-model="audit.init.date" md-placeholder="Enter date"></md-datepicker>
                    </div>
                    <div layout="row">
                      <md-input-container flex-gt-sm>
                        <label>Key Person(s) present at Audit </label>
                        <input ng-model="audit.final_score.key_person" type="text" name="key_person">
                      </md-input-container>
                      <md-input-container flex-gt-sm>
                        <label>Name/Signature of Person(s) Responsible (Auditee) </label>
                        <input ng-model="audit.final_score.person_responsible" type="text" name="person_responsible">
                      </md-input-container>
                    </div>
                </section>
                <!-- FINAL SCORE -->

                <!-- CANADAGAP AUDIT CHECKLIST -->
                <section>
                    <h2>CanadaGAP Audit Checklist</h2>
                    <div class="CheckListNotice">
                        <h2>IMPORTANT NOTICE</h2>
                        <p>
                            <b>It is understood that all applicable federal, provincial, territorial and municipal regulations, or other legislation relevant to the jurisdiction, will be followed.</b>
                        </p>
                    </div>
                </section>
                <!-- CANADAGAP AUDIT CHECKLIST -->
                
                <!-- AUTOMATIC FAILURE -->
                <section>
                  <table class="automaticFailure">
                    <tr>
                      <th style="width: 50%;">Automatic Failure Items:<br><i>Check (√) if observed and score audit as an auto fail.</i></th>
                      <th style="width: 7%;"></th>
                      <th style="width: 43%;"><i>Auditor Observation(s)</i></th>
                    </tr>
                    <tr>
                      <td>1. An immediate food safety risk is present (e.g., livestock/poultry slaughter activities) when product is produced, handled, packed, repacked stored or held under conditions that promote or cause the product to become contaminated.</td>
                      <td><md-checkbox ng-model="audit.automatic_failure.one" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.one_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                    <tr>
                      <td>2. Animal/bird/human feces and/or presence/evidence of rodents is observed on <b>food contact surfaces in use, and/or in/on product</b>, during handling, packing/repacking, and/or storage of market product</td>
                      <td><md-checkbox ng-model="audit.automatic_failure.two" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.two_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                    <tr>
                      <td>3. Agricultural chemical application records are absent OR agricultural chemicals not registered for use on the applicable product in Canada are applied (see Section E, questions 8 and 11)</td>
                      <td><md-checkbox ng-model="audit.automatic_failure.three" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.three_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                    <tr>
                      <td>4. Manure is applied less than 120 days before harvest of product occurs OR complete and accurate records are not kept of manure application and harvest intervals (see Section E, question 5)</td>
                      <td><md-checkbox ng-model="audit.automatic_failure.four" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.four_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                    <tr>
                      <td>5. Sewage sludge is applied to fields or untreated sewage water is used for cleaning, fluming or as agricultural water, and/or toilet waste contaminates the product (see Sections E, F, H and L)</td>
                      <td><md-checkbox ng-model="audit.automatic_failure.five" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.five_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <p>6. Water (for Fluming and Cleaning) and Ice (Section L)</p>
                        <br>
                        <p>Question L3A) - No water tests (showing potability) are available -</p>
                        <br>
                        <p>Question L12) - No water tests (showing potability) are available and/or letters of assurance</p>
                        <br>
                        <p>A score of 0 on any of the following questions  - ONLY if the water/ice is used on product or has a food safety impact on  product. If water is used for cleaning equipment/buildings/containers the autofail does not apply</p>
                        <p>- questions L5) & L6) - combined  </p>
                        <p>- question L7) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - question L10)</p>
                        <p>- question L8) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - question L11) </p>
                        <br>
                        <p>- question L9) </p>
                      </td>
                      <td><md-checkbox ng-model="audit.automatic_failure.six" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.six_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                    <tr>
                      <td>7. Absence of Personal Hygiene Facilities. The auditee must have both: a) <b>washrooms</b>, AND b) <b>properly stocked handwashing facilities</b> (except for processing potatoes). Refer to the manual(s) for what is required for washrooms and properly stocked handwashing facilities. (see questions I1 and I3)</td>
                      <td><md-checkbox ng-model="audit.automatic_failure.seven" aria-label="label"></md-checkbox></td>
                      <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.automatic_failure.seven_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                      </td>
                    </tr>
                  </table>
                </section>
                <!-- AUTOMATIC FAILURE -->

                <!-- SAFETY PROGRAM AND MAINTAINANCE -->
                <section id="SectionA" aria-label="A. Food Safety Program Maintenance and Review">
                  <table class="SectionA">
                    <thead>
                      <tr>
                        <th><b>A. Food Safety Program Maintenance and Review <br>(refer to Section 24 in CanadaGAP manual)</b></th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <p>A1) A CanadaGAP Manual is being used?</p>
                          <md-radio-group ng-model="audit.section_a.manual_used" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>CanadaGAP Manual OR Food Safety Manual</td>
                        <td>
                          <div layout="column">
                            <md-input-container>
                              <label>Which manual(s) are being implemented?</label>
                              <input ng-model="audit.section_a.which_manual">
                            </md-input-container>
                            <md-input-container>
                              <label>What is the version number of the manual(s)?</label>
                              <input ng-model="audit.section_a.version_number">
                            </md-input-container>
                            <md-input-container>
                              <label>Is another food safety manual being used?</label>
                              <input ng-model="audit.section_a.another_manual">
                            </md-input-container>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">0</td>
                      </tr>
                      <tr>
                        <td>
                          <p>A2)  Was an annual review of the program completed? </p>
                          <md-radio-group ng-model="audit.section_a.annual_review" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          <br>
                          <p>A2)  Has the manual been updated to the most recent version?  </p>
                          <md-radio-group ng-model="audit.section_a.version_updated" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.section_a.a2_observations" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_a.a2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>A3) An internal audit was conducted (i.e., using the self-assessment checklist, the audit checklist or by using an outside party to perform a pre-audit), findings were reviewed and any necessary changes to policies and procedures were made?</p>
                          <md-radio-group ng-model="audit.section_a.internal_audit" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>Self-assessment checklist/ Audit checklist/ Third party pre-audit report</td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.section_a.a3_observations" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_a.a3_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>A4) Has the food safety program been maintained on an ongoing basis?</p>
                          <md-radio-group ng-model="audit.section_a.fsp_maintained" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          <br>
                          <p>Re-audit later in the season (see auditor's key)</p>
                          <md-radio-group ng-model="audit.section_a.reaudit_later" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          Review the manual, forms and documentation to ensure that the program has been maintained since the last audit. Partial points may be given. N/A option only applies to operations during their first audit. If the program has not been maintained an automatic re-audit will occur later in the season. 
                        </td>
                        <td style="vertical-align: bottom;">
                         <md-input-container>
                              <input ng-model="audit.section_a.a4_score" type="number" min="0" max="6" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Food Safety Program Maintenance and Review):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_a.a2_score + audit.section_a.a3_score + audit.section_a.a4_score }}</p>
                          <p>10</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- SAFETY PROGRAM AND MAINTAINANCE -->

                <!-- COMMODITY STARTER PRODUCTS -->
                <section id="SectionB" aria-label="B. Commodity Starter Products">
                  <table class="SectionB">
                    <thead>
                      <tr>
                        <th>B. Commodity Starter Products <br>(refer to Section 1 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="3" style="vertical-align: middle;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_b.not_applicable"></md-checkbox>
                        </td>
                        <td class="greyed"></td>
                      </tr>
                      <tr>
                        <td>
                          <p><b>POTATOES, TREE & VINE FRUIT, SMALL FRUIT, COMBINED VEGETABLES</b> <br>B1) Commodity starter product varieties that are genetically modified [Plants with Novel Traits (PNTs)] have been approved for use by the federal government or have been issued a letter of no-objection by Health Canada? </p>
                          <md-radio-group ng-model="audit.section_b.commodity_starter_product" layout="row">
                              <md-radio-button value="yes" class="md-primary" ng-disabled="audit.section_b.not_applicable">Y</md-radio-button>
                              <md-radio-button value="no" ng-disabled="audit.section_b.not_applicable"> N </md-radio-button>
                              <md-radio-button value="na" ng-disabled="audit.section_b.not_applicable"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>Letter of No-Objection</td>
                        <td>
                          Refer to the CFIA website <a href="http://active.inspection.gc.ca/eng/plaveg/bio/pntvcne.asp">http://active.inspection.gc.ca/eng/plaveg/bio/pntvcne.asp</a>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_b.b1_score" type="number" min="0" max="2" ng-disabled="audit.section_b.not_applicable" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p><b>POTATOES</b><br>B2) Varieties are registered in Canada OR have been tested for total glycoalkaloids?</p>
                          <md-radio-group ng-model="audit.section_b.varities_registered" layout="row">
                              <md-radio-button value="yes" class="md-primary" ng-disabled="audit.section_b.not_applicable">Y</md-radio-button>
                              <md-radio-button value="no" ng-disabled="audit.section_b.not_applicable"> N </md-radio-button>
                              <md-radio-button value="na" ng-disabled="audit.section_b.not_applicable"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          Review the manual, forms and documentation to ensure that the program has been maintained since the last audit. Partial points may be given. N/A option only applies to operations during their first audit. If the program has not been maintained an automatic re-audit will occur later in the season.
                          
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_b.b2_score" type="number" min="0" max="2" ng-disabled="audit.section_b.not_applicable" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Commodity Starter Products):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_b.b1_score + audit.section_b.b2_score }}</p>
                          <p>4</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- COMMODITY STARTER PRODUCTS -->

                <!-- PREMISES -->
                <section id="SectionC" aria-label="C. Premises (refer to Section 2 in CanadaGAP Manual)">
                  <table class="SectionC">
                    <thead>
                      <tr>
                        <th>C. Premises (refer to Section 2 in CanadaGAP Manual) <br>Includes Production Sites and Buildings</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Production Sites (includes greenhouse production sites)</b></td>
                      </tr>
                      <tr>
                        <td>
                          <p>C1) New production sites have been assessed for the presence of heavy metals and other contaminants?</p>
                          <md-radio-group ng-model="audit.section_c.new_production_sites" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          For new production sites, consider uses for the past 5 years. Review manual and ask questions as required.
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c1_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>C2) Production sites have been assessed for potential hazards from adjacent areas and animal/bird activity?</p>
                          <md-radio-group ng-model="audit.section_c.production_sites_assessed" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          Consider agricultural chemical/excrement drift and industrial activities, wildlife; Review manual, and record visual observations (e.g., evidence of serious animal intrusion into production site)                          
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c2_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Buildings [where product is handled and/or stored, where packaging materials, agricultural chemicals, fertilizers, etc., are stored] (includes greenhouse production sites)</b></td>
                      </tr>
                      <tr>
                        <td>
                          <p>C3) A sketch of the interior of all buildings includes:</p>
                          <div layout="column">
                            <md-checkbox ng-model="audit.section_c.c3_no_sketch" aria-label="label">No Sketch</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_na" aria-label="label">N/A (no buildings)</md-checkbox>
                            <p>OR</p>
                            <md-checkbox ng-model="audit.section_c.c3_packing_repacking" aria-label="label">Packing/Repacking line(s)</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_pest_control" aria-label="label">Pest Control Devices and Pest Control Product Storage</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_harvested_product" aria-label="label">Harvested and Market Product</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_hand_washing" aria-label="label">Hand washing Facilities</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_washrooms" aria-label="label">Washrooms</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_market_ready" aria-label="label">Market ready packaging materials</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_agricultural_chemical" aria-label="label">Agricultural Chemical Storage</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c3_container_tank" aria-label="label">Container/Tank/Cistern Storage (i.e., heating oil/fuel, water)</md-checkbox>
                          </div>
                        </td>
                        <td style="vertical-align: middle; text-align: center;"><a ng-click="goToRecord('A')">A</a></td>
                        <td>
                          <div layout="column">
                              <p><i>Type of building:</i></p>
                              <md-checkbox ng-model="audit.section_c.c3_packinghouse" aria-label="label">Packinghouse</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c3_repacking_facility" aria-label="label">Repacking Facility</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c3_greenhouse_production" aria-label="label">Greenhouse Production Site</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c3_product_storage" aria-label="label">Product Storage</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c3_wholesale_facility" aria-label="label">Wholesale Facility</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c3_other" aria-label="label">Other:</md-checkbox>
                              <md-input-container ng-show="audit.section_c.c3_other">
                              <label>Other</label>
                              <input ng-model="audit.section_c.c3_other_desc" type="text">
                            </md-input-container>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c3_score" type="number" min="0" max="4" aria-label="label" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>C4) Exterior of buildings are assessed to ensure there are no potential hazards and maintained to prevent contamination of product?</p>
                          <md-radio-group ng-model="audit.section_c.c4_exterior_assessed" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <div layout="column">
                              <p><i>Record observations:</i></p>
                              <md-checkbox ng-model="audit.section_c.c4_crevices_holes" aria-label="label">Crevices/holes allow pest access</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c4_poor_drainage" aria-label="label">Poor drainage</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c4_doors_windows_screens" aria-label="label">Doors/window/screens do not fit properly</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c4_other" aria-label="label">Other:</md-checkbox>
                              <md-input-container ng-show="audit.section_c.c4_other">
                              <label>Other</label>
                              <input ng-model="audit.section_c.c4_other_desc" type="text">
                            </md-input-container>
                            <md-checkbox ng-model="audit.section_c.c4_long_grass_junk" aria-label="label">Long grass/ junk/garbage around buildings</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c4_contamination" aria-label="label">Contamination from location (e.g., drifting, airborne pollutants, cross-contamination, livestock/poultry/fish facilities, etc.)</md-checkbox>
                            <md-checkbox ng-model="audit.section_c.c4_new_construction" aria-label="label">New construction or renovations/modifications do not meet applicable building codes</md-checkbox>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c4_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>C5) Interior of buildings are assessed to ensure there are no potential hazards and maintained to prevent contamination of product?</p>
                          <md-radio-group ng-model="audit.section_c.c5_interior_assessed" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <div layout="column">
                              <p><i>Record observations:</i></p>
                              <md-checkbox ng-model="audit.section_c.c5_leaking_pipes" aria-label="label">Leaking pipes/ condensation</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_poor_drainage" aria-label="label">Poor drainage</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_garbage_spills" aria-label="label">Garbage/spills/ debris</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_open_catwalks" aria-label="label">Open catwalks above product</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_crevices_holes" aria-label="label">Crevices/holes in building (floors/walls etc.)</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_lighting_not_shatterproof" aria-label="label">Lighting not shatterproof/covered above product/packaging (include lights on equipment such as packing line)</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_animals" aria-label="label">Animals (including pets), pests or bird nests</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_lighting_inadequate" aria-label="label">Lighting inadequate for sorting/grading and/or for maintaining cleanliness within buildings (e.g., to see into corners)</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_contaimination" aria-label="label">Contamination from location (e.g., air, foot, hand, equipment cross-contamination, livestock/poultry/fish facilities, etc.)</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_inadqaute_ventilation" aria-label="label">Inadequate ventilation/contaminated air is not removedis</md-checkbox>
                              <md-checkbox ng-model="audit.section_c.c5_other" aria-label="label">Other, describe:</md-checkbox>
                              <md-input-container ng-show="audit.section_c.c5_other">
                              <label>Other, describe</label>
                              <input ng-model="audit.section_c.c5_other_desc" type="text">
                            </md-input-container>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c5_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>C6) Monthly inspection of all buildings recorded when in use?</p>
                          <md-radio-group ng-model="audit.section_c.monthly_inspection" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td style="vertical-align: middle; text-align: center;"><a ng-click="goToRecored('G')">G</a></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Observations</label>
                              <textarea ng-model="audit.section_a.c5_observations" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c6_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>C7) Pre-season product storage inspection is complete and recorded?</p>
                          <md-radio-group ng-model="audit.section_c.pre_season_product" layout="row">
                              <md-radio-button value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button value="no"> N </md-radio-button>
                              <md-radio-button value="na"> N/A </md-radio-button>
                              <md-radio-button value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td style="vertical-align: middle; text-align: center;"><a ng-click="goToRecored('B')">B</a></td>
                        <td>
                          Ensure all items on Form B have been completed for EACH storage 
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_c.c7_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Premises):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_c.c1_score + audit.section_c.c2_score + audit.section_c.c3_score + audit.section_c.c4_score + audit.section_c.c5_score + audit.section_c.c6_score + audit.section_c.c7_score }}</p>
                          <p>30</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- PREMISES -->

                <!-- EQUIPMENT -->
                <section id="SectionD" aria-label="D. Equipment">
                  <table class="SectionD">
                    <thead>
                      <tr>
                        <th>D. Equipment <br>(refer to Section 8 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">If entire section is not applicable to the operation check box and go to next section: 
                        <md-checkbox ng-model="audit.section_d.not_applicable"></md-checkbox></td>
                      </tr>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Production Site Equipment (NOTE: Questions D3, D5 and D6 also pertain to building equipment)</b></td>
                      </tr>
                      <tr>
                        <td>
                          <p>D1) Production site equipment:</p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d1_no_production_site_equipment" aria-label="label">(No production site equipment)</md-checkbox>
                            <br>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d1_inspected_before_use" aria-label="label">is inspected before use (2 points)</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d1_clean_when_use" aria-label="label">is cleaned when in use (2 points)</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d1_condition_not_contributed" aria-label="label">condition does not contribute to contamination of product (4 points)</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Production site equipment is free of excessive rust, leaks, broken, corroded or damaged parts, etc. and is clean. Refer to commodity-specific requirements for cleaning frequency. </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_d.d1_score" ng-disabled="audit.section_d.not_applicable" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D2) Records are kept of production site equipment cleaning, inspection and maintenance, when in use and at appropriate frequency?</p>
                          <md-radio-group ng-model="audit.section_d.recored_kept_production" layout="row">
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToRecord('I')">I <br>SSOP</a></td>
                        <td>
                          <i>Appropriate frequency for inspection/cleaning/recording: Refer to commodity-specific requirements</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_d.d2_score" type="number" min="0" max="2" required ng-disabled="audit.section_d.not_applicable">
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D3) Agricultural chemical application equipment (in both the production site and building) is calibrated according to written instructions and records are kept?</p>
                          <md-radio-group ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.agricultural_chemical_app_equip" layout="row">
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToRecord('I')">I</a></td>
                        <td>
                          <i>Calibration instructions & records available for applications in both the production site and buildings (e.g., sprout  inhibitor). Equipment may include sprayers, scales, nozzles, etc.</i>
                          <br>
                          <i>Check that measuring equipment exists if necessary</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_d.d3_score" ng-disabled="audit.section_d.not_applicable" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D4)  Agricultural chemical application equipment: </p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d4_na" aria-label="label">N/A</md-checkbox>
                            <br>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d4_is_cleaned" aria-label="label">is cleaned, used for mixing, rinsed or flushed where production sites and/or water sources may not become contaminated?</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d4_prevent_backflow" aria-label="label">A method is used to prevent backflow from application equipment into water sources or production site</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Backflow prevention could be a one-way valve or leaving a gap between the filling hose and the tank</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_d.d4_score" type="number" ng-disabled="audit.section_d.not_applicable" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D5) Hand-held cutting and trimming tools (<b>in both the production site and buildings</b>) that are in direct contact with product are : </p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d5_na" aria-label="label">(hand held cutting/trimming tools are not used)</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d5_non_retractable" aria-label="label">Non-retractable</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d5_cleaned_daily" aria-label="label">Cleaned daily before use</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.dd.cleaning_recorded" aria-label="label">Cleaning is recorded daily</md-checkbox>
                          </div>
                        </td>
                        <td><a ng-click="goToRecord('I')">I</a></td>
                        <td>
                          <i><b>Greenhouse manual</b> - retractable knives may be used but an SOP must be in place to control physical hazard </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-model="audit.section_d.d5_score" ng-disabled="audit.section_d.not_applicable" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D6) Hoses for potable water uses (<b>in both the production site and buildings</b>) are/have:</p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d6_na" aria-label="label">(no hoses)</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d6_ends_kept_up" aria-label="label">ends are kept up off the ground</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d6_stored_contamination" aria-label="label">stored in a way that prevents contamination</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d6_flushed_before_use" aria-label="label">flushed out before EACH use</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d6_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d6_score" type="number" min="0" max="3" required>
                              <div class="hint">3</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Building equipment</b></td>
                      </tr>
                       <tr>
                        <td>
                          <p>D7) Building equipment is:</p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d7_na" aria-label="label">(No building equipment)</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d7_inspected_before_use" aria-label="label">inspected before use</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d7_cleaned_weekly" aria-label="label">cleaned weekly (minimum) when in use</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d7_easily_accessed" aria-label="label">easily accessed for cleaning</md-checkbox>
                             <md-checkbox ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d7_condition_not_contributed" aria-label="label">condition does not contribute to contamination of product</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Building equipment does not contribute to contamination of product (e.g., clean, free of excessive rust, chipping paint, leaks, broken, corroded or damaged parts)? </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d7_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D8) Records are kept of building equipment cleaning, inspection and maintenance weekly when in use?</p>
                          <md-radio-group ng-model="audit.section_d.d8_record_kept" layout="row">
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToRecord('I')">I <br>SSOP</a></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d8_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d8_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>D9) Calibration records are available for building equipment such as pH/ORP meter, automatic chlorinator, thermometer, etc.?</p>
                          <md-radio-group ng-model="audit.section_d.d9_calibration_records" layout="row">
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToRecord('I')">I</a></td>
                        <td>
                          <i>This does not include any equipment for agricultural chemical applications - see question D3)</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d9_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Production Site Equipment and Building Equipment</b></td>
                      </tr>
                      <tr>
                        <td>
                          <p>D10) All equipment (when not in use) is stored separate from product, water sources, market ready packaging materials, etc.?</p>
                          <md-radio-group ng-model="audit.section_d.d10_equip_stored_seperate" layout="row">
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_d.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Is equipment stored to prevent leakage of fuel, oil, gases, etc., on to product/packaging materials?</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_d.not_applicable" ng-model="audit.section_d.d10_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Equipment):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_d.d1_score  + audit.section_d.d2_score + audit.section_d.d3_score + audit.section_d.d4_score + audit.section_d.d5_score + audit.section_d.d6_score + audit.section_d.d7_score + audit.section_d.d8_score + audit.section_d.d9_score + audit.section_d.d10_score }}</p>
                          <p>43</p>
                        </td>
                      </tr>
                  </tbody>
                </table>
              </section>
                <!-- EQUIPMENT -->

              <!-- AGRONOMIC INPUTS -->
              <section id="SectionE" aria-label="E. Agronomic Inputs">
                  <table class="SectionE">
                    <thead>
                      <tr>
                        <th>E. Agronomic Inputs <br>(refer to Sections 3,4,5 and 6 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_e.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Production Site Equipment (NOTE: Questions D3, D5 and D6 also pertain to building equipment)</b></td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>E1) Sewage sludge is used?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e1_sewage_sludge" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e1_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <b>If YES, auto fail</b>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E2) A letter of assurance or written procedures are available for compost/compost tea?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e2_letter_assurance" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>Letter of Assurance/ Procedures</td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E3) Pulp sludge meets provincial regulations?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e3_pulp_sludge" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                          <br>
                          <p>Soil amendments meet provincial regulations?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e2_soil_amendments" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>Records as required by province</td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e3_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e3_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E4) Complete and accurate records are kept of agronomic input applications (fertilizers, soil amendments, pulp sludge, mulch/row covers, compost/compost tea, other by-products)? See question E5 for manure and question E11 for agricultural chemical records</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e4_complete_accurate_records" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td><a ng-click="goToRecord('H2')">H2</a></td>
                        <td>
                         <i>Records for other by-products include the type. Application records are not required for cover crops/green manure or plastic mulch/row covers. Greenhouse operations need records only of compost/compost tea and other by-product applications.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e4_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>E5) Manure is applied at least 120 days before harvest?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e5_manure_applied" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                          <br>
                          <p>Product is not harvested until the 120 days has elapsed?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e5_product_not_harvested" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                          <br>
                          <p>Complete and accurate records are kept of manure application and harvest intervals?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e5_complete_accurate_records" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>
                          <a ng-click="goToRecord('H2')">H2</a><br>
                          <a ng-click="goToRecord('P1/P2')">P1/P2</a><br>
                          <a ng-click="goToRecord('Q')">Q</a>
                        </td>
                        <td>
                         <i>Operations will autofail if manure is applied less than 120 days before harvest OR records are not kept. The 120 days needs to have elapsed before harvest and this needs to be recorded somehow. The scoring for this question is all or nothing. Look at Form H2 to see when manure was applied and cross check this with Forms P1/P2/Q to ensure that the 120 day interval had elapsed before harvest began. A checkmark (or some sort of identifier) must be recorded to show this was done. The scoring for this question is all or nothing.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e5_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E6) Manure is stored separately to prevent contamination?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e6_manure_stored_seperatly" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                         <i>Manure is stored separate from water sources, production sites, buildings, equipment, product, etc.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e6_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E7) Agronomic inputs (<b>other than agricultural chemicals - see question E12 and manure - see question E5</b>) are stored separate from product, market ready packaging materials or other contaminants?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e7_agronomic_inputs" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                         <i>New plastic mulch/row covers can be stored with packaging materials. </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e7_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>E8) Agricultural chemicals are purchased from licensed dealers and registered for use on the applicable product in Canada or permitted under the Grower Requested Own Use Program or the Own Use Import Program and receipts are kept?       </p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e8_agricultural_chemicals" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>Receipt/ GROU or OUI certificate</td>
                        <td>
                         <i>The autofail pertains ONLY to using agricultural chemicals that are NOT registered for use on the applicable product in Canada. Points will be deducted for purchasing from unlicensed dealers or not keeping receipts.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e8_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E9) Agricultural chemical applicator(s) is/are either formally trained/licensed/ certified or supervised by a person formally trained/licensed/certified to apply chemicals? </p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e9_agricultural_chemicals" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>License/ Certificate/Formal Training Documents  </td>
                        <td>
                         <i>Need to see proof (i.e., certificate, course outline, license) of training/licensing/certification of person doing the supervising or of person doing the actual application.</i>
                         <br>
                         <i>The scoring for this question is all or nothing - either the applicator(s) is/are formally trained/certified/ licensed or supervised by someone who is, or they are not.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e9_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E10) Agricultural chemicals are mixed and applied according to label directions?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e10_agricultural_chemicals" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                         <i>Label directions are available?</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e10_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>E11) Records are kept of agricultural chemical applications?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e10_agricultural_chemicals" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>
                          <a ng-click="goToRecord('H1')">H1</a><br>
                          <a ng-click="goToRecord('H3')">H3</a><br>
                          <a ng-click="goToRecord('P1')">P1</a>
                        </td>
                        <td>
                         <i>Records  may include applications in the production site, before/during storage, during packing and to seed potatoes.</i>
                         <br>
                         <i><b>Important Information (worth more points)</b></i>
                         <div layout="column">
                            <md-checkbox ng-model="audit.section_e.e11_phi" aria-label="label">PHI</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_area_treated" aria-label="label">Area treated</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_product_trade_name" aria-label="label">Product/Trade name</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_application_date" aria-label="label">Application Date</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_rate_applied" aria-label="label">Rate Applied and Label Followed</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_signature" aria-label="label">Signature/Name of Applicator</md-checkbox>
                         </div>
                         <i><b>Less Important Information (worth fewer points)</b></i>
                         <div layout="column">
                            <md-checkbox ng-model="audit.section_e.e11_earliest_allowable_harvest" aria-label="label">Earliest Allowable Harvest date (EAHD)</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_application_method" aria-label="label">Application method</md-checkbox>
                            <md-checkbox ng-model="audit.section_e.e11_pcp_num" aria-label="label">PCP #</md-checkbox>
                         </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e11_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>E12) Agricultural chemicals are stored in an area that is:</p>
                          <div layout="column">
                            <md-checkbox ng-label="audit.section_e.e12_na" aria-label="label">(Producer does not store agricultural chemicals)</md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e12_clearly_identified" aria-label="label">clearly identified and dedicated only to agricultural chemicals & commercial fertilizers</md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e12_locked" aria-label="label">locked</md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e12_maintains_integrity" aria-label="label">maintains integrity of containers</md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e12_pose_a_risk" aria-label="label">does not pose a risk of contamination</md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e12_labels_intact" aria-label="label">labels intact/legible </md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e12_covered" aria-label="label">covered, dry and clean</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                         <i>Risk of contamination: e.g., large chemical storage tanks that do not fit in a building should not be leaking etc.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e12_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p><b>FOR EXPORTS ONLY: (Complete Q. 13-14)</b></p>
                          <p>E13) Only chemicals approved for use in destination markets are used according to label directions and supporting information is available about acceptable chemicals in destination markets (e.g., registration for the specific crop, product labels, Maximum Residue Limits, banned lists, etc.)?  </p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_e.e13.only_chemical_approved" layout="row">
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_e.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>Supporting documents</td>
                        <td>
                         <md-input-container class="md-block">
                          <label>Comments/Observations</label>
                          <textarea ng-model="audit.section_e.e13_observation" md-maxlength="500" rows="5" md-select-on-focus ng-disabled="audit.section_e.not_applicable"></textarea>
                        </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e13_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                        <td>
                          <p>E14) Where customers require agricultural chemical residue testing:</p>
                          <div layout="column">
                            <md-checkbox ng-label="audit.section_e.e14_na" aria-label="label">N/A</md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e14_na" aria-label="label">Agricultural chemical residues on product do not exceed the published Maximum Residue Limits (MRL) in the destination market(s)? </md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e14_na" aria-label="label">Residue test results are available from an accredited lab where analyses are performed to standards equivalent to ISO 17025, or evidence is available demonstrating participation in a third party agricultural chemical residue monitoring system traceable to the farm? </md-checkbox>
                            <md-checkbox ng-label="audit.section_e.e14_na" aria-label="label">INC</md-checkbox>
                          </div>
                        </td>
                        <td>Test Results and/or Supporting Documents</td>
                        <td>
                         <md-input-container class="md-block">
                          <label>Comments/Observations</label>
                          <textarea ng-model="audit.section_e.e14_observation" md-maxlength="500" rows="5" md-select-on-focus ng-disabled="audit.section_e.not_applicable"></textarea>
                        </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_e.not_applicable" ng-model="audit.section_e.e14_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Agronomic Inputs):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_e.e1_score + audit.section_e.e2_score + audit.section_e.e3_score + audit.section_e.e4_score + audit.section_e.e5_score + audit.section_e.e6_score + audit.section_e.e7_score + audit.section_e.e8_score + audit.section_e.e9_score + audit.section_e.e10_score + audit.section_e.e11_score + audit.section_e.e12_score + audit.section_e.e13_score + audit.section_e.e14_score }}</p>
                          <p>82</p>
                        </td>
                      </tr>
                  </tbody>
              </table>
          </section>
              <!-- AGRONOMIC INPUTS -->

              <!-- AGRICULTURAL WATER -->
              <section id="SectionF" aria-label="F. Agricultural Water">
                  <table class="SectionF">
                    <thead>
                      <tr>
                        <th>F. Agricultural Water <br>(refer to Section 7 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_f.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="4" style="background: rgba(0, 0, 0, 0.1); text-align: left;"><b>Production Site Equipment (NOTE: Questions D3, D5 and D6 also pertain to building equipment)</b></td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>F1) Untreated sewage water is used?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_f.f1_untreated_sewage_water" layout="row">
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f1_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <b>If YES, auto fail</b>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>F2) Water sources have been assessed?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_f.f2_water_source_assessed" layout="row">
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                        <p><i>Each source is assessed for animal access, upstream contamination, runoff/spills, pipe contamination, wells in proper working condition, leaching etc.? </i></p>
                        <br>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f2_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>F3) If risk is identified, corrective actions and/or preventive measures have been taken?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_f.f3_risk_identified" layout="row">
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                        <p><i>Corrective Actions and/or Preventive measures (e.g., testing, barriers/buffers, aeration, filtration, alternate source, etc.):</i></p>
                        <br>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f3_corrective_actions" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f3_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>F4) <b>GREENHOUSE PRODUCT</b></p>
                          <div layout="column">
                            <md-checkbox ng-model="audit.section_f.f4_no_greenhouse" aria-label="label">(no greenhouse product)</md-checkbox>
                            <md-checkbox ng-model="audit.section_f.f4_only_municipal_water" aria-label="label">(only municipal water that is not recirculated/stored is used)</md-checkbox>
                          </div>
                          <table class="SectionFTests">
                              <thead>
                                  <tr>
                                      <th>Water tests are available showing microbiological quality is appropriate for intended use?</th>
                                      <th>1st Water Test <br><br>• Prior to initial use <br>• NOT prior to initial use</th>
                                      <th>2nd Water Test <br><br>(taken anytime during the season)</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <tr>
                                      <td>
                                          <p>1) ALL PRODUCTS - use potable water for overhead sprays of agricultural chemicals and for misting</p>
                                          <md-checkbox ng-model="audit.section_f.f4_1_use_portable_water_na" aria-label="label"> N/A </md-checkbox>
                                      </td>
                                      <td>
                                          <div layout="column">
                                              <p><b>Prior to</b></p>
                                              <div layout="row">
                                                <md-radio-group ng-model="audit.section_f.f4_1_prior_to" layout="row">
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                              </md-radio-group>
                                          </div>
                                          <br>
                                          <md-divider></md-divider>
                                          <br>
                                          <div layout="column">
                                              <p><b>NOT Prior to</b></p>
                                              <div layout="row">
                                                <md-radio-group ng-model="audit.section_f.f4_1_not_prior_to" layout="row">
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                              </md-radio-group>
                                          </div>
                                      </td>
                                      <td>
                                          <div layout="row">
                                            <md-radio-group ng-model="audit.section_f.f4_1_yes_no" layout="row">
                                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                          </md-radio-group>
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <p>2) ONLY FOR FLOATING/LIVING LETTUCE/HERBS - use potable water for filling/replenishing ponds</p>
                                          <md-checkbox ng-model="audit.section_f.f4_2_portable_water_na" aria-label="label"> N/A </md-checkbox>
                                      </td>
                                      <td>
                                          <div layout="column">
                                              <p><b>Prior to</b></p>
                                              <div layout="row">
                                                <md-radio-group ng-model="audit.section_f.f4_2_prior_to" layout="row">
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                              </md-radio-group>
                                          </div>
                                          <br>
                                          <md-divider></md-divider>
                                          <br>
                                          <div layout="column">
                                              <p><b>NOT Prior to</b></p>
                                              <div layout="row">
                                                <md-radio-group ng-model="audit.section_f.f4_2_not_prior_to" layout="row">
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                              </md-radio-group>
                                          </div>
                                      </td>
                                      <td>
                                          <div layout="row">
                                            <md-radio-group ng-model="audit.section_f.f4_2_yes_no" layout="row">
                                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                          </md-radio-group>
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <p>3) ONLY FOR LEAFY GREENS AND HERBS <br>- use potable water for irrigation/fertigation/ chemigation  </p>
                                          <md-checkbox ng-model="audit.section_f.f4_3_portable_water_na" aria-label="label"> N/A </md-checkbox>
                                      </td>
                                      <td>
                                          <div layout="column">
                                              <p><b>Prior to</b></p>
                                              <div layout="row">
                                                <md-radio-group ng-model="audit.section_f.f4_3_prior_to" layout="row">
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                              </md-radio-group>
                                          </div>
                                          <br>
                                          <md-divider></md-divider>
                                          <br>
                                          <div layout="column">
                                              <p><b>NOT Prior to</b></p>
                                              <div layout="row">
                                                <md-radio-group ng-model="audit.section_f.f4_3_not_prior_to" layout="row">
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                                  <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                              </md-radio-group>
                                          </div>
                                      </td>
                                      <td>
                                          <div layout="row">
                                            <md-radio-group ng-model="audit.section_f.f4_3_yes_no" layout="row">
                                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                                          </md-radio-group>
                                      </td>
                                  </tr>
                              </tbody>
                          </table>
                        </td>
                        <td>Water tests</td>
                        <td>
                            <p><i>2 annual water tests required for potability. Municipal water needs to be tested ONLY if the water is recycled/recirculated/stored. Samples should be taken from the source (tap, well, cistern/storage container/tank, etc.) .</i></p>
                            <br>
                            <table class="SectionFScoring">
                                <tr>
                                    <th colspan="4">
                                        SCORING
                                    </th>
                                </tr>
                                <tr>
                                    <th>Test 1: PRIOR to  initial use</th>
                                    <th>Test 1: Not Prior to initial use</th>
                                    <th>Test 2: anytime during the season</th>
                                    <th>Score</th>
                                </tr>
                                <tr>
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>NO</td>
                                    <td>YES</td>
                                    <td>NO</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>YES</td>
                                    <td>N/A</td>
                                    <td>NO</td>
                                    <td>10</td>
                                </tr>
                                <tr>
                                    <td>NO</td>
                                    <td>YES</td>
                                    <td>YES</td>
                                    <td>10</td>
                                </tr>
                                <tr>
                                    <td>YES</td>
                                    <td>N/A</td>
                                    <td>YES</td>
                                    <td>20</td>
                                </tr>
                            </table>
                            <br>
                            <p><b><i>The 20 marks for this question are awarded for complete testing of ALL water uses.  Therefore, if 2 out of 3 water uses have been tested appropriately, the question will be scored for the one that has not been.</i></b></p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f4_score" type="number" min="0" max="20" required>
                              <div class="hint">20</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>F5) If agricultural water is stored the cistern/tank/container has been cleaned OR a water test is available?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_f.f5_water_source_assessed" layout="row">
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_f.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td>Water test</td>
                        <td>
                        <p><i>The operation has the option to clean the storage cistern/tank/container OR take one water test prior to use of the water to ensure the cistern/tank/container is not contaminated. The scoring for this question is all or nothing.</i></p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_f.not_applicable" ng-model="audit.section_f.f5_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Agricultural Water):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_f.f2_score + audit.section_f.f3_score + audit.section_f.f4_score + audit.section_f.f5_score }}</p>
                          <p>32</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
              <!-- AGRICULTURAL WATER -->

              <!-- CLEANING AND MAINTENANCE -->
              <section id="SectionG" aria-label="G. Cleaning and Maintenance Material">
                  <table class="SectionG">
                    <thead>
                      <tr>
                        <th>G. Cleaning and Maintenance Materials <br>(refer to Section 9 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_g.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>G1) Cleaning and maintenance materials are appropriate for intended use and used according to label instructions?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_g.g1_cleaning_maintenance" layout="row">
                              <md-radio-button ng-disabled="audit.section_g.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_g.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_g.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_g.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Do sanitizers, oils, fuels, water treatment chemicals, etc., pose a risk of contamination to product?</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g1_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>G2) Cleaning and maintenance materials are stored:</p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_material_not_stored_na" aria-label="label">materials are not stored</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_clean_dry" aria-label="label">in a clean/dry location</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_labels_intact" aria-label="label">with labels intact/legible</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_container_integrity" aria-label="label">with the container(s) integrity maintained</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_seperate_product" aria-label="label">separate from product, equipment, waste, agricultural chemicals and market ready packaging materials</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_g.g2_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Cleaning and Maintenance Materials):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_g.g1_score + audit.section_g.g2_score }}</p>
                          <p>6</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- CLEANING AND MAINTENANCE -->

                <!-- WASTE MANAGEMENT -->
                <section id="SectionH" aria-label="H. Waste Management">
                  <table class="SectionH">
                    <thead>
                      <tr>
                        <th>H. Waste Management <br>(refer to Section 10 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_h.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>H1) Garbage, recyclables and compostable waste: </p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h1_dedicated_containers" aria-label="label">are in dedicated containers in appropriate areas</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h1_cull_piles" aria-label="label">cull piles are stored away from market product (if applicable)</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h1_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>H2) Containers are covered (where pest intrusion is a problem), emptied and cleaned as necessary? </p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_h.h2_containers_covered" layout="row">
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_h.h2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>H3) Empty agricultural chemical containers are: </p>
                          <div layout="column">
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_na" aria-label="label">N/A</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_not_reused" aria-label="label">not reused</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_disposed" aria-label="label">disposed of according to applicable regulations</md-checkbox>
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_stored_seperate" aria-label="label">stored separate from product, water sources and market ready packaging materials </md-checkbox>
                            <md-checkbox ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h2_stored_designated" aria-label="label">stored in a designated/labelled area/container</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h4_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_g.not_applicable" ng-model="audit.section_h.h3_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>H4) Waste from toilets is disposed of away from the production site(s), agronomic inputs, water sources, etc.?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_h.h4_waste_disposed" layout="row">
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Waste from toilets must not contaminate anything that could possibly contaminate the product</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <b>If NO, auto fail</b>
                        </td>
                      </tr>
                       <tr>
                        <td>
                          <p>H5) Waste from hand washing facilities and production wastewater are disposed of properly?</p>
                          <div layout="column">
                            <md-radio-group ng-model="audit.section_h.h5_waste_hand_washing" layout="row">
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Disposal of waste/wastewater does not contaminate product, water sources, packaging materials, agronomic inputs, etc.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_h.not_applicable" ng-model="audit.section_h.h5_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Waste Management):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_h.h1_score + audit.section_h.h2_score + audit.section_h.h3_score + audit.section_h.h5_score }}</p>
                          <p>12</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- WASTE MANAGEMENT -->

                <!-- PERSONAL HYGIENE -->
                <section id="SectionI" aria-label="I. Personal Hygiene Facilities">
                  <table class="SectionI">
                    <thead>
                      <tr>
                        <th>I. Personal Hygiene Facilities <br>(refer to Section 11 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_i.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>I1) Washroom(s) and hand washing facility(ies) are provided for Production Site employees:</p>
                          <md-checkbox ng-model="audit.section_i.i1_washroom_na" aria-label="label" ng-disabled="audit.section_i.not_applicable">(no production site)</md-checkbox>
                          <br>
                          <br>
                          <p><b>a) Production site washrooms (see Auditor's Key for requirements)</b></p>
                          <md-radio-group ng-model="audit.section_i.i1_production_site_washroom" layout="row">
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_h.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <br>
                          <div layout="row">
                            <md-input-container>
                              <label># of toilets</label>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_num_toilets" type="text">
                            </md-input-container>
                            <md-input-container>
                              <label># of production site employees</label>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_num_production_site" type="text">
                            </md-input-container>
                          </div>
                          <br>
                          <p>Stocked with toilet paper</p>
                          <md-radio-group ng-model="audit.section_i.i1_stocked_toiler_paper" layout="row">
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <br>
                          <br>
                          <p>Properly stocked handwashing facilities in the production site or header house/entrance/ service room/connecting house (Greenhouse) </p>
                          <md-radio-group ng-model="audit.section_i.i1_properly_stocked_handwashing" layout="row">
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <br>
                          <br>
                          <md-checkbox ng-model="audit.section_i.i1_hand_washing_not_required" aria-label="label">(Hand washing facility NOT required)</md-checkbox>
                          <md-input-container class="md-block" ng-show="audit.section_i.i1_hand_washing_not_required">
                              <label>Explain why it is NOT required</label>
                              <textarea ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_hand_washing_not_required_explain" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                          <br>
                          <br>
                          <p>Choose one of the 3 options below – all items in the option chosen must be present to avoid autofailing</p>
                          <p>These include:</p>
                          <br>
                          <p><b>Option 1:</b></p>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option1_portable_water" aria-label="label">potable water</md-checkbox>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option1_paper_towel" aria-label="label">paper towel</md-checkbox>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option1_soap" aria-label="label">soap</md-checkbox>
                          <br>
                          <br>
                          <p><b>Option 2:</b></p>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option2_water" aria-label="label">water</md-checkbox>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option2_paper_towel" aria-label="label">paper towel</md-checkbox>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option2_hand_sanitizer" aria-label="label">hand sanitizer</md-checkbox>
                          <br>
                          <br>
                          <p><b>Option 3:</b></p>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option3_hand_wipes" aria-label="label">hand wipes</md-checkbox>
                          <md-checkbox ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_option3_hand_sanitizer" aria-label="label">hand sanitizer</md-checkbox>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Appropriate # of toilets: refer to commodity-specific requirements. Washrooms must be on-site or in the header house/entrance/service room/connecting house/adjacent building  (Greenhouse) OR  accessible through transportation</i>
                          <br>
                          <br>
                          <i>Note: Hand washing water stored in permanent tanks within portable washrooms is NOT considered potable UNLESS the water potability is confirmed as per procedures in Section 15.</i>
                          <br>
                          <br>
                          <i><b>NOTE: Processing Potato operations will NOT autofail if they do not have handwashing facilities in the production site; instead they will lose points.</b></i>
                          <br>
                          <br>
                          <i>Note on scoring: The scoring for this question is all or nothing. For example, if there is a properly stocked hand washing facility but no toilet it will be an autofail; part marks should not be given for the hand washing facility. Partially stocked handwashing facilities are also an AUTOFAIL (no part marks).</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i1_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>I2) Handwashing facilities in the production site have:</p>
                          <md-checkbox ng-model="audit.section_i.i2_no_production_site" aria-label="label" ng-disabled="audit.section_i.not_applicable">(no production site)</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i2_hand_washing_facility" aria-label="label" ng-disabled="audit.section_i.not_applicable">(hand washing facility NOT required)</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i2_garbage_can" aria-label="label" ng-disabled="audit.section_i.not_applicable">garbage can</md-checkbox>  
                          <md-checkbox ng-model="audit.section_i.i2_hand_washing_signs" aria-label="label" ng-disabled="audit.section_i.not_applicable">hand washing signs</md-checkbox>                          
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>I3) Washroom(s) and hand washing facility(ies) are provided for Packinghouse and Product Storage employees:</p>
                          <md-checkbox ng-model="audit.section_i.i3_no_packinghouse" aria-label="label" ng-disabled="audit.section_i.not_applicable">(no packinghouse)</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i3_no_product_storage" aria-label="label" ng-disabled="audit.section_i.not_applicable">(no product storage))</md-checkbox>
                          <br>                
                          <table>
                              <tr>
                                  <td colspan="3"><b>a) Packinghouse/product storage washrooms (see Auditor's Key for requirements)</b></td>
                              </tr>
                              <tr>
                                  <th></th>
                                  <th>Packing-house:</th>
                                  <th>Product storage:</th>
                              </tr>
                              <tr>
                                  <td></td>
                                  <td>
                                    <md-radio-group ng-model="audit.section_i.i3_packinghouse" layout="row">
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                                    </md-radio-group>
                                  </td>
                                  <td>
                                    <md-radio-group ng-model="audit.section_i.i3_product_storage" layout="row">
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                                    </md-radio-group>
                                  </td>
                              </tr>
                              <tr>
                                  <td># of toilets</td>
                                  <td>
                                      <md-input-container>
                                        <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i3_toilet_num_packinghouse" type="text">
                                      </md-input-container>
                                  </td>
                                  <td>
                                      <md-input-container>
                                        <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i3_toilet_num_product_storage" type="text">
                                      </md-input-container>
                                  </td>
                              </tr>
                              <tr>
                                  <td># of employees</td>
                                  <td>
                                      <md-input-container>
                                        <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i3_employees_packinghouse" type="text">
                                      </md-input-container>
                                  </td>
                                  <td>
                                      <md-input-container>
                                        <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i3_employees_product_storage" type="text">
                                      </md-input-container>
                                  </td>
                              </tr>
                              <tr>
                                  <td>Stocked with toilet paper</td>
                                  <td>
                                      <md-radio-group ng-model="audit.section_i.i3_stocked_packinghouse" layout="row">
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                                    </md-radio-group>
                                  </td>
                                  <td>
                                      <md-radio-group ng-model="audit.section_i.i3_stocked_product_storage" layout="row">
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                                    </md-radio-group>
                                  </td>
                              </tr>
                              <tr>
                                  <td colspan="3"><b>b) Properly stocked handwashing facilities in the packinghouse/ product storage </b></td>
                              </tr>
                              <tr>
                                  <td></td>
                                  <td>
                                      <md-radio-group ng-model="audit.section_i.i3_stocked_handwashing_packinghouse" layout="row">
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                                    </md-radio-group>
                                  </td>
                                  <td>
                                      <md-radio-group ng-model="audit.section_i.i3_stocked_handwashing_product_storage" layout="row">
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                        <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                                    </md-radio-group>
                                  </td>
                              </tr>
                              <tr>
                                  <td colspan="3">Choose one of the 3 options below – all items in the option chosen must be present to avoid autofailing</td>
                              </tr>
                              <tr>
                                  <td colspan="3">Option 1</td>
                              </tr>
                              <tr>
                                  <td>potable water</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option1_packinghouse_water" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option1_product_storage_water" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td>paper towel</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option1_packinghouse_paper_towel" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option1_product_storage_paper_towel" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td>soap</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option1_packinghouse_soap" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option1_product_storage_soap" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td colspan="3">Option 2</td>
                              </tr>
                              <tr>
                                  <td>water</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option2_packinghouse_water" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option2_product_storage_water" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td>paper towel</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option2_packinghouse_paper_towel" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option2_product_storage_paper_towel" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td>hand sanitizer</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option2_packinghouse_hand_sanitizer" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option2_product_storage_hand_sanitizer" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td colspan="3">Option 3</td>
                              </tr>
                              <tr>
                                  <td>hand wipes</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option3_packinghouse_hand_wipes" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option3_product_storage_hand_wipes" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                              <tr>
                                  <td>hand sanitizer</td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option3_packinghouse_hand_sanitizer" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                                  <td><md-checkbox ng-model="audit.section_i.i3_option3_product_storage_hand_sanitizer" aria-label="label" ng-disabled="audit.section_i.not_applicable"></md-checkbox></td>
                              </tr>
                          </table>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Appropriate # of toilets: refer to commodity-specific requirements. Washrooms must be in the packinghouse/product storage or in the immediate vicinity.</i>
                          <br><br>
                          <i>Note: Hand washing water stored in permanent tanks within portable washrooms is NOT considered potable UNLESS the water potability is confirmed as per procedures in Section 15.</i>
                          <br><br>
                          <i><b>NOTE: Processing Potato operations will NOT autofail if they do not have handwashing facilities in either the product storage or packinghouse; instead they will lose points.</b></i>
                          <br><br>
                          <i><b>Note on scoring: The scoring for this question is all or nothing. For example, if there is a properly stocked hand washing facility but no toilet it will be an autofail;  part marks should not be given for the  hand washing facility. Partially stocked handwashing facilities are also an AUTOFAIL (no part marks). If there is both a packinghouse and product storage(s) it is all or nothing. This means both the packinghouse and the product storage(s) need to have ALL of the requirements. No part marks are to be given for just the packinghouse or the product storage(s). If there is only a packinghouse or only a product storage the total score will still be out of 10. </b></i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i3_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>I4) Handwashing facilities in the packinghouse/product storages have:</p>
                          <md-checkbox ng-model="audit.section_i.i4_no_packinghouse" aria-label="label" ng-disabled="audit.section_i.not_applicable">(no packinghouse/product storages)</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i4_garbage_can" aria-label="label" ng-disabled="audit.section_i.not_applicable">garbage can</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i4_hand_washing" aria-label="label" ng-disabled="audit.section_i.not_applicable">hand washing signs</md-checkbox>                           
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i4_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i4_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                       <tr>
                        <td>
                          <p>I5) Personal hygiene facilities (washrooms and handwashing facilities) are inspected and maintained when in use and records are available?</p>
                          <md-radio-group ng-model="audit.section_i.i5_personal_hygiene" layout="row">
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_i.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>  
                        </td>
                        <td><a ng-click="goToRecord('J')">J</a></td>
                        <td>
                         <i>Check for frequency - daily during peak season and weekly while in use. Cleaning company contract and invoice is acceptable. Ask Auditee about inventory of supplies.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i5_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                       <tr>
                        <td>
                          <p>I6) Are there:</p>
                          <md-checkbox ng-model="audit.section_i.i6_waterproof" aria-label="label" ng-disabled="audit.section_i.not_applicable">waterproof coverings for wounds (e.g., gloves)</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i6_fully_stocked" aria-label="label" ng-disabled="audit.section_i.not_applicable">fully stocked first aid kits (with bandages)</md-checkbox>
                          <md-checkbox ng-model="audit.section_i.i6_dedicated_lunch" aria-label="label" ng-disabled="audit.section_i.not_applicable">dedicated lunch/break areas</md-checkbox>                           
                          <md-checkbox ng-model="audit.section_i.i6_dedicated_areas" aria-label="label" ng-disabled="audit.section_i.not_applicable">dedicated areas to store personal effects</md-checkbox>                           
                          <md-checkbox ng-model="audit.section_i.i6_employees_remove" aria-label="label" ng-disabled="audit.section_i.not_applicable">employees remove working effects before breaks/entering washrooms </md-checkbox>                           
                          <md-checkbox ng-model="audit.section_i.i6_proper_storage" aria-label="label" ng-disabled="audit.section_i.not_applicable">proper storage of working effects</md-checkbox>                           
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Personal effects are away from product and washrooms; lunchrooms are separate from product handling areas; working effects are stored separate from food contact surfaces, break areas or other sources of contamination? Working effects include gloves, aprons, smocks, etc.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_i.not_applicable" ng-model="audit.section_i.i6_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Personal Hygiene Facilities):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_i.i1_score + audit.section_i.i2_score + audit.section_i.i3_score + audit.section_i.i4_score + audit.section_i.i5_score + audit.section_i.i6_score }}</p>
                          <p>36</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- PERSONAL HYGIENE -->

                <!-- EMPLOYEE TRAINING -->
                <section id="SectionJ" aria-label="H. Employee Training">
                  <table class="SectionJ">
                    <thead>
                      <tr>
                        <th>J. Employee Training <br>(refer to Section 12 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_j.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>J1) Personal hygiene and food handling practices training is provided: </p>
                          <p>to all employee?</p>
                          <md-radio-group ng-model="audit.section_j.j1_personal_hygiene" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                          <p>as refresher to returning employees?</p>
                          <md-radio-group ng-model="audit.section_j.j1_refresher" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                          <p>to reinforce new practices?</p>
                          <md-radio-group ng-model="audit.section_j.j1_reinforce" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                          <p>in appropriate language(s)?</p>
                          <md-radio-group ng-model="audit.section_j.j1_appropriate" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j1_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j1_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>J2) Complete and accurate training on personal hygiene and food handling practices is given and records are available?</p>
                          <md-radio-group ng-model="audit.section_j.j2_complete_accurate" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td>
                          <a ng-click="goToRecord('C')">C</a><br>
                          <a ng-click="goToRecord('D')">D</a><br>
                          <a ng-click="goToRecord('K')">K</a>
                        </td>
                        <td>
                          <p>Training session/records cover:</p>
                          <div layout="column">
                              <md-checkbox ng-model="audit.section_j.j2_hand_washing" ng-disabled="audit.section_j.not_applicable" aria-label="label">hand washing</md-checkbox>
                              <md-checkbox ng-model="audit.section_j.j2_production_practise" ng-disabled="audit.section_j.not_applicable" aria-label="label">production practices</md-checkbox>
                              <md-checkbox ng-model="audit.section_j.j2_glove_apron" ng-disabled="audit.section_j.not_applicable" aria-label="label">glove and apron use</md-checkbox>
                              <md-checkbox ng-model="audit.section_j.j2_employee_biosecurity" ng-disabled="audit.section_j.not_applicable" aria-label="label">employee biosecurity</md-checkbox>
                              <md-checkbox ng-model="audit.section_j.j2_major_minor" ng-disabled="audit.section_j.not_applicable" aria-label="label">major and minor deviations</md-checkbox>
                              <md-checkbox ng-model="audit.section_j.j2_cleanliness" ng-disabled="audit.section_j.not_applicable" aria-label="label">cleanliness, jewellery (packinghouse/product storage only)</md-checkbox>
                              <md-checkbox ng-model="audit.section_j.j2_injury" ng-disabled="audit.section_j.not_applicable" aria-label="label">employee injury and illness</md-checkbox>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j2_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>J3) A designated person is responsible for training and compliance?</p>
                          <md-radio-group ng-model="audit.section_j.j3_designated_person" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j3_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j3_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>J4) Employees are adhering to safe food handling practices?</p>
                          <md-radio-group ng-model="audit.section_j.j4_food_handling" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group> 
                          <br>
                          <div class="autoFailRow">
                            <md-checkbox ng-model="audit.section_j.j4_inappropriate" ng-disabled="audit.section_j.not_applicable" aria-label="label">Employees NOT using or inappropriately using the personal hygiene facilities.</md-checkbox>
                          </div>
                          <br><br>
                          <md-checkbox ng-model="audit.section_j.j4_no_employee" ng-disabled="audit.section_j.not_applicable" aria-label="label">N/A (no employees at time of audit)</md-checkbox>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>The autofail is for all commodities EXCEPT for processing potatoes. These operations will lose points.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j4_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>J5) Policy is in place for handling employee illness?</p>
                          <md-radio-group ng-model="audit.section_j.j5_policy_handling" layout="row">
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_j.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j5_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_j.not_applicable" ng-model="audit.section_j.j5_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Employee Training):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_j.j1_score + audit.section_j.j2_score + audit.section_j.j3_score + audit.section_j.j4_score + audit.section_j.j5_score }}</p>
                          <p>24</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- EMPLOYEE TRAINING -->

                <!-- VISITOR POLICY -->
                <section id="SectionK" aria-label="K. Visitor Policy">
                  <table class="SectionK">
                    <thead>
                      <tr>
                        <th>K. Visitor Policy <br>(refer to Section 13 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_k.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>K1) Controlled-access areas are determined within buildings?</p>
                          <md-radio-group ng-model="audit.section_k.k1_controlled_access" layout="row">
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <p><i>Designated controlled access for:</i></p>
                          <br>
                          <div layout="column">
                              <md-checkbox ng-model="audit.section_k.k1_packing_repacking" aria-label="label" ng-disabled="audit.section_k.not_applicable">packing/ repacking area</md-checkbox>
                              <md-checkbox ng-model="audit.section_k.k1_market_ready" aria-label="label" ng-disabled="audit.section_k.not_applicable">market ready packaging material storage</md-checkbox>
                              <md-checkbox ng-model="audit.section_k.k1_product_storages" aria-label="label" ng-disabled="audit.section_k.not_applicable">product storages</md-checkbox>
                              <md-checkbox ng-model="audit.section_k.k1_other" aria-label="label" ng-disabled="audit.section_k.not_applicable">other</md-checkbox>
                              <md-input-container ng-show="audit.section_k.k1_other">
                                <label>Other</label>
                                <input ng-disabled="audit.section_k.not_applicable" ng-model="audit.section_k.k1_other_info" type="text">
                              </md-input-container>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_k.not_applicable" ng-model="audit.section_k.k1_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>K2) Visitors are informed of and understand visitor policy?  </p>
                          <md-radio-group ng-model="audit.section_k.k2_visitors_informed" layout="row">
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group> 
                          <br>
                          <p>Visitor sign-in records are available? </p>
                          <md-radio-group ng-model="audit.section_k.k2_visitor_sign_in" layout="row">
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td><a ng-click="goToRecord('L')"></a></td>
                        <td>
                          <i>Auditor is informed of visitor policy or policy is visible and auditor is asked to sign in</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_k.not_applicable" ng-model="audit.section_k.k2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>K3) U-pick customers are provided with washrooms, hand washing facility(ies),  a hygiene policy and a set of instructions?    </p>
                          <md-radio-group ng-model="audit.section_k.k3_upick_customers" layout="row">
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_k.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Customers are instructed (visual, written or verbal) to use washrooms, to use garbages, to wash hands, to harvest into clean containers, etc. </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_k.not_applicable" ng-model="audit.section_k.k3_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Visitor Policy):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_k.k1_score + audit.section_k.k2_score + audit.section_k.k3_score }}</p>
                          <p>6</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- VISITOR POLICY -->

                <!-- WATER AND ICE -->
                <section id="SectionL" aria-label="L. Water (for Fluming and Cleaning) and Ice">
                  <table class="SectionL">
                    <thead>
                      <tr>
                        <th>L. Water (for Fluming and Cleaning) and Ice <br>(refer to Sections 15 and 16 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_l.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>L1) Is untreated sewage water or tertiary water used?</p>
                          <md-radio-group ng-model="audit.section_l.l1_untreated_sewage_water" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td></td>
                        <td>
                        <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l1_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <b>If YES, auto fail</b>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>L2) Written assessment of each water source includes: intended use, method of application, potential hazards, corrective actions (if any)?</p>
                          <md-radio-group ng-model="audit.section_l.l2_written_assessment" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToRecord('F')">F</a></td>
                        <td>
                        <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l2_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>L3A) Describe how and what ALL water is used for (e.g., treated well water for handwashing, municipal water for final rinse, well water to fill flumes, etc.). </p>
                          <md-input-container class="md-block">
                              <label>Describe</label>
                              <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_description" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                          <br>
                          <md-checkbox ng-model="audit.section_l.l3_municipal_water_used" ng-disabled="audit.section_l.not_applicable" aria-label="label">ONLY Municipal water is used?  </md-checkbox>
                          <br>
                          <p>Is ANY water treated? </p>
                          <md-radio-group ng-model="audit.section_l.l3_any_water_treated" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <br>
                          <div ng-show="audit.section_l.l3_any_water_treated == 'yes'">
                              <md-input-container class="md-block">
                                <label>If yes, how is the water treated and what is the treated water used for?</label>
                                <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_water_treated_what_how" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                          </div>
                          <br>
                          <p>Is ANY water stored (cistern/tank/container)?</p>
                          <md-radio-group ng-model="audit.section_l.l3_any_water_stored" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <br>
                          <div ng-show="audit.section_l.l3_any_water_stored == 'yes'">
                              <md-input-container class="md-block">
                                <label>If yes, what is stored water used for? </label>
                                <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_water_treated_what_how" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                          </div>
                          <br>
                          <md-input-container class="md-block">
                              <label># of individual equipment (packinglines, tanks, etc.)</label>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_individual_equipment" type="text">
                            </md-input-container>
                            <br>
                            <md-input-container class="md-block">
                              <label># of individual water sources (e.g., well, municipal, surface, cistern/tank/container, etc.) </label>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_individual_water_source" type="text">
                            </md-input-container>
                            <table class="SectionFTests">
                                <tr class="autoFailRow">
                                    <th>Water tests are available showing microbiological quality is appropriate for intended use?</th>
                                    <th>1st Water Test <br>• Prior to initial use <br>• NOT prior to initial use</th>
                                    <th>2nd Water Test <br>(taken anytime during the season)</th>
                                </tr>
                                <tr class="autoFailRow">
                                    <td colspan="3"><b>THE BELOW ARE AUTOFAIL ITEMS IF NO WATER TESTS HAVE BEEN COMPLETED</b></td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td colspan="3">
                                      <md-checkbox ng-model="audit.section_l.l3_only_municipal_water" ng-disabled="audit.section_l.not_applicable" aria-label="label">(only municipal water is used and it is not stored, treated or used for the final rinse)</md-checkbox>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water used to fill/replenish flumes, wash/drench tanks, hydro-coolers, etc.</p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_flumes_tanks_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_flumes_tanks_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_flumes_tanks_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_flumes_tanks_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water used to wash melons </p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_melons_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_melons_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_melons_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_melons_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water used to wash leafy greens  </p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_leafy_green_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_leafy_green_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_leafy_green_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_leafy_green_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water used for flume/wash/drench/ cooling/ hydro-cooling/slush is kept potable</p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_flume_cooling_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_flume_cooling_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_flume_cooling_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_flume_cooling_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Final Rinse water</p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_final_rinse_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_final_rinse_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_final_rinse_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_final_rinse_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p><b>CRANBERRIES ONLY</b></p>
                                      <p>Final Rinse water after wet harvesting</p>
                                      <p><b>OR</b></p>
                                      <p>Processor provides a final rinse confirmed with a letter of assurance</p>
                                      <md-radio-group ng-model="audit.section_l.l3_water_processor_final_rinse" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                      <md-checkbox ng-model="audit.section_l.l3_water_wet_harvesting_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A (no wet harvesting of cranberries)</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_cranberries_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_cranberries_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_cranberries_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Chemical application (during packing) water</p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_chemical_application_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_chemical_application_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_chemical_application_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_chemical_application_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water used for packaging accessories (e.g., to wet pads/liners)</p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_packaging_accessories_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_packaging_accessories_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_packaging_accessories_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_packaging_accessories_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water for humidity/ misting (except for  potatoes)</p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_humidity_misting_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_humidity_misting_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_humidity_misting_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_humidity_misting_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                                <tr class="autoFailRow">
                                    <td>
                                      <p>Water for handwashing </p>
                                      <md-checkbox ng-model="audit.section_l.l3_water_handwashing_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">N/A</md-checkbox>
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_handwashing_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3_water_handwashing_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3_water_handwashing_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                            </table>
                        </td>
                        <td>Water tests <br>Letter of assurance </td>
                        <td>
                            <i>Samples should be taken from the source (e.g., tap, well, cistern, storage container/tank etc.) OR from the equipment (e.g., nozzles, tank, hose, wetting equipment, humidity/misting equipment, etc.). Each equipment (e.g., line, tank, hose, etc.) needs to be tested to be in compliance. </i>
                            <br><br>
                            <i>Municipal water ONLY needs to be tested in certain circumstances (e.g., water is used for final rinse, is treated, is stored, etc.). Review Section 15.1 to ensure the sample is taken when necessary and from the appropriate location.             </i>
                            <br><br>
                            <i>Hand washing water stored in permanent tanks within portable washrooms is not considered potable UNLESS the water potability is confirmed as per procedures in Section 15. </i>
                            <br><br>
                            <i>Potable water is NOT required for handwashing if sanitizer is used</i>
                            <br><br>
                            <i>If cranberries are wet harvested a final rinse is provided, unless proof is shown that a final rinse occurs at processing (i.e., a letter of assurance). Full marks are given if a letter of assurance is provided. </i>
                            <br><br>
                            <i><b>NOTE: The autofail does not apply to potatoes and vegetables for PROCESSING, instead they will lose points. Potatoes for processing need potable water only for handwashing. </b></i>
                          <md-input-container class="md-block">
                                <label>Comments:</label>
                                <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_comments_1" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                              <table>
                                  <tr class="autoRowFail">
                                      <th colspan="4"><b>SCORING: AUTOFAIL ITEMS</b></th>
                                  </tr>
                                  <tr>
                                      <th>Test 1: PRIOR to  initial use</th>
                                      <th>Test 1: NOT Prior to initial use</th>
                                      <th>Test 2: anytime during the season</th>
                                      <th>Score</th>
                                  </tr>
                                  <tr class="autoRowFail">
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>AUTO-FAIL</td>
                                  </tr>
                                  <tr>
                                      <td>NO</td>
                                      <td>YES</td>
                                      <td>NO</td>
                                      <td>0</td>
                                  </tr>
                                  <tr>
                                      <td>YES</td>
                                      <td>N/A</td>
                                      <td>NO</td>
                                      <td>5</td>
                                  </tr>
                                  <tr>
                                      <td>NO</td>
                                      <td>YES</td>
                                      <td>YES</td>
                                      <td>5</td>
                                  </tr>
                                  <tr>
                                      <td>YES</td>
                                      <td>N/A</td>
                                      <td>YES</td>
                                      <td>10</td>
                                  </tr>
                              </table>
                              <p><b><i>The 10 marks for this question are awarded for complete testing of ALL water uses.  Therefore, if 4 out of 5 water uses have been tested appropriately, the question will be scored for the one that has not been.</i></b></p>
                              <md-input-container class="md-block">
                                <label>Comments:</label>
                                <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_comments_2" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                          <td>
                              <p>L3B) Describe the sources (e.g., well, municipal, surface, cistern/tank/container, etc.) used to clean equipment, containers and buildings (e.g., well #1 to clean packingline, well #2 treated to wash building floor, stored municipal water in tank to clean containers, etc.):</p>
                              <md-input-container class="md-block">
                                <label>Describe:</label>
                                <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3b_describe_source" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                              <p><b>THE BELOW IS NOT AN AUTOFAIL ITEM IF NO WATER TESTS HAVE BEEN COMPLETED</b></p>
                              <br>
                              <br>
                              <md-checkbox aria-label="label" ng-model="audit.section_l.l3b_only_municipal_water" ng-disabled="audit.section_l.not_applicable">N/A (only municipal water is used and it is not stored, treated or used for the final rinse)</md-checkbox>
                              <br>
                              <table>
                                  <tr>
                                      <td>
                                          <p>Water for cleaning equipment, containers or buildings </p>
                                          <md-checkbox aria-label="label" ng-model="audit.section_l.l3b_cleaning_equip_na" ng-disabled="audit.section_l.not_applicable">N/A</md-checkbox>
                                      </td>
                                      <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3b_cleaning_equip_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l3b_cleaning_equip_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l3b_wcleaning_equip_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                  </tr>
                              </table>
                          </td>
                          <td>Water tests</td>
                          <td>
                            <table>
                                  <tr class="autoRowFail">
                                      <th colspan="4"><b>SCORING: AUTOFAIL ITEMS</b></th>
                                  </tr>
                                  <tr>
                                      <th>Test 1: PRIOR to  initial use</th>
                                      <th>Test 1: NOT Prior to initial use</th>
                                      <th>Test 2: anytime during the season</th>
                                      <th>Score</th>
                                  </tr>
                                  <tr class="autoRowFail">
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>0</td>
                                  </tr>
                                  <tr>
                                      <td>NO</td>
                                      <td>YES</td>
                                      <td>NO</td>
                                      <td>0</td>
                                  </tr>
                                  <tr>
                                      <td>YES</td>
                                      <td>N/A</td>
                                      <td>NO</td>
                                      <td>4</td>
                                  </tr>
                                  <tr>
                                      <td>NO</td>
                                      <td>YES</td>
                                      <td>YES</td>
                                      <td>4</td>
                                  </tr>
                                  <tr>
                                      <td>YES</td>
                                      <td>N/A</td>
                                      <td>YES</td>
                                      <td>8</td>
                                  </tr>
                              </table>
                              <p><i><b>The 8 marks for this question are awarded for complete testing of ALL water uses.  Therefore, if 4 out of 5 water uses have been tested appropriately, the question will be scored for the one that has not been.</b></i></p>
                          </td>
                          <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l3b_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>L4) <b>CANTALOUPES/MUSK MELONS </b></p>
                          <md-checkbox aria-label="label" ng-model="audit.section_l.l4_musk_melon_washed_na" ng-disabled="audit.section_l.not_applicable">N/A</md-checkbox>
                          <br>
                          <p>Cantaloupes/musk melons that are washed/flumed/cooled, are NOT fully submerged in the water?</p>
                          <md-radio-group ng-model="audit.section_l.l4_musk_melon_washed_cooled" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                            <i>Measures are taken such as controlling product through-put, minimizing the depth of the water, etc. to prevent full submersion </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l4_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>L5) Treated water is treated properly and treatment is monitored?  </p>
                          <md-radio-group ng-model="audit.section_l.l5_treated_water" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>Instructions/Labels</td>
                        <td>
                            <i>This includes slush/ice slurry.</i>
                            <br>
                            <i>Look at the instructions/labels for the treatment method and ensure that these are being followed .</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l5_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>L6) Records are kept of water treatment monitoring?  </p>
                          <md-radio-group ng-model="audit.section_l.l6_record_water_treatment" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToForm('N1')">N1</a></td>
                        <td>
                          <md-input-container class="md-block">
                                <label>Comments/Observation</label>
                                <textarea ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l6_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l6_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>L7) TOMATOES/APPLES</p>
                          <md-checkbox ng-model="audit.section_l.l7_not_produced_washed" ng-disabled="audit.section_l.not_applicable" aria-label="label">(These commodities are not produced or washed)</md-checkbox>
                          <md-checkbox ng-model="audit.section_l.l7_washed_potable" ng-disabled="audit.section_l.not_applicable" aria-label="label">(These commodities are washed BUT water is kept potable [see question L3A) for water tests]</md-checkbox>(These commodities are washed BUT water is kept potable [see question L3A) for water tests]
                          <br><br>
                          <p>Water is not kept potable therefore product and water temperature is monitored/controlled?</p>
                          <md-radio-group ng-model="audit.section_l.l7_potable_monitored" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToForm('N2')">N2</a></td>
                        <td>
                          <i>Are control measures in place to ensure that contaminated water is not internalized by tomatoes/apples? If water has been kept potable choose N/A and move to the next question. If water has not been kept potable the water temperature must be kept at least 10 deg F (5.5 deg C) warmer than product (i.e., internal core temperature of product is at least 10 deg F [5.5 deg C] colder than the water). The scoring for this question is all or nothing. Check Form N2 for accuracy and completion.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l7_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                        <td>
                          <p>L8) The cistern/tank/container (used to store water): </p>
                          <md-checkbox ng-model="audit.section_l.l8_not_stored_na" ng-disabled="audit.section_l.not_applicable" aria-label="label">(Water is not stored)</md-checkbox>
                          <br><br>
                          <p>Is cleaned (annually prior to use and monthly during use)?</p>
                          <md-radio-group ng-model="audit.section_l.l8_cleaned_annually" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <p>Cleaning is recorded?</p>
                          <md-radio-group ng-model="audit.section_l.l8_cleaning_recorded" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <p>Filling procedure is followed (each time it is filled)?</p>
                          <md-radio-group ng-model="audit.section_l.l8_filling_procedure" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <p>Filling mechanism, employees and outside sources are not a source of contamination? </p>
                          <md-radio-group ng-model="audit.section_l.l8_filling_mechanism" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                          <p>Part where the water is emptied from (e.g., spigot, tap, opening, etc.) is kept free from contamination?</p>
                          <md-radio-group ng-model="audit.section_l.l8_filling_mechanism" layout="row">
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_l.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToForm('I')">I</a><br><p>SOP</p><p>SSOP</p></td>
                        <td>
                          <i>Each cistern/tank/container must have its own SSOP for cleaning.</i>
                          <br>
                          <i>For the filling of cisterns/tanks/containers there must be a different SOP for each water source, type of tank/container/cistern or filling mechanism.</i>
                          <br>
                          <i>Note: annual cleaning of the cistern/tank/container must be completed prior to use of the water. The first water test must be taken after this cleaning (see L3A for water tests).</i>
                          <br>
                          <i>Scoring for this question is <b>all or nothing</b>. </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_l.not_applicable" ng-model="audit.section_l.l8_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If ice is not used in the operation, check box and proceed to Section M: 
                          <md-checkbox ng-model="audit.section_l.ice_not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr class="autoFailRow">
                          <td>
                            <p>L9) Ice is stored in clean, covered, designated containers/areas and in a manner that protects it from contamination?</p>
                            <md-radio-group ng-model="audit.section_l.l9_ice_clean_covered" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                          </td>
                          <td></td>
                          <td>
                             <md-input-container class="md-block">
                                <label>Comments/Observation</label>
                                <textarea ng-disabled="audit.section_l.ice_not_applicable" ng-model="audit.section_l.l9_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                          </td>
                          <td style="vertical-align: bottom;">
                            <md-input-container>
                                <input ng-disabled="audit.section_l.ice_not_applicable" ng-model="audit.section_l.l9_score" type="number" min="0" max="2" required>
                                <div class="hint">2</div>
                              </md-input-container>
                        </td>
                      </tr> 
                      <tr class="autoFailRow">
                          <td>
                            <p>L10)  Ice is handled to prevent contamination including using clean, designated tools/equipment?</p>
                            <md-radio-group ng-model="audit.section_l.l10_contamination" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                          </td>
                          <td></td>
                          <td>
                             <md-input-container class="md-block">
                                <label>Comments/Observation</label>
                                <textarea ng-disabled="audit.section_l.ice_not_applicable" ng-model="audit.section_l.l10_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                              </md-input-container>
                          </td>
                          <td style="vertical-align: bottom;">
                            <md-input-container>
                                <input ng-disabled="audit.section_l.ice_not_applicable" ng-model="audit.section_l.l10_score" type="number" min="0" max="2" required>
                                <div class="hint">2</div>
                              </md-input-container>
                        </td>
                      </tr> 
                      <tr class="autoFailRow">
                          <td>
                            <p>L11) Ice is not recycled or recovered?</p>
                            <md-radio-group ng-model="audit.section_l.l11_not_recycled" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                          </td>
                          <td></td>
                          <td>
                             <i>Note: This does not include slush/ice slurry. Slush is covered under Water (for fluming and cleaning).</i>
                          </td>
                          <td style="vertical-align: bottom;">
                            <md-input-container>
                                <input ng-disabled="audit.section_l.ice_not_applicable" ng-model="audit.section_l.l11_score" type="number" min="0" max="2" required>
                                <div class="hint">2</div>
                              </md-input-container>
                        </td>
                      </tr> 
                      <tr class="autoFailRow">
                          <td>
                            <p>L12) Ice is purchased?</p>
                            <md-radio-group ng-model="audit.section_l.l12_ice_purchased" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                            <br>
                            <p>A letter of assurance is available (if ice is purchased)?</p>
                            <md-radio-group ng-model="audit.section_l.l12_letter_assurance" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                            <br>
                            <p>Ice is produced on-site?</p>
                            <md-radio-group ng-model="audit.section_l.l12_ice_produced" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                            <br>
                            <p>Ice tests (two per year) are available (if ice is produced on-site)?</p>
                            <md-radio-group ng-model="audit.section_l.l12_ice_tests" layout="row">
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="no"> N </md-radio-button>
                                <md-radio-button ng-disabled="audit.section_l.ice_not_applicable" value="na"> N/A </md-radio-button>
                            </md-radio-group>
                            <br><br>
                            <table>
                                <tr>
                                    <th>Ice tests are available showing microbiological quality is appropriate for intended use?</th>
                                    <th>1st Ice Test <br> • Prior to initial use <br>• NOT prior to initial use</th>
                                    <th>2nd Ice Test <br>(taken anytime during the season)</th>
                                </tr>
                                <tr>
                                    <td>
                                        Ice produced on-site
                                    </td>
                                    <td>
                                        <p>Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l12_1st_ice_test_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                        <br>
                                        <md-divider></md-divider>
                                        <br>
                                        <p>NOT Prior to</p>
                                        <md-radio-group ng-model="audit.section_l.l12_1st_ice_test_not_prior_to" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                    <td>
                                        <md-radio-group ng-model="audit.section_l.l12_2nd_water_test" layout="row">
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                                            <md-radio-button ng-disabled="audit.section_l.not_applicable" value="no"> N </md-radio-button>
                                        </md-radio-group>
                                    </td>
                                </tr>
                            </table>
                          </td>
                          <td>Ice tests or Letter of Assurance</td>
                          <td>
                             <i>Check N/A if the audit occurs too early for ice test (e.g., no ice on site because it will not be used for 2 months). Ice sample is taken from the point closest to the product. If ice is purchased, a letter of assurance is required and the scoring is all or nothing.</i>
                             <br><br>
                             <table>
                                  <tr class="autoRowFail">
                                      <th colspan="4"><b>SCORING</b></th>
                                  </tr>
                                  <tr>
                                      <th>Test 1: PRIOR to  initial use</th>
                                      <th>Test 1: NOT Prior to initial use</th>
                                      <th>Test 2: anytime during the season</th>
                                      <th>Score</th>
                                  </tr>
                                  <tr class="autoRowFail">
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>AUTO-FAIL</td>
                                  </tr>
                                  <tr>
                                      <td>NO</td>
                                      <td>YES</td>
                                      <td>NO</td>
                                      <td>0</td>
                                  </tr>
                                  <tr>
                                      <td>YES</td>
                                      <td>N/A</td>
                                      <td>NO</td>
                                      <td>2</td>
                                  </tr>
                                  <tr>
                                      <td>NO</td>
                                      <td>YES</td>
                                      <td>YES</td>
                                      <td>2</td>
                                  </tr>
                                  <tr>
                                      <td>YES</td>
                                      <td>N/A</td>
                                      <td>YES</td>
                                      <td>4</td>
                                  </tr>
                              </table>
                              <p><b><i>The 4 marks for this question are awarded for complete testing of all ice being produced. </i></b></p>
                          </td>
                          <td style="vertical-align: bottom;">
                            <md-input-container>
                                <input ng-disabled="audit.section_l.ice_not_applicable" ng-model="audit.section_l.l12_score" type="number" min="0" max="4" required>
                                <div class="hint">4</div>
                              </md-input-container>
                        </td>
                      </tr> 
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Water (for Fluming and Cleaning) and Ice):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_l.l2_score + audit.section_l.l3_score + audit.section_l.l4_score + audit.section_l.l5_score + audit.section_l.l6_score + audit.section_l.l7_score + audit.section_l.l8_score + audit.section_l.l9_score + audit.section_l.l10_score + audit.section_l.l11_score + audit.section_l.l12_score }}</p>
                          <p>76</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- WATER AND ICE -->

                <!-- PEST PROGRAMS AND BUILDING -->
                <section id="SectionM" aria-label="M. Pest Program for Buildings">
                  <table class="SectionM">
                    <thead>
                      <tr>
                        <th>M. Pest Program for Buildings <br>(refer to Section 14 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_m.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>M1) Visual assessment of interior of buildings in use:</p>
                          <div layout="column">
                              <md-checkbox ng-model="audit.section_m.m1_na" aria-label="label" ng-disabled="audit.section_m.not_applicable">N/A (no buildings)</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m1_chewed_Wall" aria-label="label" ng-disabled="audit.section_m.not_applicable">no chewed walls/boxes</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m1_birs_nesting" aria-label="label" ng-disabled="audit.section_m.not_applicable">no birds nesting</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m1_animals_tracks" aria-label="label" ng-disabled="audit.section_m.not_applicable">no animals/animal tracks</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m1_feces" aria-label="label" ng-disabled="audit.section_m.not_applicable">no feces</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Is the pest program effective?</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_m.not_applicable" ng-model="audit.section_m.m1_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>M2) Type of pest control program:</p>
                          <div layout="column">
                              <md-checkbox ng-model="audit.section_m.m2_na" aria-label="label" ng-disabled="audit.section_m.not_applicable">N/A (no buildings)</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m2_third_party" aria-label="label" ng-disabled="audit.section_m.not_applicable">third party</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m2_self_managed" aria-label="label" ng-disabled="audit.section_m.not_applicable">self-managed</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m2_none" aria-label="label" ng-disabled="audit.section_m.not_applicable">none</md-checkbox>
                          </div>
                          <br>
                          <p>Records are kept of control, monitoring and use of pest control devices and products? </p>
                          <md-radio-group ng-model="audit.section_m.m3_records_kept_control" layout="row">
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td><a ng-click="goToRecord('E')">E</a><br><a ng-click="goToRecord('M')">M</a></td>
                        <td>
                          <i>Points are only for the records. Forms E and M give information pertaining to how pests are controlled and if monthly monitoring is occurring.      </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_m.not_applicable" ng-model="audit.section_m.m2_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>M3) Traps are: </p>
                          <div layout="column">
                              <md-checkbox ng-model="audit.section_m.m3_na" aria-label="label" ng-disabled="audit.section_m.not_applicable">N/A (no buildings)</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m3_flush_walls" aria-label="label" ng-disabled="audit.section_m.not_applicable">flush against the walls</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m3_inside_entrance" aria-label="label" ng-disabled="audit.section_m.not_applicable">set on the inside of each entrance, both sides (i.e., 2 traps per doorway)</md-checkbox>
                              <md-checkbox ng-model="audit.section_m.m3_baited_rodents" aria-label="label" ng-disabled="audit.section_m.not_applicable">if baited, rodents cannot escape from interior traps</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Are traps effective and appropriate for use? </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_m.not_applicable" ng-model="audit.section_m.m3_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>M4) Pest Control Products are stored properly (separate from product/ packaging materials; in a clean, covered, dry location; with labels intact and legible, etc.)</p>
                          <md-radio-group ng-model="audit.section_m.m4_pest_control_products" layout="row">
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_m.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group> 
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_m.not_applicable" ng-model="audit.section_m.m4_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_m.not_applicable" ng-model="audit.section_m.m4_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Pest Program for Buildings):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_m.m1_score + audit.section_m.m2_score + audit.section_m.m3_score + audit.section_m.m4_score }}</p>
                          <p>24</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- PREST PROGRAMS AND BUILDING -->
                
                <!-- PACKAGING MATERIAL -->
                <section id="SectionN" aria-label="N. Packaging Materials">
                  <table class="SectionN">
                    <thead>
                      <tr>
                        <th>N. Packaging Materials <br>(refer to Section 17 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_n.not_applicable"></md-checkbox>
                          <br>
                          <p>NOTE: This section does not apply to wholesaling operations</p>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>N1) Harvested product packaging materials are used and stored appropriately: </p>
                          <md-checkbox ng-model="audit.section_n.n1_na" aria-label="label" ng-disabled="audit.section_n.not_applicable">N/A</md-checkbox>
                          <p>(Auditee does not have harvested product packaging materials)</p>
                          <md-radio-group ng-model="audit.section_n.n1_auditee" layout="row">
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                        <p>Harvested product packaging materials are:</p>
                         <div layout="column">
                              <md-checkbox ng-model="audit.section_n.n1_clean_free" aria-label="label" ng-disabled="audit.section_n.not_applicable">clean and free of loose objects/debris</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n1_stored_seperate" aria-label="label" ng-disabled="audit.section_n.not_applicable">stored separate from sources of contamination and damage</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n1_clearly_marked" aria-label="label" ng-disabled="audit.section_n.not_applicable">clearly marked if used for other purposes so they are not subsequently used for product</md-checkbox>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_n.not_applicable" ng-model="audit.section_n.n1_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>N2) Market ready packaging materials are inspected and used appropriately:</p>
                          <md-checkbox ng-model="audit.section_n.n2_na" aria-label="label" ng-disabled="audit.section_n.not_applicable">N/A</md-checkbox>
                          <p>(Auditee does not use market ready packaging materials)</p>
                          <md-radio-group ng-model="audit.section_n.n2_auditee" layout="row">
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('I')">I </a><br>
                          <a ng-click="goToRecord('Q')">Q</a>
                          <p>SSOP</p>
                          <p>Letter of assurance</p>
                        </td>
                        <td>
                        <p>Market ready packaging materials are:</p>
                         <div layout="column">
                              <md-checkbox ng-model="audit.section_n.n2_primary_material" aria-label="label" ng-disabled="audit.section_n.not_applicable">primary materials are new, OR reusable materials are cleaned according to a written procedure/cleaned by a third party and a letter of assurance is received, OR a new impermeable liner is used</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n2_reused_without" aria-label="label" ng-disabled="audit.section_n.not_applicable">reused without a liner for pumpkins, squash, sweet corn and smooth-skinned melons</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n2_clearly_marked" aria-label="label" ng-disabled="audit.section_n.not_applicable">clearly marked if used for other purposes so they are not subsequently used for product</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n2_clean_free" aria-label="label" ng-disabled="audit.section_n.not_applicable">clean and free of debris</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n2_packing_accessories" aria-label="label" ng-disabled="audit.section_n.not_applicable">packaging accessories (including liners) are new</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n2_reused_materials" aria-label="label" ng-disabled="audit.section_n.not_applicable">reused materials are in good repair</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n2_complete_accurate" aria-label="label" ng-disabled="audit.section_n.not_applicable">complete and accurate records are kept of inspection of market ready primary packaging materials</md-checkbox>
                          </div>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_n.not_applicable" ng-model="audit.section_n.n2_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>N3) Market ready packaging materials are labelled correctly?</p>
                          <md-radio-group ng-model="audit.section_n.n3_market_ready" layout="row">
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_n.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"</td>
                        <td>
                        <p>Market ready packaging materials are:</p>
                         <i>Market ready packaging materials are labelled with correct identifying information AND Pack ID. Transparent secondary packaging does not need to be labelled if you can see the primary packaging material. <b>This question is scored as 4 if fully compliant or 0 if anything is missing.</b></i>
                         <br><br>
                         <i>Pack ID must be on secondary packaging. For product with no secondary packaging, Pack ID must be on primary packaging. If no primary or secondary packaging, Pack ID must be on the pallet/skid.</i>
                         <br><br>
                         <i>If someone else (another operation) is labelling the market product then pallet/bin tags or some other form of identification is required to keep track of the market product.</i>
                         <br><br>
                         <i><b>NOTE: Refer to Section 22: Identification and Traceability for more information on labelling requirements</b></i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_n.not_applicable" ng-model="audit.section_n.n3_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>N4) Market ready primary and secondary packaging materials and packaging accessories are stored: </p>
                          <div layout="column">
                              <md-checkbox ng-model="audit.section_n.n4_na" aria-label="label" ng-disabled="audit.section_n.not_applicable">(Auditee does not use market ready packaging materials)</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n4_clean_covered" aria-label="label" ng-disabled="audit.section_n.not_applicable">in a clean, covered, dry location</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n4_ground" aria-label="label" ng-disabled="audit.section_n.not_applicable">off the ground</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n4_least_wall" aria-label="label" ng-disabled="audit.section_n.not_applicable">at least 8 cm away from the wall</md-checkbox>
                              <md-checkbox ng-model="audit.section_n.n4_seperate_sources" aria-label="label" ng-disabled="audit.section_n.not_applicable">separate from sources of contamination and damage</md-checkbox>
                          </div>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_n.not_applicable" ng-model="audit.section_n.n4_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_n.not_applicable" ng-model="audit.section_n.n4_score" type="number" min="0" max="6" required>
                              <div class="hint">6</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Packaging Materials):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_n.n1_score + audit.section_n.n2_score + audit.section_n.n3_score + audit.section_n.n4_score }}</p>
                          <p>22</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- PACKAGING MATERIAL -->

                <!-- GROWING AND HARVESTING -->
                <section id="SectionO" aria-label="O. Growing and Harvesting">
                  <table class="SectionO">
                    <thead>
                      <tr>
                        <th>O. Growing and Harvesting <br>(refer to Section 18 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_o.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>O1) Agricultural chemical PHI’s are checked before harvest and this is recorded?  </p>
                          <md-radio-group ng-model="audit.section_o.o1_agricultural_chemical" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('P1')">P1</a> / 
                          <a ng-click="goToRecord('P2')">P2</a>
                          <br>
                          <a ng-click="goToRecord('Q')">Q</a>
                        </td>
                        <td>
                          <p>Look at Form H1 to see when agricultural chemicals were applied and the PHI. Cross check this with Forms P1/P2/Q to ensure that the PHI had elapsed before harvest began. A checkmark (or some sort of identifier) must be recorded to show that PHI was checked before harvest. The scoring for this question is all or nothing. Each PHI needs to have elapsed before harvest and this needs to be recorded somehow. Since completion of Form H1 was already checked in Section E; do not deduct more points for that here. </p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o1_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>O2) Before harvest the production site is surveyed for sources of contamination?</p>
                          <md-radio-group ng-model="audit.section_o.o2_before_harvest" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('P1')">P1</a> / 
                          <a ng-click="goToRecord('P2')">P2</a>
                          <br>
                          <a ng-click="goToRecord('Q')">Q</a>
                        </td>
                        <td>
                          <p>Sources of contamination include oil or chemical spills, portable toilets leaking, flooding, animal intrusion, toxic weeds/trap crops, etc. Check that the survey of the production site is recorded on the appropriate forms.</p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o2_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>O3) When harvesting, packaging materials are not a source of contamination? </p>
                          <md-radio-group ng-model="audit.section_o.o3_harvesting_packaging" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <p>FOR Combined Vegetable, Leafy Vegetables and Cruciferae, Small Fruit and Tree and Vine Fruit ONLY - looking for muddy containers NOT to be stacked on top of each other, etc.</p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o3_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>O4) A visual inspection of  product is conducted before and during harvest for any sources of contamination?</p>
                          <md-radio-group ng-model="audit.section_o.o4_visual_inspection" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <p>FOR Combined vegetables, Leafy Vegetables and Cruciferae, Small Fruit and Tree and Vine Fruit ONLY - looking for evidence of unusual animal or bird activity (i.e., excrement) and other possible contaminants (e.g., biological controls, etc.).</p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o4_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>O5) Product that has fallen/touched the ground is not harvested?</p>
                          <md-radio-group ng-model="audit.section_o.o5_fallen_touched_ground" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <p>FOR Small Fruit (except for cranberries) and Tree and Vine Fruit ONLY</p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o5_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p><b>GREENHOUSE PRODUCT</b></p>
                          <p>O6) At harvest employees visually inspect product and surrounding area for glass, and complete, accurate records are kept?  </p>
                          <md-radio-group ng-model="audit.section_o.o6_harvest_inspect" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="inc"> INC</md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('Q')">Q</a><br><a ng-click="goToRecord('R')">R</a>
                        </td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o6_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o6_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p><b>GREENHOUSE PRODUCT</b></p>
                          <p>O7) During harvest the product is protected from contamination [e.g., water dripping when harvesting or transferring product (e.g., trays, rafts, roots)].</p>
                          <md-radio-group ng-model="audit.section_o.o7_harvest_inspect" layout="row">
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_o.not_applicable" value="inc"> INC</md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o7_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_o.not_applicable" ng-model="audit.section_o.o7_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Growing and Harvesting):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_o.o1_score + audit.section_o.o2_score + audit.section_o.o3_score + audit.section_o.o4_score + audit.section_o.o5_score + audit.section_o.o6_score + audit.section_o.o7_score }}</p>
                          <p>26</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- GROWING AND HARVESTING -->

                <!-- SORTING GRADING -->
                <section id="SectionP" aria-label="P. Sorting, Grading, Packing, Repacking, Storing and Brokerage">
                  <table class="SectionP">
                    <thead>
                      <tr>
                        <th>P. Sorting, Grading, Packing, Repacking, Storing and Brokerage <br>(refer to Section 19 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_p.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>P1) When selecting/purchasing harvested/market product from another source, product is from CanadaGAP-certified operations or from operations that have successfully completed another industry recognized third party food safety audit/certification? </p>
                          <md-radio-group ng-model="audit.section_p.p1_selecting_purchasing" layout="row">
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                            Current/ Valid Certificate
                        </td>
                        <td>
                          <p><b>If ANY certificate is missing the most the operation can score is 5/10</b>
                              <br>This includes the transaction(s) for brokerage operations.</p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_p.not_applicable" ng-model="audit.section_p.p1_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>P2) Sorting and/or grading is done to remove foreign objects, damaged or rotten product, crop debris?  </p>
                          <md-radio-group ng-model="audit.section_p.p2_sorting_grading" layout="row">
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_p.not_applicable" ng-model="audit.section_p.p2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_p.not_applicable" ng-model="audit.section_p.p2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>P3) Wax is used with knowledge of origin, applied according to label instructions, and complete, accurate application records are kept?  </p>
                          <md-radio-group ng-model="audit.section_p.p3_wax_origin_applied" layout="row">
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_p.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                            <a ng-click="goToRecord('Q')">Q</a> <br>
                            <p>Letter  of No-Objection or of Assurance</p>
                        </td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_p.not_applicable" ng-model="audit.section_p.p3_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_p.not_applicable" ng-model="audit.section_p.p3_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Sorting, Grading, Packing, Repacking, Storing and Brokerage):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_p.p1_score + audit.section_p.p2_score + audit.section_p.p3_score }}</p>
                          <p>14</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- SORGING GRADING -->

                <!-- STORAGE OF PRODUCT -->
                <section id="SectionQ" aria-label="P. Sorting, Grading, Packing, Repacking, Storing and Brokerage">
                  <table class="SectionQ">
                    <thead>
                      <tr>
                        <th>Q. Storage of Product <br>(refer to Section 20 in CanadaGAP Manual)   </th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_q.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>Q1) All product is stored in a manner that prevents contamination of product?</p>
                          <md-radio-group ng-model="audit.section_q.q1_product_stored" layout="row">
                              <md-radio-button ng-disabled="audit.section_q.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_q.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_q.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_q.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <p>Is harvested product stored separate from market product? Is all product (including seed potatoes) stored separate from fuels, chemicals, market ready packaging materials, etc? Is product in an environment where contamination can not occur (clean/well-maintained area)?Is product stored in a manner that prevents cross-contamination from non-produce items?</p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_q.not_applicable" ng-model="audit.section_q.q1_score" type="number" min="0" max="8" required>
                              <div class="hint">8</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Storage of Product):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_q.q1_score }}</p>
                          <p>8</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- STORAGE OF PRODUCT -->

                <!-- TRANSPORTATION -->
                <section id="SectionR" aria-label="R. Transportation">
                  <table class="SectionR">
                    <thead>
                      <tr>
                        <th>R. Transportation <br>(refer to Section 21 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_q.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>R1) Product is loaded into clean, inspected trucks? </p>
                          <md-radio-group ng-model="audit.section_r.r1_product_loaded" layout="row">
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                          <br><br>
                          <p>Market product is covered during transportation?</p>
                          <md-radio-group ng-model="audit.section_r.r1_market_product" layout="row">
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td class="greyed"></td>
                        <td>
                          <i>Transportation does not contribute to the contamination of product? If unable to observe trucks, score is 0 out of 0.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_r.not_applicable" ng-model="audit.section_r.r1_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>R2) Records are kept of vehicle inspection and product information for product being transported to someone else’s premises?</p>
                          <md-radio-group ng-model="audit.section_r.r2_records_vehicle_inspection" layout="row">
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_r.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td><a ng-click="goToRecord('O')">O</a></td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_r.not_applicable" ng-model="audit.section_r.r2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_r.not_applicable" ng-model="audit.section_r.r2_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Transportation):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_r.r1_score + audit.section_r.r2_score }}</p>
                          <p>8</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- TRANSPORTATION -->

                <!-- IDENTIFICATION -->
                <section id="SectionS" aria-label="S. Identification and Traceability">
                  <table class="SectionS">
                    <thead>
                      <tr>
                        <th>S. Identification and Traceability <br>(refer to Section 22 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <p>S1) Traceability can be established through the records?</p>
                          <md-radio-group ng-model="audit.section_s.s1_traceability_records" layout="row">
                              <md-radio-button ng-disabled="audit.section_s.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_s.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_s.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('P1')">P1</a> / <a ng-click="goToRecord('P2')">P2</a><br>
                          <a ng-click="goToRecord('Q')">Q</a>
                          <p>Written Confirmation</p>
                        </td>
                        <td>
                          <i>Can product be traced one step up and one step down? Use Forms H1/H2/O to ensure that a link can be made to Forms P1/P2 and Q (e.g., the same information should be followed through). Ensure Forms P1/P2 and Q are complete. From all of the records the product and what happened to it (e.g., agronomic inputs, harvesting, packing, repacking, storing, etc) should be traceable. Completion of  Forms H1/H2/O was already checked in previous sections of the audit; do not deduct more points here. Incoming/outgoing packaging material must be properly labelled and incoming/outgoing product information must be recorded.</i>
                          <br><br>
                          <i>If someone else (another operation) is labelling market product look for written confirmation from the operation completing the labelling that market product is labelled immediately upon receipt and in accordance with labelling requirements for market product in Section N.</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_s.not_applicable" ng-model="audit.section_s.s1_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Identification and Traceability):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_s.s1_score }}</p>
                          <p>10</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- IDENTIFICATION -->

                <!-- DEVIATION -->
                <section id="SectionT" aria-label="T. Deviations and Crisis Management">
                  <table class="SectionT">
                    <thead>
                      <tr>
                        <th>T. Deviations and Crisis Management <br>(refer to Section 23 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <p>T1) Records are kept of major deviations and complaints?  </p>
                          <md-radio-group ng-model="audit.section_t.t1_records_deviations" layout="row">
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('R')">R</a>
                        </td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_t.not_applicable" ng-model="audit.section_t.t1_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_t.not_applicable" ng-model="audit.section_t.t1_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>T2) Food defense risks are addressed and a system is in place to reduce or eliminate the identified risks?</p>
                          <md-radio-group ng-model="audit.section_t.t2_food_defense" layout="row">
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('R')">T</a>
                        </td>
                        <td>
                          <i>Potential threats to food security must be identified and assessed in all areas of the operation. Form T must be completed. </i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_t.not_applicable" ng-model="audit.section_t.t2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>T3) An allergen program is in place to ensure that cross contamination does not occur?</p>
                          <md-radio-group ng-model="audit.section_t.t3_allergen_program" layout="row">
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                          <br>
                          <p>If undeclared allergens are handled, equipment is cleaned before use on market product, and if necessary, precautionary labeling is used.</p>
                          <md-radio-group ng-model="audit.section_t.t3_undeclared_allergens" layout="row">
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <a ng-click="goToRecord('S')">S</a>
                        </td>
                        <td>
                          <i>Form S must be completed. Sulphites are not used on market product (EXCEPT table grapes)</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_t.not_applicable" ng-model="audit.section_t.t3_score" type="number" min="0" max="4" required>
                              <div class="hint">4</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>T4) An up to date recall program is in place and a mock recall is performed annually?</p>
                          <md-radio-group ng-model="audit.section_t.t4_recall_program" layout="row">
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="no"> N </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_t.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <p>Contact lists <br>Mock Recall Documentation</p>
                        </td>
                        <td>
                          <i>Appendix R: How to Conduct a Mock Recall - An Example, contact lists for suppliers, customers, recall team, Appendix S: Recall Program or other relevant documents</i>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_t.not_applicable" ng-model="audit.section_t.t4_score" type="number" min="0" max="10" required>
                              <div class="hint">10</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (Deviations and Crisis Management):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_t.t1_score + audit.section_t.t2_score + audit.section_t.t3_score + audit.section_t.t4_score }}</p>
                          <p>18</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- DEVIATION -->

                <!-- REPACKING -->
                <section id="SectionU" aria-label="U. Site-specific HACCP Plan">
                  <table class="SectionU">
                    <thead>
                      <tr>
                          <th colspan="4">FOR REPACKING AND WHOLESALING OPERATIONS ONLY</th>
                      </tr>
                      <tr>
                        <th>U. Site-specific HACCP Plan <br>(refer to Section 24.1 in CanadaGAP Manual)</th>
                        <th>Records</th>
                        <th><i>(Auditor's Key)</i><br>Comments/Observations</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="4" style="text-align: left;">
                          If entire section is not applicable to the operation check box and go to next section: 
                          <md-checkbox ng-model="audit.section_u.not_applicable"></md-checkbox>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>U1) A site-specific HACCP plan has been documented and implemented.</p>
                          <md-radio-group ng-model="audit.section_u.u1_site_specific_haccp" layout="row">
                              <md-radio-button ng-disabled="audit.section_u.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_u.not_applicable" value="no"> N </md-radio-button>
                               <md-radio-button ng-disabled="audit.section_u.not_applicable" value="na"> N/A </md-radio-button>
                              <md-radio-button ng-disabled="audit.section_u.not_applicable" value="inc"> INC </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <p>HACCP Plan</p>
                        </td>
                        <td>
                          <p>The site-specific HACCP Plan is complete. All Forms have been filled in properly. All hazards have been assessed and carried through the Forms appropriately. <br> Assign the 20 marks according to how complete and correct the HACCP Plan is (e.g., 25% of the marks if 25% of the hazards have been addressed, etc.). <br>Auditor should collect a copy of the operation's Form 1 for their records. </p>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_u.not_applicable" ng-model="audit.section_u.u1_score" type="number" min="0" max="20" required>
                              <div class="hint">20</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <p>U2) The site-specific HACCP plan is reviewed and updated annually </p>
                          <md-radio-group ng-model="audit.section_u.u2_site_specific_haccp_reviewed" layout="row">
                              <md-radio-button ng-disabled="audit.section_u.not_applicable" value="yes" class="md-primary">Y</md-radio-button>
                              <md-radio-button ng-disabled="audit.section_u.not_applicable" value="no"> N </md-radio-button>
                               <md-radio-button ng-disabled="audit.section_u.not_applicable" value="na"> N/A </md-radio-button>
                          </md-radio-group>
                        </td>
                        <td>
                          <p>HACCP Plan</p>
                        </td>
                        <td>
                          <md-input-container class="md-block">
                              <label>Comments/Observation</label>
                              <textarea ng-disabled="audit.section_u.not_applicable" ng-model="audit.section_u.u2_observation" md-maxlength="500" rows="5" md-select-on-focus></textarea>
                          </md-input-container>
                        </td>
                        <td style="vertical-align: bottom;">
                          <md-input-container>
                              <input ng-disabled="audit.section_u.not_applicable" ng-model="audit.section_u.u2_score" type="number" min="0" max="2" required>
                              <div class="hint">2</div>
                            </md-input-container>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" style="text-align: right;">
                          <p>Auditee's Actual Score for Section (HACCP Plan):</p>
                          <p>Maximum Attainable Score for Section:</p>
                        </td>
                        <td>
                          <p>@{{ audit.section_u.u1_score + audit.section_u.u2_score }}</p>
                          <p>22</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
                <!-- REPACKING -->

                <!-- COMMENTS -->
                <md-input-container class="md-block">
                    <label>Additional Comments</label>
                    <textarea ng-model="audit.additional_comments" md-maxlength="800" rows="5" md-select-on-focus></textarea>
                </md-input-container>
                <!-- COMMENTS -->

                <md-button class="md-raised md-primary" style="padding: 0 20px;" ng-click="saveAuditForm()" ng-disabled="AuditForm.$invalid">Save Audit</md-button>
            </md-content>
        </form>
		</div>
	</div>
    @endforeach
@stop
