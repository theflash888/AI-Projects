@extends('dashboard.home')

@section('dashboard-content')
	<div class="row animated AuditHome fadeIn {{ Request::is('dashboard/form/R') ? 'FullWidth' : null }} PlaceholderFix HBarFOE">
		<div class="large-12 columns" style="padding: 15px;">
			<div class="FormsBorder">
				<md-content class="md-padding">
					<h3>Audit</h3>
					<ul>
						<li>
							<a href="{{ url('dashboard/audits/new') }}">New Audit</a>
							<a href="{{ url('dashboard/audits/') }}">Self-Declaration and Self-Assessment Checklist</a>
						</li>
					</ul>
				</md-content>
			</div>
		</div>
	</div>
@stop
