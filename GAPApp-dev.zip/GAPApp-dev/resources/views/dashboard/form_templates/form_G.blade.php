@foreach(Auth::user()->organizations as $org)
<md-content ng-controller="FormGController" class="md-padding FormG">
	<form name="FormGForm">
			<p><b>Instructions:</b> An inspection of both the interior and exterior of your buildings (e.g., packinghouse, storages) (except agricultural chemical storage buildings) must be conducted monthly [when in use and where possible (e.g., not a sealed storage)] and the following checklist completed. Place N/A if certain structures are not applicable to your operation.</p>
			<br>
			<div layout="row">
				<md-input-container class="md-block" flex-gt-xs>
				<label>Storage ID # / Name:</label>
				<md-select ng-model="form_g.storage_id" required >
					<md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
								@{{ entity.name }}
					</md-option>
		</md-select>
		</md-input-container>
		<md-input-container class="md-block" flex-gt-xs>
		<label>Select Building Type</label>
		<md-select ng-model="form_g.building_type" required >
			<md-option ng-repeat="btype in buildingTypes" value="@{{ btype.id }}">
						@{{ btype.name }}
			</md-option>
</md-select>
</md-input-container>
	</div>
			<div class="row FullWidth">

					<div class="large-6 columns" ng-show="form_g.building_type == '1' || form_g.building_type == '3'">
							<p style="text-align: center;"><b>Interior of Building <br> (Permanent Structures)</b>
							</p>
							<md-input-container>
									<md-radio-group ng-model="form_g.no_holes" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
											<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
											<md-radio-button  value="no" > No </md-radio-button>
											<md-radio-button  value="na" > N/A </md-radio-button>
									</md-radio-group>
									<p>No holes/crevices/leaks in the building (e.g., walls,  windows, screens)</p>

							</md-input-container>
							<md-input-container>
									<md-radio-group ng-model="form_g.shatterproof" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
											<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
											<md-radio-button  value="no" > No </md-radio-button>
											<md-radio-button  value="na" > N/A </md-radio-button>
									</md-radio-group>
									<p>Lighting is shatterproof and adequate (e.g., packinghouse is bright while potatoe storages are dark)</p>
							</md-input-container>

							<md-input-container>
									<md-radio-group ng-model="form_g.no_pipes" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
											<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
											<md-radio-button  value="no" > No </md-radio-button>
											<md-radio-button  value="na" > N/A </md-radio-button>
									</md-radio-group>
									<p>No pipes or condensation leaking</p>
							</md-input-container>


							<md-input-container>
									<md-radio-group ng-model="form_g.floor_drainage" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
											<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
											<md-radio-button  value="no" > No </md-radio-button>
											<md-radio-button  value="na" > N/A </md-radio-button>
									</md-radio-group>
									<p>Floor drainage is good (floor sloped, drain covers clear)</p>
							</md-input-container>

							<md-input-container>
									<md-radio-group ng-model="form_g.floors_clean" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
											<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
											<md-radio-button  value="no" > No </md-radio-button>
											<md-radio-button  value="na" > N/A </md-radio-button>
									</md-radio-group>
									<p>Floors, walls and ceilings are clean and free from garbage, spills, rodent droppings, etc.</p>
							</md-input-container>

							<md-radio-group ng-model="form_g.floor_free_pests" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Floor is free of crevices that could harbour pests or debris</p>
							<br>
							<md-radio-group ng-model="form_g.fans_air_free" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Fans and/or air filters are dust-free, clean and working properly</p>
							<br>

							<md-radio-group ng-model="form_g.animals" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Animals (wild or domestic), pests (insects, rodents, etc.) and bird nests are not present</p>
							<br>
							<md-radio-group ng-model="form_g.material_designated" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>All materials are in designated areas (e.g., packaging materials and product)</p>

							<br>

							<md-radio-group ng-model="form_g.adequate_ventilation" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Adequate ventilation</p>
							<br>
							<md-radio-group ng-model="form_g.control_measures" layout="row"  ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Control measures are in place to prevent cross-contamination from other activities/items (e.g., employee movement, dedicated areas/equipment, etc.)</p>
					</div>
					<div class="large-6 columns"  ng-show="form_g.building_type == '2' || form_g.building_type == '3'">
							<p style="text-align: center;"><b>Exterior of Building <br> (Permanent Structures)</b>
							</p>
							<br>
							<md-radio-group ng-model="form_g.no_exterior_holes" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>
									No holes/crevices/leaks in the building (e.g., walls, windows, screens)
							</p>
							<br>
							<md-radio-group ng-model="form_g.exterior_windows_closed" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>All windows can be closed OR have close-fitting screens are in good condition
							</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_half_perimeter" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>½ meter wide perimeter strip of stone or crushed gravel OR short grass around building</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_no_junk" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>
									No junk piled within 3 m of building (e.g., old or unused machinery, garbage)
							</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_weeds" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Weeds are controlled
							</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_land_drainage" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Land drainage around building is good</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_dumpster" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Dumpsters are emptied as needed to prevent pest infestation, and surroundings are free of debris </p>
							<br>

							<md-radio-group ng-model="form_g.exterior_doors_close_fitting" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>All doors are close-fitting </p>
							<br>

							<md-radio-group ng-model="form_g.exterior_doors_secured" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>Doors that can be secured (i.e., to lock storages when unsupervised)</p>
							<br>

							<p style="text-align: center;"><b>Exterior of Building <br> (Non-Permanent Structures)</b>
							</p>
							<br>
							<md-radio-group ng-model="form_g.exterior_roof_cover" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>
								Roof or Cover (i.e., tarp)
							</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_land_drainage_structure" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>
								Land drainage around structure is good
							</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_no_areas_pests" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>
								No areas where pests can live/feed/hide within 3 m of structure (e.g., old or unused machinery, garbage)
							</p>
							<br>

							<md-radio-group ng-model="form_g.exterior_weeds_controlled" layout="row"  ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
									<md-radio-button  value="yes"  class="md-primary">Yes</md-radio-button>
									<md-radio-button  value="no" > No </md-radio-button>
									<md-radio-button  value="na" > N/A </md-radio-button>
							</md-radio-group>
							<p>
								Weeds are controlled
							</p>
							<br>
					</div>
			</div>
			<hr>
			<br>
			<div class="row FullWidth">
					<div class="large-6 columns" ng-show="form_g.building_type == '1' || form_g.building_type == '3'">
						<p style="text-align: center;"><b>Maintenance Required</b>
						</p>
						<p>
							If any of the above has NOT been checked off (√), please describe the maintenance required.
						</p>
						<md-input-container class="md-block" flex-gt-xs  ng-show="form_g.no_holes == 'no' || form_g.shatterproof == 'no' || form_g.no_pipes == 'no' || form_g.floor_drainage == 'no' || form_g.floors_clean == 'no' || form_g.floor_free_pests == 'no' || form_g.fans_air_free == 'no' || form_g.animals == 'no' || form_g.material_designated == 'no' || form_g.adequate_ventilation == 'no' || form_g.control_measures == 'no'">
	            <label>Maintenance Required</label>
	            <textarea  name="storage_secured_action" ng-model="form_g.interior_maintenance" cols="30" rows="5"></textarea>
	          </md-input-container>
						<br>

						<p>
							Date and Name of person work was completed by:
						</p>
						<div layout="row">
							<md-datepicker  style="margin:15px 0;" ng-model="form_g.interior_maintenance_completed_date" md-placeholder="Enter date"></md-datepicker>
				 <md-input-container class="md-block" flex-gt-xs>
					 <label>Completed by</label>
					 <input ng-model="form_g.interior_maintenance_completed_by" name="method"   ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
				 </md-input-container>
						</div>
						<br>

						<p>
							Date and signature of person overseeing the work:
						</p>
						<div layout="row">
							<md-datepicker  style="margin:15px 0;" ng-model="form_g.interior_maintenance_overseen_date" md-placeholder="Enter date"></md-datepicker>
						<md-input-container class="md-block" flex-gt-xs>
	            <label>Overseen by</label>
	            <input ng-model="form_g.interior_maintenance_overseen_by" name="method"   ng-required="form_g.building_type == '1' || form_g.building_type == '3'">
	          </md-input-container>
					</div>
						<br>

					</div>
					<div class="large-6 columns" ng-show="form_g.building_type == '2' || form_g.building_type == '3'">
						<p style="text-align: center;"><b>Maintenance Required</b>
						</p>
						<p>
							If any of the above has NOT been checked off (√), please describe the maintenance required.
						</p>
						<md-input-container class="md-block" flex-gt-xs ng-show="form_g.no_exterior_holes == 'no' || form_g.exterior_windows_closed == 'no' || form_g.exterior_half_perimeter == 'no' || form_g.exterior_no_junk == 'no' || form_g.exterior_weeds == 'no' || form_g.exterior_land_drainage == 'no' || form_g.exterior_dumpster == 'no' || form_g.exterior_doors_close_fitting == 'no' || form_g.exterior_doors_secured == 'no' || form_g.exterior_roof_cover == 'no' || form_g.exterior_land_drainage_structure == 'no' || form_g.exterior_no_areas_pests == 'no' || form_g.exterior_weeds_controlled == 'no'">
	            <label>Maintenance Required</label>
	            <textarea  name="storage_secured_action" ng-model="form_g.exterior_maintenance" cols="30" rows="5" ></textarea>
	          </md-input-container>
						<br>

						<p>
							Date and Name of person work was completed by:
						</p>
						<div layout="row">
							<md-datepicker  style="margin:15px 0;" ng-model="form_g.exterior_maintenance_completed_date" md-placeholder="Enter date"></md-datepicker>
						<md-input-container class="md-block" flex-gt-xs>
	            <label>Completed by</label>
	            <input ng-model="form_g.exterior_maintenance_completed_by" name="method"   ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
	          </md-input-container>
					</div>
						<br>

						<p>
							Date and signature of person overseeing the work:
						</p>
						<div layout="row">
							<md-datepicker  style="margin:15px 0;" ng-model="form_g.exterior_maintenance_overseen_date" md-placeholder="Enter date"></md-datepicker>
						<md-input-container class="md-block" flex-gt-xs>
	            <label>Overseen by</label>
	            <input ng-model="form_g.exterior_maintenance_overseen_by" name="method"   ng-required="form_g.building_type == '2' || form_g.building_type == '3'">
	          </md-input-container>
					</div>
						<br>

					</div>
			</div>
			<hr>
			<table style="padding: 0; margin: 0;">
					<tr>
							<td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
									Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
							</td>
							<td style="text-align: right; padding: 0; border: 0;">
									<p style="padding: 0; margin: 0; line-height: 1.5em;">
										CanadaGAP Food Safety Manual for
									</p>
									<p style="padding: 0; margin: 0; line-height: 1.5em;">
										Fresh Fruits and Vegetables
									</p>
									<p style="padding: 0; margin: 0; line-height: 1.5em;">
											{{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
									</p>
							</td>
					</tr>
			</table>
			<br>

			<div class="row FullWidth">
					<div class="large-12 columns">

							<br>
							<md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormGForm.$invalid" style="padding: 0 20px;">Save Record</md-button>
							<!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreviewMode()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->

							<br>
							<p style="text-align: center;">Confirmation/Update Log:</p>
							<table>
									<thead>
											<tr>
													<th>Date</th>
													<th>Signature</th>
													<th>Details</th>
											</tr>
									</thead>
									<tbody>
											@foreach($org->forms_g as $g)
											<tr>
													<td>{{ $g->date }}</td>
													<td>{{ $g->author->first }} {{ $g->author->last }}</td>
													<td>
															<md-button ng-click="showFormGDetails('{{ $g->id }}')" class="md-primary">Details</md-button>
															<md-button ng-click="confirmFormGRecord({{$org->id}}, {{$g->author->id}}, {{$g->id}})" class="md-primary">Confirm and Submit</md-button>
													</td>
											</tr>
											@endforeach
									</tbody>
							</table>
					</div>
			</div>
	</form>
</md-content>
@endforeach
