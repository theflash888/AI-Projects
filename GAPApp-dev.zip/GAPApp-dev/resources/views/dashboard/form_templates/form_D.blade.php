@foreach(Auth::user()->organizations as $org)
<md-content class="FormD md-padding" ng-controller="FormDController">
    <form name="FormDForm">
        <p><b>Instructions:</b> This Form is intended to assist you in setting your policy, to itemize the policy components and to be used as a training tool and possible handout to employees. All items need to be addressed during the training session for employees. Write N/A beside those not applicable to your operation.</p>
        <br>
        <div class="row FullWidth">

            <div class="large-6 columns">
                <p style="text-align: center;"><b>Employee Illness, Disease and Injury</b>
                </p>
                <md-input-container>
                    <md-radio-group ng-model="form_d.person_transmit" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Persons able to transmit or suffering from a contagious disease and/or illness transferable to food (e.g., Hepatitis A, Salmonella, E. coli O157:H7) and those with a temporary illness (e.g., bad cold, diarrhea and vomiting) are advised to see a doctor</p>

                </md-input-container>
                <md-input-container>
                    <md-radio-group ng-model="form_d.employees_trained" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Employees are trained on the role and responsibility they play in preventing the contamination of product</p>
                </md-input-container>

                <md-input-container>
                    <md-radio-group ng-model="form_d.wounds_treated" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Open wounds are treated and covered with a waterproof covering (e.g., rubber gloves)</p>
                </md-input-container>
                <br>
                <hr>
                <br>
                <p style="text-align: center;"><b>Employee Cleanliness, Footwear and Hair</b>
                </p>
                <md-input-container>
                    <md-radio-group ng-model="form_d.personal_cleanliness" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>A degree of personal cleanliness is maintained which includes starting each day wearing clean clothing and <i>(specify other): </i>
                        <md-input-container class="FormDIC" style="margin: 12px auto;">
                            <label>Specify Other</label>
                            <input ng-model="form_d.personal_cleanliness_other" style="color: #000000 !important;" ng-disabled="form_d.personal_cleanliness == 'no' || form_d.personal_cleanliness == 'na'">
                        </md-input-container>
                    </p>

                </md-input-container>
                <md-input-container>
                    <md-radio-group ng-model="form_d.clean_footwear" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Clean footwear is always worn (no dirt or other foreign matter)</p>
                </md-input-container>
                <br>
                <md-input-container>
                    <md-radio-group ng-model="form_d.long_hair_touching" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Long hair touching the shoulders is restrained  (e.g., hat, hairnet, tied)</p>
                </md-input-container>
                <hr>
                <br>
                <p style="text-align: center;"><b>Production Practices</b>
                </p>
                <md-input-container>
                    <md-radio-group ng-model="form_d.employee_authorized" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Employees adhere to the following:</i>
                        <br>
                        <ul  style="padding-left: 40px; !important;">
                            <li>Only authorized employees handle market product</li>
                            <li>Only authorized employees may enter controlled-access areas</li>
                        </ul>
                    </p>

                </md-input-container>
                <hr>
                <br>
                <p style="text-align: center;"><b>Employee Jewellery and Other Personal Effects</b>
                </p>
                <md-input-container>
                    <md-radio-group ng-model="form_d.jewellery_worn" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Bracelets, necklaces or other jewellery (except for rings) are not worn
                    </p>

                </md-input-container>
                <br>
                <md-input-container>
                    <md-radio-group ng-model="form_d.ring_gloves" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Rings are covered with gloves
                    </p>

                </md-input-container>
                <br>
                <md-input-container>
                    <md-radio-group ng-model="form_d.false_fingernails" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>False fingernails, false eyelashes or other such effects are not worn
                    </p>

                </md-input-container>
                <br>
                <md-input-container>
                    <md-radio-group ng-model="form_d.items_removed_pocket" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Items are removed from shirt pockets (e.g., pens, etc.)
                    </p>

                </md-input-container>
                <br>
                <md-input-container>
                    <md-radio-group ng-model="form_d.loose_buttons_fixed" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Loose buttons on shirts/jackets are fixed
                    </p>

                </md-input-container>
                <hr>
                <br>
                <p style="text-align: center;"><b>Employee Glove and Apron Use</b>
                </p>
                <md-radio-group ng-model="form_d.gloves_used" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Gloves are used</p>
                <br>
                <md-radio-group ng-model="form_d.aprons_used" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Aprons are used</p>
                <br>

                <p>If gloves and aprons are not used, proceed to the next sub-section</p>
                <br>
                <md-radio-group ng-model="form_d.gloves_rubber" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Gloves are made of rubber, nitrile, polyethylene, polyvinyl chloride, polyurethane or cloth (canvas/leather gloves may be used for potatoes and bulb and root vegetables ONLY)</p>
                <br>
                <md-radio-group ng-model="form_d.hands_washed" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Hands are washed and dried, before gloves are put on and after they are removed</p>

                <br>

                <md-radio-group ng-model="form_d.aprons_rubber" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Aprons are made of rubber</p>
                <br>
                <md-radio-group ng-model="form_d.employee_aprons" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Employees wear aprons when they hold product against their upper body (e.g., to trim product)</p>
                <br>
                <md-radio-group ng-model="form_d.gloves_aprons" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Gloves and aprons are replaced when ripped or worn out</p>

                <br>
                <md-radio-group ng-model="form_d.reusable_aprons" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Reusable aprons are washed daily</p>
                <br>
                <md-radio-group ng-model="form_d.gloves_removed" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Gloves are removed when leaving the work area and replaced upon return  or, if reusable, gloves are washed (using proper hand washing technique) after being put back on and when changing tasks that could potentially contaminate the product.</p>

                <br>
            </div>
            <div class="large-6 columns">
                <p style="text-align: center;"><b>Employee Hand Washing</b>
                </p>
                <md-radio-group ng-model="form_d.hands_washed_dried" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>
                    Hands are washed and dried:
                    <br>
                    <ul style="padding-left: 40px; !important;">
                        <li>Before beginning work each day</li>
                        <li>Before entering the production site</li>
                        <li>Before putting on gloves (if used)</li>
                        <li>After every visit to the washroom</li>
                        <li>After a break or meal</li>
                        <li>After smoking</li>
                        <li>After hand-to-face contact (e.g., coughing, sneezing, blowing nose)</li>
                        <li>After applying sunscreen and insect repellent</li>
                        <li>After handling any materials other than the product (e.g., fuelling equipment, spraying)</li>
                    </ul>
                </p>
                <br>
                <md-radio-group ng-model="form_d.hands_reusable_gloves" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Hands and reusable gloves (except for cloth) are washed using proper hand washing techniques:
                    <br>
                    <ul style="padding-left: 40px; !important;">
                        <li>Wet hands, lather soap for approximately 20 seconds</li>
                        <li>Scrub well (especially fingernails and knuckles)
                            <br> Use fingernail brushes if needed/required</li>
                        <li>Rinse</li>
                        <li> Dry hands and wrists with paper towel</li>
                    </ul>
                </p>
                <br>

                <md-radio-group ng-model="form_d.no_water" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>If no water is available, hand wipes and hand sanitizer are used</p>
                <br>

                <md-radio-group ng-model="form_d.wipe_hand_sanitizer" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>
                    Hand wipe and hand sanitizer use:
                    <ul style="padding-left: 40px; !important;">
                        <li>Use hand wipes to facilitate soil/organic matter/ juice etc. removal AND</li>
                        <li>Use one squirt of waterless, antibacterial, alcohol-based product</li>
                    </ul>
                </p>
                <br>

                <md-radio-group ng-model="form_d.gloves_substitute" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Gloves are not worn as a substitute for hand washing</p>
                <br>
                <!--<hr>
                <br>
                <p style="text-align: center;"><b>Production Practices</b>
                </p>
                <md-radio-group ng-model="form_d.trained_harvest" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Employees are trained to harvest into clean containers</p>
                <br>

                <md-radio-group ng-model="form_d.trained_visually" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Employees are trained to visually inspect product during harvest to look for evidence of unusual animal or bird activity (i.e., excrement) and discards product if it has been contaminated</p>
                <br>

                <md-radio-group ng-model="form_d.trained_touched" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Employees are trained not to harvest product that has touched the ground (FOR TREE AND VINE FRUIT ONLY)</p>
                <br>

                <md-radio-group ng-model="form_d.trained_fallen" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Employees are trained not to harvest product that has fallen on the ground (FOR SMALL FRUIT ONLY)</p>
                <br>-->
                <hr>
                <br>
                <p style="text-align: center;"><b>Employee Biosecurity</b>
                </p>

                <md-input-container>
                    <md-radio-group ng-model="form_d.employees_aware" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Employees are aware of their surroundings and the people they come in contact with, in and around the production site</p>
                </md-input-container>

                <md-input-container>
                    <md-radio-group ng-model="form_d.person_responsible" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Employees inform person responsible (name of person responsible
                        <md-input-container class="FormDIC"  style="margin: 12px auto;">
                            <label>Person Responsible</label>
                            <input ng-model="form_d.person_responsible_name" style="color: #000000 !important;" ng-disabled="form_d.person_responsible == 'no' || form_d.person_responsible == 'na'">
                        </md-input-container>
                        ) of unknown visitors</p>
                </md-input-container>

                <md-input-container>
                    <md-radio-group ng-model="form_d.trained_precautions" layout="row" required>
                        <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                        <md-radio-button value="no" > No </md-radio-button>
                        <md-radio-button value="na" > N/A </md-radio-button>
                    </md-radio-group>
                    <p>Employees are trained in precautions they need to take when moving between production areas (e.g., from livestock areas/field to storage/packinghouse)</p>
                </md-input-container>
                <br>
                <hr>
                <br>
                <p style="text-align: center;"><b>Other</b>
                </p>
                <md-radio-group ng-model="form_d.major_minor" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>Employees know the difference between and how to handle major and minor food safety deviations</p>
                <br>

                <md-radio-group ng-model="form_d.employee_adhere" layout="row" required>
                    <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
                    <md-radio-button value="no" > No </md-radio-button>
                    <md-radio-button value="na" > N/A </md-radio-button>
                </md-radio-group>
                <p>
                    Employees adhere to the following:
                    <br>
                    <ul style="padding-left: 40px; !important;">
                        <li>Always use toilet facilities</li>
                        <li> Always dispose of toilet paper in toilet (i.e., not in garbage can)</li>
                        <li>Never spit</li>
                        <li>Eat food, drinks, gum, candy or use tobacco products (including chewing tobacco and snuff) only in areas designated for this purpose (e.g., outside, in lunchroom)</li>
                        <li>Put personal effects in designated areas (e.g., lunches, clothing, shoes, smoking</li>
                        <li>Dispose of waste in designated containers</li>
                    </ul>
                </p>
                <br>
            </div>
        </div>

        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>
        <div class="row FullWidth">
            <div class="large-12 columns">

                <md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormDForm.$invalid" style="padding: 0 20px;">Save Record</md-button>
                <!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreview()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->

                <br>
                <p style="text-align: center;">Confirmation/Update Log:</p>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Signature</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach(\App\Models\FormD::where('organization_id', $org->id)->where('is_completed', false)->get() as $d)
                        <tr>
                            <td>{{ $d->created_at }}</td>
                            <td>{{ $d->author->first }} {{ $d->author->last }}</td>
                            <td>
                                <div layout="row">
                                    <md-button ng-click="showFormDDetails('{{ $d->id }}')" class="md-primary">Details</md-button>
                                    <md-button ng-click="confirmFormDRecord({{$org->id}}, {{$d->author->id}}, {{$d->id}})" class="md-primary">Confirm and Submit</md-button>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </form>
</md-content>
@endforeach
