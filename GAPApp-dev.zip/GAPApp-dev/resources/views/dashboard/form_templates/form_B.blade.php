@foreach(Auth::user()->organizations as $org)
<md-content class="FormB" ng-controller="FormBController">
    <p>
        <b>Instructions:</b> This Form must be completed prior to using storages for the first time in a season (use one Form per storage for harvested and market product). If an item is not applicable, indicate N/A. Make additional copies as necessary and complete as Page _ of _ to indicate more than one page if required.
    </p>
    <form name="FormBForm">
        <div layout-gt-xs="row">
            <!--<md-input-container class="md-block" flex-gt-xs>
                <label>Storage ID # / Name:</label>
                <input ng-model="form_b.storage_id" required>
            </md-input-container>-->
            <md-input-container class="md-block" flex-gt-xs>
            <label>Storage ID # / Name:</label>
            <md-select ng-model="form_b.storage_id" required >
              <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                    @{{ entity.name }}
              </md-option>
        </md-select>
        </md-input-container>
        </div>
        <div layout-gt-xs="column">
            <table>
                <thead>
                    <tr>
                        <th>Requirement</th>
                        <th>Yes/No or N/A</th>
                        <th>Action Taken if Answered "No"</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            Storage is secured (e.g., with a lock) when unsupervised?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.storage_secured" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="storage_secured_action" ng-model="form_b.storage_secured_action" cols="30" rows="10" ng-disabled="form_b.storage_secured == 'yes' || form_b.storage_secured == 'na'" disabled></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Lights in the storage area are shatterproof or covered?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.lights_shatterproof" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="lights_shatterproof_action" ng-model="form_b.lights_shatterproof_action" cols="30" rows="10" ng-disabled="form_b.lights_shatterproof == 'yes' || form_b.lights_shatterproof == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Product in storage is kept in proper conditions (e.g., on pallets)?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.proper_condition" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="proper_condition_action" ng-model="form_b.proper_condition_action" cols="30" rows="10" ng-disabled="form_b.proper_condition == 'yes' || form_b.proper_condition == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Product is stored away from leaky areas (e.g., from roofs, pipes, condensation)?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.leaky_area" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="leaky_area_action" ng-model="form_b.leaky_area_action" cols="30" rows="10" ng-disabled="form_b.leaky_area == 'yes' || form_b.leaky_area == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            When the storage is in use, production site equipment and fertilizers are stored and repaired elsewhere? Agricultural chemicals are never stored in product storages?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.production_equipment" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="production_equipment_action" ng-model="form_b.production_equipment_action" cols="30" rows="10" ng-disabled="form_b.production_equipment == 'yes' || form_b.production_equipment == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Treated seed is stored according to the label directions (i.e., stored away from product)?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.treated_seed" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="treated_seed_action" ng-model="form_b.treated_seed_action" cols="30" rows="10" ng-disabled="form_b.treated_seed == 'yes' || form_b.treated_seed == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Oil/gas furnace is exhausting outside the storage?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.furnace_exhausting" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="furnace_exhausting_action" ng-model="form_b.furnace_exhausting_action" cols="30" rows="10" ng-disabled="form_b.furnace_exhausting == 'yes' || form_b.furnace_exhausting == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            When the storage is in use, oil/fuel storage tanks are stored elsewhere or contained to prevent contamination of product?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.storage_in_use" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="storage_in_use_action" ng-model="form_b.storage_in_use_action" cols="30" rows="10" ng-disabled="form_b.storage_in_use == 'yes' || form_b.storage_in_use == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Floor of the storage is clean and free from contaminants (e.g., oil, wood, plastic, glass, metal, garbage, chemicals)?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.floor_clean" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="floor_clean_action" ng-model="form_b.floor_clean_action" cols="30" rows="10" ng-disabled="form_b.floor_clean == 'yes' || form_b.floor_clean == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Walls/ceilings of storage are clean and in good condition (e.g., free from contamination from oil, wood, plastic, glass, metal, garbage, chemicals)?

                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.ceiling_storage" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="ceiling_storage_action" ng-required="form_b.ceiling_storage == 'no'" ng-model="form_b.ceiling_storage_action" cols="30" rows="10" ng-disabled="form_b.ceiling_storage == 'yes' || form_b.ceiling_storage == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            The storage is a no-smoking zone?

                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.no_smoking" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="no_smoking_action" ng-model="form_b.no_smoking_action" cols="30" rows="10" ng-disabled="form_b.no_smoking == 'yes' || form_b.no_smoking == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Storage is free from animals (wild or domestic) or evidence of animals (droppings) and other pests (birds, insects, rodents)?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.free_animals" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="free_animals_action" ng-model="form_b.free_animals_action" cols="30" rows="10" ng-disabled="form_b.free_animals == 'yes' || form_b.free_animals == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            FOR POTATOES ONLY:
                            <br> Potatoes in storage are kept in the dark?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.potatoes_dark" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="potatoes_dark_action" ng-model="form_b.potatoes_dark_action" cols="30" rows="10" ng-disabled="form_b.potatoes_dark == 'yes' || form_b.potatoes_dark == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            FOR POTATOES ONLY:
                            <br> Potatoes are free from direct contact with pressure treated wood?
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.potatoes_treated" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action"  name="potatoes_treated_action" ng-model="form_b.potatoes_treated_action" cols="30" rows="10" ng-disabled="form_b.potatoes_treated == 'yes' || form_b.potatoes_treated == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Other (<i>specify</i>):
                        </td>
                        <td>
                            <md-radio-group ng-model="form_b.other" layout="row" >
                                <md-radio-button value="yes"  class="md-primary">Yes</md-radio-button>
                                <md-radio-button value="no" > No </md-radio-button>
                                <md-radio-button value="na" > N/A </md-radio-button>
                            </md-radio-group>
                        </td>
                        <td>
                            <md-input-container class="md-block" flex-gt-xs>
                                <textarea placeholder="Action" name="other_action" ng-required="form_b.other == 'no'" ng-model="form_b.other_action" cols="30" rows="10" ng-disabled="form_b.other == 'yes' || form_b.other == 'na'" disabled="true"></textarea>
                            </md-input-container>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div layout="column">
                <md-input-container class="md-block">
                    <label>How and when was the storage cleaned? (describe):</label>
                    <textarea ng-model="form_b.storage_cleaning_desc" columns="1" md-maxlength="500" rows="5" ></textarea>
                </md-input-container>
            </div>
        </div>
        <md-button class="md-raised md-primary" ng-disabled="FormBForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
    </form>
    <hr>
    <table>
        <tr>
            <td style="vertical-align: top;">
                Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
            </td>
            <td style="text-align: right;">
                <p>
                  CanadaGAP Food Safety Manual for
                </p>
                <p>
                  Fresh Fruits and Vegetables
                </p>
                <p>
                    {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                </p>
            </td>
        </tr>
    </table>
    <br>
    <p style="text-align: center;">Confirmation/Update Log:</p>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Signature</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach(\App\Models\FormB::where('organization_id', $org->id)->where('is_completed', false)->get() as $b)
                    <tr>
                        <td>{{ $b->date }}</td>
                        <td>
                            {{ $b->author->first }} {{ $b->author->last }}
                        </td>
                        <td>
                            <div layout="row">
                                <md-button ng-click="showFormBDetails({{$org->id}}, {{$b->author->id}}, {{$b->id}})" class="md-primary">Details</md-button>
                                <md-button ng-click="confirmFormBRecord({{$org->id}}, {{$b->author->id}}, {{$b->id}})" class="md-primary">Confirm and Submit</md-button></td>
                            </div>
                    </tr>
                    @endforeach
                </tbody>
            </table>
</md-content>

@endforeach
