@foreach(Auth::user()->organizations as $org)
    <md-content class="md-padding FormR">
        <p>
          <b>Instructions:</b> List all major deviations, complaints and their related cause(s), corrective action(s), preventative measures and modified procedures. Record that employees have been trained on the new procedures.
        </p>
        <br>
        <table>
            <thead>
                <tr>
                    <th width="10%">
                        Date/Time of Deviation or Complaint and Person Notified
                    </th>
                    <th width="20%">
                        Major Deviation/Complaint and Description
                    </th>
                    <th width="10%">
                        Cause of Deviation/Complaint
                    </th>
                    <th width="20%">
                        Corrective Action(s)
                    </th>
                    <!--<th width="10%">
                        Prevention of Recurrence (e.g., training employee)
                    </th>
                    <th width="10%">
                        New/Modified Procedures
                    </th>
                    <th width="5%">
                        Employees Trained on New/Modified  Procedures? (√)
                    </th>-->
                    <th width="10%">
                        Signature of Person Responsible for Re-Training/Carrying out Deviation Procedure
                    </th>
                    <th width="10%">

                    </th>
                </tr>
            </thead>
            <tbody>
              @foreach($org->forms_r as $r)
                <tr>
                    <td>
                      {{ $r->created_at }}
                    </td>
                    <td>
                      {{ $r->major_deviation }}
                    </td>
                    <td>
                      {{ $r->cause_of_deviation }}
                    </td>
                    <td>
                      {{ $r->corrective_action }}
                    </td>
                    <!--<td>
                      {{ $r->prevention_of_recurrence }}
                    </td>
                    <td>
                      {{ $r->modified_procedure }}
                    </td>
                    <td>
                      {{ $r->employee_trained }}
                    </td>-->
                    <td>
                      {{ $r->author->first }} {{ $r->author->last }}
                    </td>
                    <td>
                        <md-button class="IncidentDetails" ng-href="{{ url('/dashboard/form/R/' . $r->id) }}">Details</md-button>
                    </td>
                </tr>
              @endforeach
            </tbody>
        </table>
        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>

    </md-content>
@endforeach
