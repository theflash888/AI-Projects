@foreach(Auth::user()->organizations as $org)
<md-content class="FormE md-padding" ng-controller="FormEController">
    <form name="FormEForm">
        <p><b>Instructions:</b> For each type of pest being controlled, specify the pest control method used. This Form is to be completed annually. Make additional copies as necessary and complete as Page _ of _ to indicate more than one page if required.</p>
        <br>
        <div layout-gt-xs="row">
            <md-input-container class="md-block" flex-gt-xs>
                <label>Storage ID # / Name:</label>
                <md-select ng-model="form_e.storage_id" required >
                    <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                        @{{ entity.name }}
                    </md-option>
                </md-select>
            </md-input-container>
        </div>
        <table>
            <thead>
                <tr>
                    <th width="10%">Pest</th>
                    <th width="90%">Control Method and Description</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Birds</td>
                    <td class="md-padding">
                        <p style="text-align: left;"><b>Around building exterior</b></p>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.birds.exterior_devices">Deterrent or other devices (<i>specify</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.birds.exterior_devices_info" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <md-divider></md-divider>
                        <p style="text-align: left;"><b>Inside building</b></p>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.birds.inside_devices">Deterrent or other devices (<i>specify</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.birds.inside_devices_info" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Rodents</td>
                    <td class="md-padding">
                        <p style="text-align: left;"><b>Around building exterior (perimeter)</b></p>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.rodents.exterior_bait">Bait (<i>specify type</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.rodents.exterior_bait_type" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.rodents.exterior_traps">Traps (<i>specify type</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.rodents.exterior_traps_type" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
							<div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.rodents.chemicals">Chemicals (<i>specify below</i>) </md-checkbox>
                            </div>
                            <br>
                            <div class="md-block" style="width: 70%; padding-left: 20px;">
                            	<table>
                            		<thead>
                            			<tr>
                            				<td width="50%">Name of chemical</td>
                            				<td width="30%">PCP #</td>
                            				<td width="20%">Concentration</td>
                            			</tr>
                            		</thead>
                            		<tbody>
                            			<tr ng-repeat="chemical in form_e.rodents.chemicals_list track by $index">
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>Name</label>
				                                    <input ng-model="chemical.name" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>PCP #</label>
				                                    <input ng-model="chemical.pcp" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>Concentration</label>
				                                    <input ng-model="chemical.concentration" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            			</tr>
                            			<md-button class="md-primary md-raised" style="padding: 0 20px;" ng-click="addRodentChemicalRow($event)">Add Chemical</md-button>
                            		</tbody>
                            	</table>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.rodents.exterior_other">Other (<i>specify</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.rodents.exterior_other_info" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>

                        <md-divider></md-divider>
                        <p style="text-align: left;"><b>Inside building</b></p>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.rodents.inside_traps">Traps (<i>specify type</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.rodents.inside_traps_type" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.rodents.inside_other">Other (<i>specify</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.rodents.inside_other_info" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Insects</td>
                    <td class="md-padding">
                        <p style="text-align: left;"><b>Around building exterior</b></p>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.exterior_bait">Bait (<i>specify type</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.insects.exterior_bait_type" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.exterior_traps">Traps (e.g., glue boards, sticky traps)</md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.insects.exterior_traps_type" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
							<div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.exterior_chemicals">Chemicals (<i>specify below</i>) </md-checkbox>
                            </div>
                            <br>
                            <div class="md-block" style="width: 70%; padding-left: 20px;">
                            	<table>
                            		<thead>
                            			<tr>
                            				<td width="50%">Name of chemical</td>
                            				<td width="30%">PCP #</td>
                            				<td width="20%">Concentration</td>
                            			</tr>
                            		</thead>
                            		<tbody>
                            			<tr ng-repeat="chemical in form_e.insects.exterior_chemicals_list track by $index">
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>Name</label>
				                                    <input ng-model="chemical.name" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>PCP #</label>
				                                    <input ng-model="chemical.pcp" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>Concentration</label>
				                                    <input ng-model="chemical.concentration" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            			</tr>
                            			<md-button class="md-primary md-raised" style="padding: 0 20px;" ng-click="addInsectsExteriorChemicalRow($event)" >Add Chemical</md-button>
                            		</tbody>
                            	</table>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.exterior_other">Other (<i>specify</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.insects.exterior_other_info" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>

                        <md-divider></md-divider>
                        <p style="text-align: left;"><b>Inside building</b></p>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.inside_traps">Traps (<i>specify type</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.insects.inside_traps_type" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
							<div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.inside_chemicals">Chemicals (<i>specify below</i>) </md-checkbox>
                            </div>
                            <br>
                            <div class="md-block" style="width: 70%; padding-left: 20px;">
                            	<table>
                            		<thead>
                            			<tr>
                            				<td width="50%">Name of chemical</td>
                            				<td width="30%">PCP #</td>
                            				<td width="20%">Concentration</td>
                            			</tr>
                            		</thead>
                            		<tbody>
                            			<tr ng-repeat="chemical in form_e.insects.inside_chemicals_list track by $index">
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>Name</label>
				                                    <input ng-model="chemical.name" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>PCP #</label>
				                                    <input ng-model="chemical.pcp" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            				<td>
                            					<md-input-container flex-gt-sm style="width: 100%; margin-top: 27px; margin-bottom: 0;">
				                                    <label>Concentration</label>
				                                    <input ng-model="chemical.concentration" name="" style="width: 100% !important;">
				                                </md-input-container>
                            				</td>
                            			</tr>
                            			<md-button class="md-primary md-raised" style="padding: 0 20px;" ng-click="addInsectsInsideChemicalRow($event)" >Add Chemical</md-button>
                            		</tr>
                            		</tbody>
                            	</table>
                            </div>
                        </div>
                        <div layout-gt-sm="row">
                            <div>
                                <md-checkbox  style="margin: 20px 0;" ng-model="form_e.insects.inside_other">Other (<i>specify</i>) </md-checkbox>
                            </div>
                            <div style="width: 60%; padding-left: 20px;">
                                <md-input-container flex-gt-sm style="width: 100%">
                                    <label>Specify</label>
                                    <input ng-model="form_e.insects.inside_other_info" name="" style="width: 100% !important;">
                                </md-input-container>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                	<td>Other (specify)</td>
                	<td>
                		<md-input-container class="md-block">
				          <label>Specify</label>
				          <textarea ng-model="form_e.other.information" md-maxlength="150" rows="5" md-select-on-focus ></textarea>
				        </md-input-container>
                	</td>
                </tr>
            </tbody>
        </table>
        <br>
        <md-button class="md-raised md-primary" ng-disabled="FormEForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
	</form>
  <hr>
  <table style="padding: 0; margin: 0;">
      <tr>
          <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
              Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
          </td>
          <td style="text-align: right; padding: 0; border: 0;">
              <p style="padding: 0; margin: 0; line-height: 1.5em;">
                CanadaGAP Food Safety Manual for
              </p>
              <p style="padding: 0; margin: 0; line-height: 1.5em;">
                Fresh Fruits and Vegetables
              </p>
              <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
              </p>
          </td>
      </tr>
  </table>
  <br>
	                      <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Signature</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach(\App\Models\FormE::where('organization_id', $org->id)->where('is_completed', false)->get() as $e)
                        <tr>
                            <td>{{ $e->created_at }}</td>
                            <td>{{ $e->author->first }} {{ $e->author->last }}</td>
                            <td>
                                <div layout="row">
                                    <md-button ng-click="showFormEDetails('{{ $e->id }}')" class="md-primary">Details</md-button>
                                    <md-button ng-click="confirmFormERecord({{$org->id}}, {{$e->author->id}}, {{$e->id}})" class="md-primary">Confirm and Submit</md-button>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>


</md-content>
@endforeach
