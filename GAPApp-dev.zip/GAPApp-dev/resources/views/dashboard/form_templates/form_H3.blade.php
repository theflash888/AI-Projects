@foreach(Auth::user()->organizations as $org)
<md-content class="FormC" ng-controller="FormH3Controller">
    <form name="FormH3Form">
      {{ csrf_field() }}
        <p><b>Instructions:</b> Includes all applications during packing.</b></p>
        <br>
		<div layout="row">
			<md-input-container class="md-block" flex-gt-xs>
				<label>Operation Name</label>
				<input ng-model="form_h3.operation_name" name="operation_name"  required>
			</md-input-container>
			<md-input-container class="md-block" flex-gt-xs>
	            <label>Production Site Information</label>
	            <md-select ng-model="form_h3.production_site" required ng-disabled="isInPreviewMode">
		              <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
		                    @{{ entity.name }}
		              </md-option>
		        </md-select>
	        </md-input-container>
	        <md-input-container class="md-block" flex-gt-xs>
				<label>Variety</label>
				<input ng-model="form_h3.variety" name="variety"  required>
			</md-input-container>
		</div>
		<div layout="row">
			<md-input-container class="md-block" flex-gt-xs>
				<label>Product/Trade Name</label>
				<input ng-model="form_h3.product_name" name="product_name"  required>
			</md-input-container>
			<md-input-container class="md-block" flex-gt-xs>
				<label>PCP #</label>
				<input ng-model="form_h3.pcp" name="pcp"  required>
			</md-input-container>
		</div>
		<div layout="row">
			<md-input-container class="md-block" flex-gt-xs>
				<label>Rate Applied Per Unit (cwt/tonne)</label>
				<input ng-model="form_h3.rate_applied" name="rate_applied"  required>
			</md-input-container>
			<md-input-container class="md-block" flex-gt-xs>
				<label>Quantity Treated</label>
				<input ng-model="form_h3.quantity_treated" name="quantity_treated"  required>
			</md-input-container>
		</div>
		<div layout="row">
			<md-input-container class="md-block" flex-gt-xs>
				<label>Lot ID</label>
				<input ng-model="form_h3.lot_id" name="lot_id"  required>
			</md-input-container>
			<md-input-container class="md-block" flex-gt-xs>
				<label>DAA</label>
				<input ng-model="form_h3.daa" name="daa"  required>
			</md-input-container>
		</div>
		<md-button class="md-raised md-primary" ng-disabled="FormH3Form.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
	</form>
  <hr>
  <table style="padding: 0; margin: 0;">
      <tr>
          <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
              Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
          </td>
          <td style="text-align: right; padding: 0; border: 0;">
              <p style="padding: 0; margin: 0; line-height: 1.5em;">
                CanadaGAP Food Safety Manual for
              </p>
              <p style="padding: 0; margin: 0; line-height: 1.5em;">
                Fresh Fruits and Vegetables
              </p>
              <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
              </p>
          </td>
      </tr>
  </table>
  <br>
	<table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Operation Name</th>
                        <th>Signature</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_h3 as $h3)
					<tr>
						<td>{{ $h3->created_at }}</td>
						<td>{{ $h3->operation_name }}</td>
						<td>{{ $h3->author->first }} {{ $h3->author->last }}</td>
						<td><md-button ng-click="showFormH3Details({{$org->id}}, {{$h3->author->id}}, {{$h3->id}})" class="md-primary">Details</md-button></td>
						<md-button ng-click="confirmFormH3Record({{$org->id}}, {{$h3->author->id}}, {{$h3->id}})" class="md-primary">Confirm and Submit</md-button>
					</tr>
                    @endforeach
                </tbody>
            </table>
</md-content>
@endforeach
