@foreach(Auth::user()->organizations as $org)
<div class="FormL" ng-controller="FormLController">
    <md-content>
        <p><b>Instructions:</b> All visitors must sign in prior to entering controlled-access areas (within buildings).</p>
        <br>
        <h3 style="text-align: center;">VISITOR POLICY</h3>
        <br>
        <p><b>All visitors must:</b></p>
        <p class="visitors_rule">Remain in the area they are given permission to be in (e.g., contractor remains in work area only)</p>
        <p class="visitors_rule">Wash hands before entering controlled-access areas</p>
        <p class="visitors_rule">Not handle product or materials unless given permission</p>
        <p class="visitors_rule">Wear appropriate protective and/or food safety-related clothing <br> This includes: </p>
        <p class="visitors_rule">Shoes must be cleaned, changed or covered prior to entering if they are visibly dirty or soiled</p>
        <p class="visitors_rule">Other <i>(specify)</i></p>
        <p class="visitors_rule">Sign in below to indicate they are informed of and understand the visitor policy</p>
        <br>
        <form name="FormLForm">
        <div class="row">
                    <div class="large-12 columns">
                            <md-input-container class="md-block" flex-gt-sm>
                            <label>Visitor's Name</label>
                            <input ng-model="form_l.visitor" name="visitor" required>
                            <div ng-messages="NewFormLRecord.visitor.$error">
                                <div ng-message="required">
                                    Please enter visitor's name!
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block" flex-gt-sm>
                        <label>Company Name, Purpose of Visit</label>
                        <input ng-model="form_l.company_purpose" name="company_purpose" required>
                        <div ng-messages="NewFormLRecord.company_purpose.$error">
                            <div ng-message="required">
                                Please enter Company Name, Purpose of Visit!
                            </div>
                        </div>
                    </md-input-container>
                    <md-input-container class="md-block" flex-gt-xs>
                    <label>Location on Premises</label>
                    <md-select multiple ng-model="form_l.location" required >
                      <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                            @{{ entity.name }}
                      </md-option>
                </md-select>
                </md-input-container>
        <md-button class="md-raised md-primary" ng-disabled="FormLForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
                    </div>
                </div>
                </form>
                <br>
        <div layout="row">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Visitor's Name</th>
                        <th>Company Name, Purpose of Visit</th>
                        <th>Location on Premises</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_L as $l)
                    <tr>
                        <td>{{$l->created_at}}</td>
                        <td>{{$l->visitor}}</td>
                        <td>{{$l->company_purpose}}</td>
                        <td><?php $toEnd = count($l->location); ?>@foreach($l->location as $loc) {{ \App\Models\EntityName::where('id', $loc)->first()->name }}@if (0 === --$toEnd) @else, @endif @endforeach</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>

        <md-content>
</div>
@endforeach
