@foreach(Auth::user()->organizations as $org)
<md-content class="FormC" ng-controller="FormN1Controller">
    <form name="FormN1Form">
      {{ csrf_field() }}
        <p><b>Instructions:</b> If using chlorine to treat water, complete the following chart to control and monitor your chlorine treatment at least daily or more frequently based on your operation’s needs. Refer to Appendix B: Chlorination of Water for Fluming and Cleaning Fresh Fruits and Vegetables and Cleaning Equipment – An Example for an example of chlorinating instructions.</p>
        <br>
        <div layout="row" md-block>
          <md-input-container class="md-block" flex-gt-xs>
              <label>Water Source:</label>
              <md-select ng-model="form_n1.water_source" name="storage_id"  required>
                <md-option ng-repeat="source in waterSources" value="@{{ source.id }}">
                      @{{ source.name }}
                </md-option>
          </md-select>
          </md-input-container>
        </div>
        <md-input-container class="md-block" flex-gt-xs>
            <label>Concentration of Chlorine:</label>
            <input ng-model="form_n1.chlorine_concentration" name="chlorine_concentration"   required>
          </md-input-container>
        <div layout="row" md-block>
          <md-input-container class="md-block" flex-gt-xs>
            <label>Method (e.g., injection):</label>
            <input ng-model="form_n1.method" name="method"   required>
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
            <label>Volume of Water</label>
            <input ng-model="form_n1.volume" name="volume"   required>
          </md-input-container>
        </div>
        <div layout="row" md-block>
          <md-input-container class="md-block" flex-gt-xs>
            <md-checkbox ng-model="form_n1.recirculated_water" aria-label="Checkbox 1" >
              Re-circulated Water
            </md-checkbox>
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
            <label>Contact Time</label>
            <input ng-model="form_n1.contact_time" name="contact_time"   required>
          </md-input-container>
        </div>
        <div class="row FullWidth" style="margin: 20px auto;">
            <div class="large-12 columns">
                <table>
                    <thead>
                        <tr>
                            <th width="22.5%">Pre-treatment Concentration of Chlorine (ppm) or ORP</th>
                            <th width="22.5%">Amount of Chlorine Added</th>
                            <th width="22.5%">Post-treatment Concentration of Chlorine (ppm) or ORP</th>
                            <th width="22.5%">pH of Water</th>
                            <th width="10%">Water Changed</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="padding: 10px 0;">
                              <md-input-container class="md-block" flex-gt-xs>
                                <label>Concentration</label>
                                <input ng-model="form_n1.pre_treatment" name="pre_treatment"   required>
                              </md-input-container>
                            </td>
                            <td style="padding: 10px 0;">
                              <md-input-container class="md-block" flex-gt-xs>
                                <label>Amount</label>
                                <input ng-model="form_n1.chlorine_added" name="chlorine_added"   required>
                              </md-input-container>
                            </td>
                            <td style="padding: 10px 0;">
                              <md-input-container class="md-block" flex-gt-xs>
                                <label>Concentration</label>
                                <input ng-model="form_n1.post_treatment" name="post_treatment"   required>
                              </md-input-container>
                            </td>
                            <td style="padding: 10px 0;">
                              <md-input-container class="md-block" flex-gt-xs>
                                <label>pH</label>
                                <input ng-model="form_n1.water_ph" name="water_ph"   required>
                              </md-input-container>
                            </td>
                            <td>
                              <md-checkbox ng-model="form_n1.water_changed" aria-label="Checkbox 1" ></md-checkbox>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <md-button class="md-raised md-primary" ng-disabled="FormN1Form.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
    </form>
    <hr>
    <table style="padding: 0; margin: 0;">
        <tr>
            <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
            </td>
            <td style="text-align: right; padding: 0; border: 0;">
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  CanadaGAP Food Safety Manual for
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  Fresh Fruits and Vegetables
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                </p>
            </td>
        </tr>
    </table>
    <br>
    <div class="row FullWidth" style="margin: 20px auto;">
        <div class="large-12 columns">
            <table>
                <thead>
                    <tr>
                      <th>Date</th>
                      <th>Author</th>
                      <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_n1 as $n1)
                    <tr>
                        <td>{{ $n1->created_at }}</td>
                        <td>{{ $n1->author->first }} {{ $n1->author->last }}</td>
                        <td><md-button ng-click="showFormN1Details({{$org->id}}, {{$n1->author->id}}, {{$n1->id}})" class="md-primary">Details</md-button>
                                    <md-button ng-click="confirmFormN1Record({{$org->id}}, {{$n1->author->id}}, {{$n1->id}})" class="md-primary">Confirm and Submit</md-button>

                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</md-content>
@endforeach
