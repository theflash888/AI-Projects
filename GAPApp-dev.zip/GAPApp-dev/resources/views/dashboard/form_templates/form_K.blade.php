@foreach(Auth::user()->organizations as $org)
<div class="FormI" ng-controller="FormKController">
    <md-content>
        <p><b>Instructions:</b> Document when the Employee Personal Hygiene and Food Handling Practices Policy (Forms C Employee Personal Hygiene and Food Handling Practices Policy – Production Site and D Employee Personal Hygiene and Food Handling Practices Policy - Packinghouse/Product Storage) and minor and major deviations training session is held for all employees handling product/packaging materials/food contact surfaces.  In cases where employee names and signatures are not recorded, indicate in the final column where further records are available (e.g., payroll records, contractor records) to track training of employees.</p>
        <br>
        <form name="FormKForm">
        <div class="row FullWidth">
                    <div class="large-12 columns">
                        <br>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Number of Employees Trained or Employee Name</label>
                            <input ng-model="form_k.employees" name="employees" required>
                            <div ng-messages="NewFormKRecord.employees.$error">
                                <div ng-message="required">
                                    Please enter number of employees or employee name
                                </div>
                            </div>
                        </md-input-container>
                        <br>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Topic Covered [Form C or D, minor and major deviations, or other (describe)]</label>
                            <input ng-model="form_k.topic" name="topic" required>
                            <div ng-messages="NewFormKRecord.topic.$error">
                                <div ng-message="required">
                                    Please enter topics covered!
                                </div>
                            </div>
                        </md-input-container>
                        <br>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Person Responsible for Training</label>
                            <input ng-model="form_k.responsible" name="responsible" required>
                            <div ng-messages="NewFormKRecord.responsible.$error">
                                <div ng-message="required">
                                    Please enter person responsible!
                                </div>
                            </div>
                        </md-input-container>
                        <br>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Casual Employee (C), Contract Employee (CE), Payroll Record (P) or Employee Signature</label>
                            <input ng-model="form_k.signature" name="signature" required>
                            <div ng-messages="NewFormKRecord.signature.$error">
                                <div ng-message="required">
                                    Please enter Casual Employee (C), Contract Employee (CE), Payroll Record (P) or Employee Signature
                                </div>
                            </div>
                        </md-input-container>
        <md-button class="md-raised md-primary" ng-disabled="FormKForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
                    </div>
                </div>
                </form>
        <br>
        <div layout="row">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Number of Employees Trained or Employee Name</th>
                        <th>Topic Covered [Form C or D, minor and major deviations, or other (describe)]</th>
                        <th>Person Responsible for Training</th>
                        <th>Casual Employee (C), Contract Employee (CE), Payroll Record (P) or Employee Signature</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_k as $k)
                    <tr>
                        <td>{{$k->created_at}}</td>
                        <td>{{$k->employees}}</td>
                        <td>{{$k->topics}}</td>
                        <td>{{$k->responsible}}</td>
                        <td>{{$k->signature}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>

        <md-content>
</div>
@endforeach
