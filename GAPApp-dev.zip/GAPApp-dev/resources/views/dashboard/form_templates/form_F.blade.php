@foreach(Auth::user()->organizations as $org)
<md-content class="FormF md-padding" ng-controller="FormFController">
    <form name="FormFForm" enctype="multipart/form-data">
        <p class="md-padding"><b>Instructions:</b> Complete and/or update annually for all water sources. Check off (<i class="bi_interface-tick"></i>) those items that apply.</p>
        <br>
        <div layout="row" class="md-padding">
            <md-input-container class="md-block" flex-gt-xs>
                <label>Water Source</label>
                <md-select ng-model="form_f.data.water_source"  required>
                    <md-option ng-repeat="source in waterSources" value="@{{ source.id }}">
                        @{{ source.name }}
                    </md-option>
                </md-select>
            </md-input-container>
        </div>
        <div layout="row" class="md-padding">
            <md-input-container class="md-block" flex-gt-xs>
                <md-checkbox ng-model="form_f.data.recycled" aria-label="Checkbox 1" >
                    Re-cycled?
                </md-checkbox>
            </md-input-container>
            <md-input-container class="md-block" flex-gt-xs>
                <md-checkbox ng-model="form_f.data.stored" aria-label="Checkbox 1" >
                    Stored?
                </md-checkbox>
            </md-input-container>
            <md-input-container class="md-block" flex-gt-xs>
                <label>Commodity ***</label>
                <input ng-model="form_f.data.commodity" name="commodity" >
            </md-input-container>
        </div>
        <md-divider></md-divider>
        <div class="row">
            <div class="large-4 columns">
                <p class="md-block" style="margin: 10px auto; text-align: center; font-weight: bold;">Use</p>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.fluming" aria-label="Checkbox 1" >
                        Fluming
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.cooling" aria-label="Checkbox 1" >
                        Hydro-cooling/cooling
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.washing" aria-label="Checkbox 1" >
                        Washing
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.drenching" aria-label="Checkbox 1" >
                        Drenching
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs>
                    <md-checkbox ng-model="form_f.data.final_rinse" aria-label="Checkbox 1" >
                        Final Rinse
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.chemical_application" aria-label="Checkbox 1" >
                        FOR POTATOES ONLY: Chemical application (during packing)
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.wetting" aria-label="Checkbox 1" >
                        Wetting packing accessories
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.humidity" aria-label="Checkbox 1" >
                        Humidity/Misting
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.hand_washing" aria-label="Checkbox 1" >
                        Hand washing
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.equipment_container" aria-label="Checkbox 1" >
                        Cleaning equipment containers/building
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.ice" aria-label="Checkbox 1" >
                        Ice
                    </md-checkbox>
                </md-input-container>
            </div>

            <div class="large-4 columns">


                <p class="md-block" style="margin: 10px auto; text-align: center; font-weight: bold;">Method</p>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.pit" aria-label="Checkbox 1" >
                        Pit
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.spray" aria-label="Checkbox 1" >
                        Spray
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.hose" aria-label="Checkbox 1" >
                        Hose
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.tap" aria-label="Checkbox 1" >
                        Tap
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.dump_tank" aria-label="Checkbox 1" >
                        Dump tank
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.pressure_wash" aria-label="Checkbox 1" >
                        Pressure wash
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.other" aria-label="Checkbox 1" >
                        Other
                    </md-checkbox>
                </md-input-container>
                <br>
                <div class="" ng-show="form_f.data.other">
                    <md-input-container class="md-block" flex-gt-xs>
                        <label>Other</label>
                        <input ng-model="form_f.data.other_method" name="commodity" >
                    </md-input-container>
                </div>
            </div>

            <div class="large-4 columns">
                <p class="md-block" style="margin: 10px auto; text-align: center; font-weight: bold;">Items to Access</p>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.animal_access" aria-label="Checkbox 1"  >
                        Animals access
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.runoff" aria-label="Checkbox 1" >
                        Runoff
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.working_condition" aria-label="Checkbox 1" >
                        Working condition of well/pipes
                    </md-checkbox>
                </md-input-container>
                <md-input-container flex-gt-xs class="md-block">
                    <md-checkbox ng-model="form_f.data.other_possible" aria-label="Checkbox 1" >
                        Other possible hazards accessed
                    </md-checkbox>
                </md-input-container>
            </div>
        </div>
        <div class="" ng-show="form_f.data.other_possible">
            <md-input-container class="md-block" flex-gt-xs>
                <label>Other</label>
                <input ng-model="form_f.data.other_possible_hazard" name="commodity" >
            </md-input-container>
        </div>
        <md-divider></md-divider>
        <p class="md-block" style="margin: 10px auto; text-align: center; font-weight: bold;">Water Tests</p>
        <div layout="columns">
            <div>
                <div layout="row">
                    <p style="margin: 10px 0; margin-left: 20px;">Prior to use test</p>
                    <md-datepicker ng-model="form_f.data.water_prior_test" md-placeholder="Enter date" ></md-datepicker>
                </div>
                <div layout="row">
                    <p style="margin: 10px 0;">When will the water first be used?</p>
                    <md-datepicker ng-model="form_f.data.water_first_used" md-placeholder="Enter date" ></md-datepicker>
                </div>
                <div layout="row">
                    <p style="margin: 10px 0; margin-left: 20px;">2nd water test</p>
                    <md-datepicker ng-model="form_f.data.water_second_test" md-placeholder="Enter date" ></md-datepicker>
                </div>
                <div layout="row" class="md-padding">
                    <md-input-container class="md-block" flex-gt-xs>
                        <label>Corrective Actions:</label>
                        <md-select ng-model="form_f.data.actions"  required>
                            <md-option ng-repeat="action in actionsList" value="@{{ action.id }}">
                                @{{ action.name }}
                            </md-option>
                        </md-select>
                    </md-input-container>
                </div>
            </div>
            <div class="md-padding">
                <md-button style="margin-left: 50%; padding: 0 20px;" class="md-primary md-raised" ng-model="form_f.wtfiles.water_tests_uploads" name="water_tests_uploads" ngf-select="uploadFormFWaterTests($files)" ngf-accept="'.pdf, .doc, .docx, .png, .jpg'" ngf-multiple="true">Upload Water Tests</md-button>
                <br>
                <ul style="list-style: none; margin-left: 30px;" ng-show="!isInPreviewMode">
                    <li ng-repeat="wtfile in water_tests_files_list">File: @{{ wtfile.name }}</li>
                </ul>
                <ul style="list-style: none; margin-left: 30px;" ng-show="isInPreviewMode">
                    <li ng-repeat="wtfile in form_f.wtfiles.wt_uploaded">File: @{{ wtfile.filename }}</li>
                </ul>
            </div>
        </div>
        
        <md-divider></md-divider>
        <p class="md-block" style="margin: 10px auto; text-align: center; font-weight: bold;">Cleaning and Treatment**</p>
        <div layout="row">
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.cleaned" aria-label="Checkbox 1" >
                    Cleaned
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.treated" aria-label="Checkbox 1" >
                    Treated
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.cistern" aria-label="Checkbox 1" >
                    Cistern
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.well" aria-label="Checkbox 1" >
                    Well
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.other_cleaning" aria-label="Checkbox 1" >
                    Other
                </md-checkbox>
            </md-input-container>
        </div>
        <div layout="row">
            <p style="margin: 5px 0;" flex-gt-xs>Using Appendix</p>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.appendix_a" aria-label="Checkbox 1" >
                    A
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.appendix_b" aria-label="Checkbox 1" >
                    B
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <md-checkbox ng-model="form_f.data.appendix_h" aria-label="Checkbox 1" >
                    H
                </md-checkbox>
            </md-input-container>
            <md-input-container flex-gt-xs>
                <label>OR</label>
                <input ng-model="form_f.data.appendix_or" name="or" >
            </md-input-container>
        </div>
        <div layout="row">
        <md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormFForm.$invalid" style="padding: 0 20px;">Save Record</md-button>
        <md-progress-circular class="md-hue-2" ng-show="inUploadProgress" md-mode='indeterminate' md-diameter="50px"></md-progress-circular>
        
        <!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreviewMode()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->
        </div>
    </form>
    <hr>
    <table style="padding: 0; margin: 0;">
        <tr>
            <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
            </td>
            <td style="text-align: right; padding: 0; border: 0;">
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  CanadaGAP Food Safety Manual for
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  Fresh Fruits and Vegetables
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                </p>
            </td>
        </tr>
    </table>
    <br>
    <div class="row FullWidth">
        <div class="large-12 columns">
            <br>
            <p style="text-align: center;">Confirmation/Update Log:</p>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Signature</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach(\App\Models\FormF::where('organization_id', $org->id)->where('is_completed', false)->get() as $f)
                    <tr>
                        <td>{{ $f->created_at }}</td>
                        <td>{{ $f->author->first }} {{ $f->author->last }}</td>
                        <td>
                            <div layout="row">
                                <md-button ng-click="showFormFDetails('{{ $f->id }}')" class="md-primary">Details</md-button>
                                <md-button ng-click="confirmFormFRecord({{$org->id}}, {{$f->author->id}}, {{$f->id}})" class="md-primary">Confirm and Submit</md-button>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</md-content>
@endforeach
