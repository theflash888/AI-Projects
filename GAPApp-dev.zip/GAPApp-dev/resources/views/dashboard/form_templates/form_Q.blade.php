@foreach(Auth::user()->organizations as $org)
	<md-content class="md-padding FormQ" ng-controller="FormQController">
		<p><b><i>Instructions:</i></b> Complete for any of the following activities: <br>
			<ul style="margin: 0 20px;">
				<li>Harvested product being packed into market ready packaging materials (both in the production site and packinghouse, and includes your own and others’ product)</li>
				<li>All packing and repacking activities that involve market product (see glossary definition of “Packing”  and "Repacking");</li>
				<li>Market product being put into storage</li>
				<li>Brokerage of product</li>
			</ul>
		</p>
		<br>
		<form name="FormQForm">
			<div layout="columns">
				<p style="margin: 10px 0;">Date Harvested/ Market Product Received/ Put into Storage</p>
				<md-datepicker ng-model="form_q.date_harvested" md-placeholder="Enter date" ></md-datepicker>
			</div>
			<div layout="columns">
				<md-input-container flex="70" class="md-block" flex-gt-xs>
		            <label>Name of person who Produced/ Packed/ Repacked/ Stored the Product</label>
		           	<input ng-model="form_q.name_produced" required >
		        </md-input-container>
		        <md-input-container flex="30" class="md-block" flex-gt-xs>
		            <label>Product Variety</label>
		           	<input ng-model="form_q.product_variety" required >
		        </md-input-container>
			</div>
			<div layout="columns">
				<md-checkbox ng-model="form_q.phi_eahd" aria-label="Checkbox 1" >
            		*PHI/EAHD  met (Forms H1 and H2 verified)
          		</md-checkbox>
          		<md-checkbox ng-model="form_q.production_site_assesed" aria-label="Checkbox 1" >
            		** Production site was assesed
          		</md-checkbox>
			</div>
			<div layout="columns">
				<div style="margin: 20px 0;" flex="70">
					<span>Date Harvested/ Market Product Received/ Put into Storage</span>
					<md-datepicker ng-model="form_q.harvest_date" md-placeholder="Enter date" ></md-datepicker>
				</div>
				<md-input-container flex="30" class="md-block" flex-gt-xs>
		            <label>Field/Block #/Pallet/Bin Tag</label>
		           	<input ng-model="form_q.field_block_tag" required >
		        </md-input-container>
			</div>
			<div layout="columns">
				<md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Incoming Pack ID and/or Lot ID</label>
		           	<input ng-model="form_q.incoming_pack" required >
		        </md-input-container>
		        <div style="margin: 20px 0;" flex="40">
					<span style="margin: 10px 0;">Packing/ Repacking Date</span>
					<md-datepicker ng-model="form_q.packing_repacking" md-placeholder="Enter date" ></md-datepicker>
				</div>
			</div>
			<div layout="columns">
				<md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Outgoing Pack ID</label>
		           	<input ng-model="form_q.outgoing_pack_id" required >
		        </md-input-container>
		        <md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Wax Lot # (If Wax Applied)</label>
		           	<input ng-model="form_q.wax_lot" required >
		        </md-input-container>
		        <md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Lot ID</label>
		           	<input ng-model="form_q.lot_id" required >
		        </md-input-container>
						<md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Quantity</label>
		           	<input ng-model="form_q.quantity" required >
		        </md-input-container>
			</div>
			<div layout="columns">
				<md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Primary Packaging Material Used</label>
		           	<input ng-model="form_q.primary_package" required >
		        </md-input-container>
		        <md-input-container flex="55" class="md-block" flex-gt-xs>
		            <label>Secondary Packaging Material Used</label>
		           	<input ng-model="form_q.secondary_package" required >
		        </md-input-container>
			</div>
			<div layout="columns">
				<md-checkbox flex="50" ng-model="form_q.packaging_checked" aria-label="Checkbox 1" >
            		Packaging Checked for Cleanliness
          		</md-checkbox>
          		<div style="margin: 20px 0;" flex="50">
					<span style="margin: 10px 0;">Date Market Product Put into Storage</span>
					<md-datepicker ng-model="form_q.market_product_storage" md-placeholder="Enter date" ></md-datepicker>
				</div>
			</div>
			<p><i>* Forms H1 and H2 have been verified to ensure that harvested product meets the required pre-harvest interval PHI/EAHD for agricultural chemical application and the spreading of manure. </i></p>
			<p><i>**The production site was surveyed to ensure that there were no signs of obvious contamination (e.g., oil or chemical spill, portable toilet leaking, flooding, animal intrusion, etc.) before harvest.</i></p>
						<div class="row FullWidth">
					<div class="large-12 columns">

							<br>
							<md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormQForm.$invalid" style="padding: 0 20px;">Save Record</md-button>
							<!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreviewMode()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->

							<hr>
							<table style="padding: 0; margin: 0;">
									<tr>
											<td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
													Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
											</td>
											<td style="text-align: right; padding: 0; border: 0;">
													<p style="padding: 0; margin: 0; line-height: 1.5em;">
														CanadaGAP Food Safety Manual for
													</p>
													<p style="padding: 0; margin: 0; line-height: 1.5em;">
														Fresh Fruits and Vegetables
													</p>
													<p style="padding: 0; margin: 0; line-height: 1.5em;">
															{{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
													</p>
											</td>
									</tr>
							</table>
							<br>
							<p style="text-align: center;">Confirmation/Update Log:</p>
							<table>
									<thead>
											<tr>
													<th>Date</th>
													<th>Signature</th>
													<th>Details</th>
											</tr>
									</thead>
									<tbody>
											@foreach($org->forms_q as $q)
											<tr>
													<td>{{ $q->created_at }}</td>
													<td>{{ $q->author->first }} {{ $q->author->last }}</td>
													<td>
															<md-button ng-click="showFormQDetails('{{ $q->id }}')" class="md-primary">Details</md-button>
															<md-button ng-click="confirmFormQRecord({{$org->id}}, {{$q->author->id}}, {{$q->id}})" class="md-primary">Confirm and Submit</md-button>
													</td>
											</tr>
											@endforeach
									</tbody>
							</table>
					</div>
			</div>


		</form>
	</md-content>
@endforeach
