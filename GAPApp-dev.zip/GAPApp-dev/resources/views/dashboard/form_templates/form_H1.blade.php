@foreach(Auth::user()->organizations as $org)
<md-content ng-controller="FormH1Controller" class="md-padding FormH1">
    <form name="FormH1Form">
      <p><b>Instructions:</b> Includes all applications from pre-planting through to, and including, harvest/storage. One Form must be completed for <b>EACH PRODUCTION SITE</b>.</p>
			<br>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Operation Name</label>
          <input ng-model="form_h1.operation_name" name="operation_name" required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Previous Year Crop(s)</label>
          <input ng-model="form_h1.previous_year_crops" name="previous_year_crops" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Seed certification #:</label>
          <input ng-model="form_h1.seed_certificate" name="seed_certificate" required>
          <div class="hint">FOR POTATOES ONLY</div>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Current Crop</label>
          <input ng-model="form_h1.current_crop" name="current_crop" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
        <label>Product Site Information</label>
        <md-select ng-model="form_h1.product_site_information" required ng-disabled="isInPreviewMode">
          <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                @{{ entity.name }}
          </md-option>
    </md-select>
    </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Production Site Area</label>
          <input ng-model="form_h1.production_site_area" name="production_site_area" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <label style="margin: 25px 0;">Date Planted:</label>
        <md-datepicker style="margin: 15px 0;" ng-model="user.date_planted" md-placeholder="Enter date">
          </md-datepicker>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Variety</label>
          <input ng-model="form_h1.variety" name="variety" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Product/Trade Name</label>
          <input ng-model="form_h1.product_trade_name" name="product_trade_name" required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>PCP #</label>
          <input ng-model="form_h1.pcp" name="pcp" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Actual Quantity Used</label>
          <input ng-model="form_h1.actual_quantity_used" name="actual_quantity_used" required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Rate Applied Per Unit</label>
          <input ng-model="form_h1.rate_applied" name="rate_applied" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
        <md-checkbox ng-model="form_h1.label_followed" aria-label="Checkbox 1">
          Label Instructions Followed
        </md-checkbox>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Area Treated</label>
          <input ng-model="form_h1.area_treated" name="area_treated" required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Method of Application</label>
          <input ng-model="form_h1.method_of_application" name="method_of_application" required>
        </md-input-container>
      </div>
      <div layout="rows">
        <label style="margin: 25px 0;">Earliest Allowable Harvest Date (EAHD)</label>
        <md-datepicker style="margin: 15px 0;" ng-model="form_h1.eahd" md-placeholder="Enter date">
          </md-datepicker>
          <md-input-container class="md-block" flex-gt-xs>
            <label>PHI/DAA</label>
            <input ng-model="form_h1.phi_daa" name="phi_daa" required>
          </md-input-container>
        </div>
        <div layout="rows">
          <md-input-container class="md-block" flex-gt-xs>
            <label>Weather Conditions</label>
            <input ng-model="form_h1.weather_condition" name="weather_condition" required>
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
            <label>Person Responsible</label>
            <input ng-model="form_h1.person_responsible" name="person_responsible" required>
          </md-input-container>
      </div>
      <md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormH1Form.$invalid" style="padding: 0 20px;">Save Record</md-button>
      <!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreviewMode()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->
      <hr>
      <table style="padding: 0; margin: 0;">
          <tr>
              <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                  Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
              </td>
              <td style="text-align: right; padding: 0; border: 0;">
                  <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    CanadaGAP Food Safety Manual for
                  </p>
                  <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    Fresh Fruits and Vegetables
                  </p>
                  <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                  </p>
              </td>
          </tr>
      </table>
      <br>
      <div class="row FullWidth">
					<div class="large-12 columns">
							<br>
							<p style="text-align: center;">Confirmation/Update Log:</p>
							<table>
									<thead>
											<tr>
													<th>Date</th>
													<th>Signature</th>
													<th>Details</th>
											</tr>
									</thead>
									<tbody>
											@foreach($org->forms_h1 as $h1)
											<tr>
													<td>{{ $h1->created_at }}</td>
													<td>{{ $h1->author->first }} {{ $h1->author->last }}</td>
													<td>
															<md-button ng-click="showFormH1Details('{{ $h1->id }}')" class="md-primary">Details</md-button>
                              <md-button ng-click="confirmFormH1Record({{$org->id}}, {{$h1->author->id}}, {{$h1->id}})" class="md-primary">Confirm and Submit</md-button>
													</td>
											</tr>
											@endforeach
									</tbody>
							</table>
					</div>
			</div>
    </form>
</md-content>
@endforeach
