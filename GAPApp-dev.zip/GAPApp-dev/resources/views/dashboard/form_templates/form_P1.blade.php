@foreach(Auth::user()->organizations as $org)
<md-content class="FormP1 md-padding" ng-controller="FormP1Controller">
        <p><b>Instructions:</b> Complete for any harvested potatoes that are:
            <br>
            <ul style="margin: 0 30px;">
                <li>Put into harvested product packaging materials </li>
                <li>Harvested in bulk</li>
                <li>Put into storage</li>
            </ul>
        </p>
        <br>
        <form name="FormP1Form">
            <div layout-gt-xs="row">
                <md-input-container class="md-block" flex-gt-xs>
                    <label>Storage Name/Area/ID/#: </label>
                    <md-select ng-model="form_p1.storage_id" required >
                        <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                            @{{ entity.name }}
                        </md-option>
                    </md-select>
                </md-input-container>
            </div>
            <br>
            <p style="text-align: center;">Agricultural Chemical Application - if being applied</p>
            <br>
			<div class="row FullWidth">
                <div class="large-12 columns">
                    <div layout="row">
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Variety</label>
                            <input ng-model="form_p1.first.variety" >
                        </md-input-container>
                        <p style="margin: 20px 0">Harvest Date</p><md-datepicker style="margin: 10px 0;" ng-model="form_p1.first.harvest_date"  md-placeholder="Harvest Date"></md-datepicker>
                        <p style="margin: 20px 0">Bin Fill Date</p><md-datepicker style="margin: 10px 0;" ng-model="form_p1.first.bin_fill_date"  md-placeholder="Bin Fill Date"></md-datepicker>
                    </div>
                        <md-checkbox ng-model="form_p1.first.phi_eahd_daa" >
                            * PHI/EAHD/DAA met (Form H1/H2/H3 verified)
                        </md-checkbox>
                        <br>
                        <md-checkbox ng-model="form_p1.first.production_site_assessed" >
                            ** Production site was assessed
                        </md-checkbox>
                    <div layout="row">
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Product/Trade Name and PCP #</label>
                            <input ng-model="form_p1.first.product_name" >
                        </md-input-container>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Quantity Treated</label>
                            <input ng-model="form_p1.first.quantity_treated" >
                        </md-input-container>
                    </div>
                    <div layout="row">
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Application Rate</label>
                            <input ng-model="form_p1.first.application_rate" >
                        </md-input-container>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Method of Application (Spray, Ventilation)</label>
                            <input ng-model="form_p1.first.method_of_application" >
                        </md-input-container>
                    </div>
                    <div layout="row">
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Cross section of the bin</label>
                            <textarea ng-model="form_p1.first.cross_section"  md-maxlength="400" rows="5" md-select-on-focus></textarea>
                        </md-input-container>
                    </div>
                            <md-button class="md-raised md-primary" ng-disabled="FormP1Form.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->

                </div>
            </div>
            <br>
            <p>* Forms H1/H2/H3 have been verified to ensure that harvested potatoes meet the required pre-harvest interval PHI/EAHD/DAA for agricultural chemical application and the spreading of manure.</p>
            <p>** The production site was surveyed to ensure that there were no signs of obvious contamination (e.g., oil or chemical spill, portable toilet leaking, flooding, animal intrusion, etc.) before harvest.</p>
        </form>
        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>
                          <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Signature</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($org->forms_p1 as $p1)
                        <tr>
                            <td>{{ $p1->created_at }}</td>
                            <td>{{ $p1->author->first }} {{ $p1->author->last }}</td>
                            <td>
                                <md-button ng-click="showFormP1Details('{{ $p1->id }}')" class="md-primary">Details</md-button>
                                <md-button ng-click="confirmFormP1Record({{$org->id}}, {{$p1->author->id}}, {{$p1->id}})" class="md-primary">Confirm and Submit</md-button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>

</md-content>
@endforeach
