@foreach(Auth::user()->organizations as $org)
<md-content ng-controller="FormP2Controller" class="md-padding FormP2">
<form name="FormP2Form">
    <p>
        <b>Instructions:</b> Complete for any harvested product that is:
        <br>
        <i>- Put into harvested product packaging materials</i>
        <br>
        <i>- Harvested in bulk</i>
        <br>
        <i>- Put into storage</i>
        <br>
    </p>
    <br>
    <md-input-container class="md-block" flex-gt-xs>
        <label>Storage ID # / Name:</label>
        <md-select ng-model="form_p2.storage_id" required >
            <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                @{{ entity.name }}
            </md-option>
        </md-select>
    </md-input-container>
    <br>
    <div layout="columns">
      <md-input-container class="md-block" flex-gt-xs>
        <label>Product and Variety</label>
        <input ng-model="form_p2.product_variety" name="product_variety"   required>
      </md-input-container>
      <md-input-container class="md-block" flex-gt-xs>
      <md-checkbox ng-model="form_p2.phi_eahd_daa"  aria-label="Checkbox 1">
        *PHI/EAHD/DAA met  (Forms H1 and H2 verified)
      </md-checkbox>
      </md-input-container>
      <md-input-container class="md-block" flex-gt-xs>
      <md-checkbox ng-model="form_p2.production_assessed"  aria-label="Checkbox 1">
          ** Production site was assessed
      </md-checkbox>
      </md-input-container>
    </div>
    <div layout="columns">
      <md-input-container class="md-block" flex-gt-xs>
        <label>Quantity/Units Harvested</label>
        <input ng-model="form_p2.quantity" name="product_variety"   required>
      </md-input-container>
      <md-input-container class="md-block" flex-gt-xs>
        <label>Field/Block #/Pallet/Bin Tag (Same as Forms H1 and H2)</label>
        <input ng-model="form_p2.field_block" name="product_variety"   required>
      </md-input-container>
      <md-input-container class="md-block" flex-gt-xs>
        <label>Packaging Materials Used</label>
        <input ng-model="form_p2.packaging_material" name="product_variety"   required>
      </md-input-container>
    </div>
    <div layout="columns">
      <p style="margin-top: 10px;">Harvest Date</p>
      <md-datepicker ng-model="form_p2.harvest_date" md-placeholder="Enter date"  required></md-datepicker>
    </div>
    <p><i>
      * Forms H1 and H2 have been verified to ensure that harvested product meets the required pre-harvest interval PHI/EAHD/DAA for agricultural chemical application and the spreading of manure.<br>
      ** The production site was surveyed to ensure that there were no signs of obvious contamination (e.g., oil or chemical spill, portable toilet leaking, flooding, animal intrusion, etc.) before harvest.
    </i></p>
    <br>
    <md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormP2Form.$invalid" style="padding: 0 20px;">Save Record</md-button>
    <!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreviewMode()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->
    <hr>
    <table style="padding: 0; margin: 0;">
        <tr>
            <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
            </td>
            <td style="text-align: right; padding: 0; border: 0;">
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  CanadaGAP Food Safety Manual for
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  Fresh Fruits and Vegetables
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                </p>
            </td>
        </tr>
    </table>
    <br>
    <div class="row FullWidth">
        <div class="large-12 columns">

            <br>
            <p style="text-align: center;">Confirmation/Update Log:</p>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Signature</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_p2 as $p2)
                    <tr>
                        <td>{{ $p2->created_at }}</td>
                        <td>{{ $p2->author->first }} {{ $p2->author->last }}</td>
                        <td>
                            <md-button ng-click="showFormP2Details('{{ $p2->id }}')" class="md-primary">Details</md-button>
                            <md-button ng-click="confirmFormP2Record({{$org->id}}, {{$p2->author->id}}, {{$p2->id}})" class="md-primary">Confirm and Submit</md-button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</form>
</md-content>
@endforeach
