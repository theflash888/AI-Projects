@foreach(Auth::user()->organizations as $org)
<div class="FormJ" ng-controller="FormJController">
    <md-content>
        <p><b>Instructions:</b> Record cleaning and maintenance of both exterior and interior washrooms and hand washing facilities. Complete at least weekly (while in use) and daily during peak season for each facility. Write N/A in column if not applicable to facility. Cleaning includes toilet, sink, floor, paper towel dispenser, all handles (e.g., toilet handle, door knob, tap), etc.</p>
        <br>
        <div layout="row">
            <div flex>
                <md-input-container class="md-block" flex-gt-xs>
                    <label>Location</label>
                    <md-select ng-model="form_j.location" required ng-disabled="isInPreviewMode">
                      <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                            @{{ entity.name }}
                      </md-option>
                    </md-select>
                </md-input-container>
            </div>
            <div flex>
                <md-input-container class="md-block" flex-gt-xs>
                    <input placeholder="Location Type" name="location_type" ng-model="form_j.location_type" cols="30" rows="10" ng-disabled="isInPreviewMode" />
                </md-input-container>
            </div>
        </div>
        <div layout="row">
            <table class="table table-striped table-bordered tableHold">
                <thead>
                    <tr>
                        <th rowspan="2">Date and Time</th>
                        <th rowspan="2">
                            Assessment of Facilities (e.g., do toilets need emptying, are extra supplies needed, etc.)
                            <md-tooltip md-direction="bottom">
                          Check (✓) if assessment OK or after corrective action(s) taken (e.g., pumped toilets, stocked extra toilet paper, etc.)
                          </md-tooltip>
                        </th>
                        <th colspan="6">Items to Inspect For (✓)</th>
                        <th rowspan="2">
                            Employee Responsible for Cleaning (sign to confirm all cleaning completed) OR Person Confirming Cleaning Completed by a Company
                        </th>
                    </tr>

                    <tr>
                        <th>Disposable Paper Towels
                        </th>
                        <th>Soap</th>
                        <th>Water Source Operating (Hot and/or Cold Water
                        </th>
                        <th>Toilet Paper
                        </th>
                        <th>Hand Sanitizer /Wipes
                        </th>
                        <th>Garbage Emptied
                        </th>
                    </tr>
                </thead>
                <tbody>
                <form name="FormJForm">
                <tr>
                    <td>{{ date('Y-m-d H:i:s') }}</td>
                    <td><md-checkbox ng-model="form_j.assessment" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-checkbox ng-model="form_j.paper_towel" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-checkbox ng-model="form_j.soap" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-checkbox ng-model="form_j.water_source" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-checkbox ng-model="form_j.toilet_paper" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-checkbox ng-model="form_j.hand_sanitizer" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-checkbox ng-model="form_j.garbage_emptied" aria-label="Checkbox 1"></md-checkbox></td>
                    <td><md-button class="md-raised md-primary" ng-click="createNewRecord()" ng-disabled="FormJForm.$invalid" style="padding: 0 20px;">Save Record</md-button></td>
                </tr>
                </form>
                @foreach(App\Models\FormJ::where('organization_id', $org->id)->orderBy('created_at', 'DESC')->get() as $j)
                <tr>
                        <td colspan="9">
                            <div layout="row">
                                <div flex>
                                    <b>Location:</b> {{ $j->entity->name }}
                                </div>
                                <div flex>
                                    <b>Location Type: </b> {{ ($j->location_type ? $j->location_type : "None") }}
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>{{ $j->created_at }}</td>
                        <td><i class="{{ ($j->assessment) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td><i class="{{ ($j->paper_towel) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td><i class="{{ ($j->soap) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td><i class="{{ ($j->water_source) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td><i class="{{ ($j->toilet_paper) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td><i class="{{ ($j->hand_sanitizer) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td><i class="{{ ($j->garbage_emptied) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
                        <td>{{ $j->author->first }} {{ $j->author->last }}</td>
                    </tr>
                    <tr>
                        <br>
                    </tr>
                    
                @endforeach
                
                </tbody>
            </table>
        </div>
        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>
        <md-content>
</div>
@endforeach
