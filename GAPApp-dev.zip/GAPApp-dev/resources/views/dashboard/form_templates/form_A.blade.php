@foreach(Auth::user()->organizations as $org)
<md-content class="FormB md-padding" ng-controller="FormAController">
    <p>
        <b>Instructions</b>: Draw the interior floor plan of your buildings. As applicable, indicate the location of packing/repacking line(s), washroom(s), hand washing station(s), hand sanitizers/wipes, harvested and market product, market ready packaging materials, oil/fuel storage tank, water storage tank/container/cistern, ice storage containers/areas, interior and exterior pest control devices [e.g., traps (each must be numbered),bait stations etc.],pest control product storage, agricultural chemical storage if located inside buildings. Also check (ü) that the agricultural chemical storage meets the requirements in the box below. Make additional copies as necessary and complete as Page _ of _ to indicate more than one page if required.
    </p>
    <br>
    <p>If applicable, indicate in the following checkbox (<i class="bi_interface-tick"></i>) that your:</p>
    <p> Agricultural chemical storage is separate from the buildings diagrammed below. <br>
		<ul style="margin: 0 40px;">
			<li>A diagram of standalone agricultural chemical storage(s) is not required.</li>
			<li>The agricultural chemical storage checklist, below, does not need to be completed.</li>
		</ul>
    </p>
    <br>
    @foreach($org->entities_name as $en)
        @if($en->active == '1')
            <br>
            <md-card class="md-padding">
                <h4><b>Building Name:</b> {{ $en->name }}</h4>
                <md-divider></md-divider>
                @if(\App\Models\FormA::where('entity_id', $en->id)->count() > 0)
                    <img src="{{ env('S3') }}{{ \App\Models\FormA::where('entity_id', $en->id)->first()->storage_path }}" alt="">
                @else
                    <md-button class="md-primary md-raised" ngf-select="uploadFormA($files, '{{ $en->id }}')">Upload Building Picture</md-button>
                @endif             
            </md-card>
        @endif
    @endforeach

</md-content>
@endforeach