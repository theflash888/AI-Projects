@extends('dashboard.home')

@section('dashboard-content')
	@if($form_r)
	<div class="row animated fadeIn align-justify" >
		<div class="large-9 columns DBTitle">
			<h1>{{ 'R' }}. {{ \App\Models\FormList::where('form', 'R')->first()->title }}</h1>
		</div>
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3>{{ \App\Models\FormList::where('form', 'R')->first()->period }}</h3>
			</div>
		</div>
	</div>
	@endif
	<div class="row animated fadeIn FormRDetails {{ Request::is('dashboard/form/R') ? 'FullWidth' : null }}" ng-controller="FormRController">
		<div class="large-12 columns">
			<md-content class="md-padding">
				<table>
					<tr>
						<td width="40%" style="text-align: left;" class="md-padding"><b>Date/Time of Deviation or Complaint and Person Notified</b></td>
						<td width="60%">{{ $form_r->created_at }}</td>
					</tr>
					<tr>
						<td style="text-align: left;" class="md-padding"><b>Major Deviation/Complaint and Description</b></td>
						<td>{{ $form_r->major_deviation }}</td>
					</tr>
					<tr>
						<td style="text-align: left;" class="md-padding"><b>Cause of Deviation/Complaint</b></td>
						<td>{{ $form_r->cause_of_deviation }}</td>
					</tr>
					<tr>
						<td style="text-align: left;" class="md-padding"><b>Corrective Action(s)</b></td>
						<td>{{ $form_r->corrective_action }}</td>
					</tr>
					@if($form_r->prevention_of_recurrence && $form_r->modified_procedure)
					<tr>
						<td style="text-align: left;" class="md-padding"><b>Prevention of Recurrence (e.g., training employee)</b></td>
						<td>{{ $form_r->prevention_of_recurrence }}</td>
					</tr>
					<tr>
						<td style="text-align: left;" class="md-padding"><b>New/Modified Procedures</b></td>
						<td>{{ $form_r->modified_procedure }}</td>
					</tr>
					@endif
				</table>
				<br>
				<br>
				@if($form_r->incident->resolved == 0)
				<form name="FormRForm">
				{{ csrf_field() }}
					<!--<md-input-container class="md-block" flex-gt-sm required>
		            	<label>Prevention of Recurrence (e.g., training employee)</label>
		            	<input ng-model="form_r.prevention_of_recurrence" name="prevention_of_recurrence">
		          	</md-input-container>
		          	<md-input-container class="md-block" flex-gt-sm required>
		            	<label>New/Modified Procedures</label>
		            	<input ng-model="form_r.modified_procedure" name="modified_procedure">
		          	</md-input-container>-->
		          	<md-checkbox name="employee_trained" ng-model="form_r.employee_trained" required>
						Employees Trained on New/Modified  Procedures? (√)
		          	</md-checkbox>
		          	<br>
		          	<md-button class="md-primary md-raised" ng-click="resolveFormR('{{ $form_r->id }}')" ng-disabled="FormRForm.$invalid" style="padding: 0 20px;">Resolve</md-button>
				</form>
				@endif
			</md-content>
		</div>
	</div>
@stop
