@foreach(Auth::user()->organizations as $org)
<md-content class="FormC" ng-controller="FormN2Controller">
    <form name="FormN2Form">
      {{ csrf_field() }}
        <p><b>Instructions:</b> During fluming, washing, or drenching (e.g., dump tank, pit), if water potability is not maintained for tomatoes/apples immersed in water, complete the following chart to record your water and product temperatures. <b>Monitor each load of product to ensure that the product is at least 5.5˚C or 10˚F colder than the water (i.e., water is at least 5.5˚C or 10˚F warmer than the product).</b></p>
        <br>
        <div layout="row" md-block>
          <md-input-container class="md-block" flex-gt-xs>
              <label>Water Source</label>
              <md-select ng-model="form_n2.water_source" name="water_source" required  required>
                <md-option ng-repeat="source in waterSources" value="@{{ source.id }}">
                      @{{ source.name }}
                </md-option>
          </md-select>
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
              <label>Methods</label>
              <md-select ng-model="form_n2.method" name="method" required  required>
                <md-option ng-repeat="method in methods" value="@{{ method.id }}">
                      @{{ method.name }}
                </md-option>
          </md-select>
          </md-input-container>
        </div>
        <div layout="row" md-block ng-show="form_n2.method == '7'">
          <md-input-container class="md-block" flex-gt-xs>
            <label>Other Method</label>
            <input ng-model="form_n2.method_other" name="method_other"   required ng-required="form_n2.method == '7'">
          </md-input-container>
        </div>
        <div layout="row" md-block>

          <md-input-container class="md-block" flex-gt-xs>
            <label>Product</label>
            <input ng-model="form_n2.product" name="product"   required>
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
              <label>Month</label>
              <md-select ng-model="form_n2.month" name="month" required  required>
                <md-option ng-repeat="month in months" value="@{{ month.id }}">
                      @{{ month.month }}
                </md-option>
          </md-select>
          </md-input-container>
        </div>
        <div layout="columns">
        <p>Temperature Type: </p>
          <md-radio-group ng-model="form_n2.temp_type" layout="rows" style="margin: 0 20px;`">
      <md-radio-button value="C" class="md-primary">Celsius</md-radio-button>
      <md-radio-button value="F"> Fahrenheit </md-radio-button>
    </md-radio-group>
        </div>
        <div class="row FullWidth" style="margin: 20px auto;">
            <div class="large-12 columns">
                <table>
                    <thead>
                        <tr>
                            <th width="25%%">Temperature of Water (<b ng-show="form_n2.temp_type == 'C'">˚C</b> <b ng-show="form_n2.temp_type == 'F'">˚F</b>)</th>
                            <th width="25%%">Temperature of Product (<b ng-show="form_n2.temp_type == 'C'">˚C</b> <b ng-show="form_n2.temp_type == 'F'">˚F</b>)</th>
                            <th width="25%%">Difference</th>
                            <th width="25%%">Corrective Action Taken</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="padding: 10px 0;">
                              <md-input-container class="md-block" flex-gt-xs>
                                <label>Water Temperature</label>
                                <input ng-model="form_n2.water_temp" type="number" name="water_temp"   required>
                              </md-input-container>
                            </td>
                            <td style="padding: 10px 0;">
                              <md-input-container class="md-block" flex-gt-xs>
                                <label>Product Temperature</label>
                                <input ng-model="form_n2.product_temp" type="number" name="product_temp"   required>
                              </md-input-container>
                            </td>
                            <td style="padding: 10px 0;" ng-show="form_n2.temp_type == 'C'">
                              @{{ form_n2.difference = (form_n2.water_temp - form_n2.product_temp).toFixed(2) }} ˚C
                              <p ng-if="(form_n2.water_temp - form_n2.product_temp) < 5.5">Product has to be at least 5.5˚C colder than the water</p>
                            </td>
                            <td style="padding: 10px 0;" ng-show="form_n2.temp_type == 'F'">
                              @{{ form_n2.difference = ((form_n2.water_temp - form_n2.product_temp) * (9/5) + 32).toFixed(2) }} ˚F
                              <p ng-if="((form_n2.water_temp - form_n2.product_temp) * (9/5) + 32) < 41.9">Product has to be at least 41.9˚F colder than the water</p>
                            </td>
                            <td style="padding: 10px 0;">
                              <md-input-container  class="md-block" flex-gt-xs>
                                <label>Action Taken</label>
                                <input ng-model="form_n2.action_taken" name="action_taken"  ng-disabled="(form_n2.water_temp - form_n2.product_temp) < 5.5" required>
                              </md-input-container>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <md-button class="md-raised md-primary" ng-disabled="FormN2Form.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
    </form>
    <hr>
    <table style="padding: 0; margin: 0;">
        <tr>
            <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
            </td>
            <td style="text-align: right; padding: 0; border: 0;">
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  CanadaGAP Food Safety Manual for
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  Fresh Fruits and Vegetables
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                </p>
            </td>
        </tr>
    </table>
    <br>
    <div class="row FullWidth" style="margin: 20px auto;">
        <div class="large-12 columns">
            <table>
                <thead>
                    <tr>
                      <th>Date</th>
                      <th>Author</th>
                      <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_n2 as $n2)
                    <tr>
                        <td>{{ $n2->created_at }}</td>
                        <td>{{ $n2->author->first }} {{ $n2->author->last }}</td>
                        <td>
                          <md-button ng-click="showFormN2Details({{$org->id}}, {{$n2->author->id}}, {{$n2->id}})" class="md-primary">Details</md-button>
                          <md-button ng-click="confirmFormN2Record({{$org->id}}, {{$n2->author->id}}, {{$n2->id}})" class="md-primary">Confirm and Submit</md-button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</md-content>
@endforeach
