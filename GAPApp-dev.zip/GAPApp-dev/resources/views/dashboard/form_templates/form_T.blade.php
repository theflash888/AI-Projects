@foreach(Auth::user()->organizations as $org)
<md-content class="FormT" ng-controller="FormTController">

    <p><b>Instructions:</b> This form is intended to assess whether potential food defense/security risk factors exist. Consider if there could be a risk in the following categories and implement appropriate security measures. If additional risks were identified, describe them below. Detailed information can be found in Appendix T: Food Defense: Assessment of Possible Risks and List of Security Measures if further assistance is required. </p>
    <div class="FormT-Content">
    <form name="FormTForm">
        <div class="header">
            <h4>Inside Security Risk Assessment</h4>
        </div>
        <div class="body">
            <p><i>To protect product from intentional contamination, assess possible inside risks (e.g., packing/repacking area/facility security, agricultural chemical storage security, product security, information security, etc.).</i>
            </p>
            <br>
            <p><b>The following potential risk factors have been assessed and appropriate security measures have been implemented:</b>
            </p>
            <br>
            <md-checkbox ng-model="form_t.general_security" aria-label="" >
                General security (e.g., signs, observations, areas etc.)
            </md-checkbox>
            <br>
            <md-checkbox ng-model="form_t.storage_security" aria-label="" >
                Storage/Building Security
            </md-checkbox>
            <br>
            <md-checkbox ng-model="form_t.water_security" aria-label="" >
                Water/Ice Security
            </md-checkbox>
            <br>
            <md-checkbox ng-model="form_t.agriculture_security" aria-label="" >
                Agricultural Chemical/Cleaning and Maintenance Materials Control Security
            </md-checkbox>
            <br>
            <md-checkbox ng-model="form_t.information_security" aria-label="" >
                Information Security
            </md-checkbox>
            <br>
            <p><u>Personnel Security Risks</u>
            </p>
            <br>
            <p>To prevent personnel security risks, ensure that only authorized personnel (e.g., employees, visitors, etc.) are within the operation and employees are trained on food defense/security measures </p>
            <br>
            <p><b>The following potential risk factors have been assessed and appropriate security measures have been implemented:</b>
            </p>
            <br>
            <md-checkbox ng-model="form_t.personnel_security" aria-label="" >
                Personnel Security (e.g., check references, check IDs, security training, etc.)
            </md-checkbox>
        </div>
        <div class="header">
            <h4>Outside Security Risk Assessment</h4>
        </div>
        <div class="body">
            <p><i>To prevent unauthorized access by people, entry of unapproved inputs, or intentional contamination of product assess possible outside risks (e.g., production site/building security, mail handling security, etc.)</i>
            </p>
            <br>
            <hr>
            <br>
            <p><b>The following potential risk factors have been assessed and appropriate security measures have been implemented:</b>
            </p>
            <br>
            <md-checkbox ng-model="form_t.physical_security" aria-label="" >
                Physical Security (e.g., door locks, lighting etc.)
            </md-checkbox>
            <br>
            <md-checkbox ng-model="form_t.entry_security" aria-label="" >
                Entry of inputs/product (e.g., loading/unloading etc.)
            </md-checkbox>
        </div>
        <div class="body">
            <md-input-container class="md-block">
                <label>If other risks have been identified, list those below, along with the corrective actions taken:</label>
                <textarea ng-model="form_t.actions" columns="1" md-maxlength="500" rows="5" ></textarea>
            </md-input-container>
            <md-input-container>
				<md-button class="md-primary md-raised" ng-click="createNewRecord()" style="padding: 0 20px;">Save Record</md-button>
                <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
            </md-input-container>
        </div>
        </form>
				<hr>
				<table style="padding: 0; margin: 0; width: 100%;">
						<tr>
								<td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
										Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
								</td>
								<td style="text-align: right; padding: 0; border: 0;">
										<p style="padding: 0; margin: 0; line-height: 1.5em;">
											CanadaGAP Food Safety Manual for
										</p>
										<p style="padding: 0; margin: 0; line-height: 1.5em;">
											Fresh Fruits and Vegetables
										</p>
										<p style="padding: 0; margin: 0; line-height: 1.5em;">
												{{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
										</p>
								</td>
						</tr>
				</table>
				<br>

        <div class="body">
        	<p style="text-align: center;">Confirmation/Update Log:</p>
        	<table>
        		<thead>
        			<tr>
        				<th>Date</th>
        				<th>Signature</th>
        				<th>Details</th>
        			</tr>
        		</thead>
        		<tbody>
        		@foreach($org->forms_t as $t)
        			<tr>
        				<td>{{ $t->created_at }}</td>
        				<td>
                            {{ $t->author->first }} {{ $t->author->last }}
                        </td>
        				<td><md-button ng-click="showFormTDetails('{{ $t->date }}', {{$org->id}}, {{$t->user_id}}, '{{$t->id}}')" class="md-primary">Details</md-button>
                        <md-button ng-click="confirmFormTRecord({{$org->id}}, {{$t->author->id}}, {{$t->id}})" class="md-primary">Confirm and Submit</md-button></td>
        			</tr>
        			@endforeach
        		</tbody>
        	</table>
        </div>
    </div>
</md-content>
@endforeach
