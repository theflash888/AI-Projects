@foreach(Auth::user()->organizations as $org)
<md-content ng-controller="FormH2Controller" class="md-padding FormH2">
    <form name="FormH2Form">
      <p><b>Instructions:</b> Includes all applications from pre-planting through to, and including, harvest. One Form must be completed for <b>EACH PRODUCTION SITE</b>. <br> <i>Note: Mulch and Row Cover Applications DO NOT need to be recorded for Bulb and Root Vegetables.</i></p>
			<br>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Operation Name</label>
          <input ng-model="form_h2.operation_name" name="operation_name"  required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Previous Year Crop(s)</label>
          <input ng-model="form_h2.previous_year_crops" name="previous_year_crops"  required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Seed certification #:</label>
          <input ng-model="form_h2.seed_certificate" name="seed_certificate"  required>
          <div class="hint">FOR POTATOES ONLY</div>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Current Crop</label>
          <input ng-model="form_h2.current_crop" name="current_crop"  required>
        </md-input-container>
      </div>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
        <label>Product Site Information</label>
        <md-select ng-model="form_h2.product_site_information" required>
          <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                @{{ entity.name }}
          </md-option>
    </md-select>
    </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Production Site Area</label>
          <input ng-model="form_h2.production_site_area" name="production_site_area"  required>
        </md-input-container>
      </div>
      <div layout="rows">
        <label style="margin: 25px 0;">Date Planted:</label>
        <md-datepicker style="margin: 15px 0;" ng-model="form_h2.date_planted" md-placeholder="Enter date">
          </md-datepicker>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Variety</label>
          <input ng-model="form_h2.variety" name="variety"  required>
        </md-input-container>
      </div>
      <p>
        COMMERCIAL FERTILIZER APPLICATION
      </p>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>Blend</label>
          <input ng-model="form_h2.blend" name="blend"  required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Rate</label>
          <input ng-model="form_h2.commercial_rate" name="commercial_rate"  required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Fertilizer Lot # (if applicable)</label>
          <input ng-model="form_h2.fertilizer_lot_num" name="fertilizer_lot_num"  required>
        </md-input-container>
      </div>
      <p>
        MANURE*/COMPOST/COMPOST TEA/OTHER BY-PRODUCTS#/PULP SLUDGE/SOIL AMENDMENT/MULCH AND ROW COVER APPLICATIONS (except for plastic)
      </p>
      <div layout="rows">
        <md-input-container class="md-block" flex-gt-xs>
          <label>What is Applied</label>
          <input ng-model="form_h2.what_is_applied" name="what_is_applied"  required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Type**</label>
          <input ng-model="form_h2.type" name="type"  required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Supplier's Name</label>
          <input ng-model="form_h2.supplier_name" name="supplier_name"  required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Rate</label>
          <input ng-model="form_h2.manure_rate" name="manure_rate"  required>
        </md-input-container>
      </div>
      <div layout="rows">
        <p style="margin-top: 10px;">
            Earliest Allowable Harvest Date* (according to appropriate time delay)
        </p>
        <md-datepicker ng-model="form_h2.earliest_harvest_date" md-placeholder="Enter date" required></md-datepicker>
      </div>
      <md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormH2Form.$invalid" style="padding: 0 20px;">Save Record</md-button>
      <!--<md-button class="md-raised md-primary DetailsButton" ng-click="closePreviewMode()" ng-show="isInPreviewMode" style="padding: 0 20px;">Close Details</md-button>-->
      <hr>
      <table style="padding: 0; margin: 0;">
          <tr>
              <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                  Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
              </td>
              <td style="text-align: right; padding: 0; border: 0;">
                  <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    CanadaGAP Food Safety Manual for
                  </p>
                  <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    Fresh Fruits and Vegetables
                  </p>
                  <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                  </p>
              </td>
          </tr>
      </table>
      <br>
      <div class="row FullWidth">
					<div class="large-12 columns">

							<br>
							<p style="text-align: center;">Confirmation/Update Log:</p>
							<table>
									<thead>
											<tr>
													<th>Date</th>
													<th>Signature</th>
													<th>Details</th>
											</tr>
									</thead>
									<tbody>
											@foreach($org->forms_h2 as $h2)
											<tr>
													<td>{{ $h2->date }}</td>
													<td>{{ $h2->author->first }} {{ $h2->author->last }}</td>
													<td>
															<md-button ng-click="showFormH2Details('{{ $h2->id }}')" class="md-primary">Details</md-button>
                              <md-button ng-click="confirmFormH2Record({{$org->id}}, {{$h2->author->id}}, {{$h2->id}})" class="md-primary">Confirm and Submit</md-button>
													</td>
											</tr>
											@endforeach
									</tbody>
							</table>
					</div>
			</div>
    </form>
</md-content>
@endforeach
