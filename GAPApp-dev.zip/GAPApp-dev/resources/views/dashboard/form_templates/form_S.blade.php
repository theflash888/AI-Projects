@foreach(Auth::user()->organizations as $org)
	<md-content class="md-padding FormS" ng-controller="FormSController">
    <p><i><b>Instructions:</b> Fill out the chart below to assess the potential risks of allergens in your operation. Column I indicates the allergens from a practice used in the production of the product. Column II indicates the allergens from something in the production site (e.g., rotational crop). Column III indicates the allergens that may be found in the product, from addition or cross-contamination. Column IV indicates the allergens present in other products that are run on the same equipment/area but at a different time. Column V indicates whether any allergens are present in a building/vehicle.</i>
    </p>
    <br>
    <p>Each box of the table must be filled with a YES or a NO. If YES, describe (if applicable) any control measures used in the last row. All allergens listed are those identified by Health Canada and enforced for labelling by the Canadian Food Inspection Agency.</p>
    <br>
    <form name="FormSForm">
        <md-input-container class="md-block" flex-gt-xs>
            <label>Storage ID # / Name:</label>
            <md-select ng-model="form_s.storage_id" required >
                <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                    @{{ entity.name }}
                </md-option>
            </md-select>
        </md-input-container>
        <table class="FormSTable">
            <thead>
                <tr>
                    <th width="35%"></th>
                    <th width="13%">Column I</th>
                    <th width="13%">Column II</th>
                    <th width="13%">Column III</th>
                    <th width="13%">Column IV</th>
                    <th width="13%">Column V</th>
                </tr>
                <tr>
                    <th>Component</th>
                    <th>Present from a production practice</th>
                    <th>Present in the production site</th>
                    <th>Present in the product</th>
                    <th>Present in other products handled on the same line/area</th>
                    <th>Present in the same building/ vehicle</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><b>Peanut or its</b> derivatives, e.g., Peanut - pieces, protein, oil, butter, flour, and mandelona nuts (an almond flavoured peanut product) etc. Peanut may also be known as ground nut.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.peanut_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.peanut_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.peanut_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.peanut_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.peanut_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Tree Nuts</b> e.g., almonds, Brazil nuts, cashews, hazelnuts (filberts), macadamia nuts, pecans, pine nuts (pinyon, pinon), pistachios and walnuts or their derivatives, e.g., nut butters and oils etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.tree_nuts_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.tree_nuts_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.tree_nuts_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.tree_nuts_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.tree_nuts_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Sesame or its</b> derivatives, e.g., paste and oil etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sesame_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sesame_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sesame_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sesame_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sesame_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Milk or its</b> derivatives, e.g., milk caseinate, whey and yogurt powder etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.milk_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.milk_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.milk_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.milk_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.milk_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Eggs or its</b> derivatives, e.g., frozen yolk, egg white powder and egg protein isolates etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.eggs_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.eggs_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.eggs_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.eggs_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.eggs_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Fish or its</b> derivatives, e.g., fish protein and extracts etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.fish_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.fish_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.fish_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.fish_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.fish_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Shellfish</b> (including crab, crayfish, lobster, prawn and shrimp) <b>and Molluscs</b> (including snails, clams, mussels, oysters, cockle and scallops) or their derivative, e.g., extracts etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.shellfish_molluscs_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.shellfish_molluscs_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.shellfish_molluscs_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.shellfish_molluscs_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.shellfish_molluscs_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Soybeans or its</b> derivatives, e.g., lecithin, oil, tofu and protein isolates etc.</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.soybeans_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.soybeans_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.soybeans_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.soybeans_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.soybeans_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Cereals containing gluten</b> and their derivatives (specify which cereal (wheat, rye, barley, oats, spelt, kamut or their hybridised strains)).</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.cereals_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.cereals_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.cereals_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.cereals_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.cereals_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Sulphites</b>, e.g., sulphur dioxide and sodium metabisulphites etc. If yes, what is the amount in ppm?</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sulphites_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sulphites_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sulphites_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sulphites_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.sulphites_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

								<tr>
                    <td><b>Mustard</b> and products thereof</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.mustard_1">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.mustard_2">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.mustard_3">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.mustard_4">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                    <td>
                    	<md-input-container class="md-block" flex-gt-xs>
                            <md-radio-group ng-model="form_s.mustard_5">
      <md-radio-button value="yes" class="md-primary">Yes</md-radio-button>
      <md-radio-button value="no"> No </md-radio-button>
    </md-radio-group>
                        </md-input-container>
                    </td>
                </tr>

                <tr>
                    <td><b>Others</b> (as considered necessary for the customer)</td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <textarea ng-model="form_s.others_1" columns="1" md-maxlength="150" rows="5" ></textarea>
                        </md-input-container>
                    </td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <textarea ng-model="form_s.others_2" columns="1" md-maxlength="150" rows="5" ></textarea>
                        </md-input-container>
                    </td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <textarea ng-model="form_s.others_3" columns="1" md-maxlength="150" rows="5" ></textarea>
                        </md-input-container>
                    </td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <textarea ng-model="form_s.others_4" columns="1" md-maxlength="150" rows="5" ></textarea>
                        </md-input-container>
                    </td>
                    <td>
                        <md-input-container class="md-block" flex-gt-xs>
                            <textarea ng-model="form_s.others_5" columns="1" md-maxlength="150" rows="5" ></textarea>
                        </md-input-container>
                    </td>
                </tr>
						</tbody>
					</table>
					<table>
                <tr>
                    <td width="35.1%"><b>Comments and/or Additional Control Measures</b></td>
                    <td style="padding-top: 20px;">
                        <md-input-container class="md-block" flex-gt-xs>
														<label>Comments and/or Additional Control Measures</label>
                            <textarea ng-model="form_s.comments" columns="1" md-maxlength="500" rows="5" ></textarea>
                        </md-input-container>
                    </td>
                </tr>
        </table>
        <br>
        <md-button class="md-raised md-primary" ng-disabled="FormSForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->
				<hr>
				<table style="padding: 0; margin: 0;">
						<tr>
								<td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
										Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
								</td>
								<td style="text-align: right; padding: 0; border: 0;">
										<p style="padding: 0; margin: 0; line-height: 1.5em;">
											CanadaGAP Food Safety Manual for
										</p>
										<p style="padding: 0; margin: 0; line-height: 1.5em;">
											Fresh Fruits and Vegetables
										</p>
										<p style="padding: 0; margin: 0; line-height: 1.5em;">
												{{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
										</p>
								</td>
						</tr>
				</table>
				<br>
    </form>
                      <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Signature</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($org->forms_s as $s)
                        <tr>
                            <td>{{ $s->created_at }}</td>
                            <td>{{ $s->author->first }} {{ $s->author->last }}</td>
                            <td>
                                <md-button ng-click="showFormSDetails('{{ $s->id }}')" class="md-primary">Details</md-button>
                                <md-button ng-click="confirmFormSRecord({{$org->id}}, {{$s->author->id}}, {{$s->id}})" class="md-primary">Confirm and Submit</md-button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>


</md-content>
@endforeach
