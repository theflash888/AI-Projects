@foreach(Auth::user()->organizations as $org)
<div class="FormI" ng-controller="FormIController">
    <md-content>
        <p>Use this Form to record production site AND building equipment cleaning, maintenance AND calibration.</p>
        <br>
        <p><b>Instructions:</b> An inspection of your building equipment (e.g., cutting blades, brushes, packing/repacking lines, conveyors, belts, chlorinator, sprayer) must be conducted at least weekly (when in use). Check for leaks, broken, loose, corroded or damaged parts, soil, mud, build-up, etc. and any cleaning, maintenance and calibration needed. Hand-held cutting and trimming tools that come into direct contact with product must be inspected and cleaned daily with this activity recorded daily. See Section 8: Equipment for requirements for production site equipment. Record required activities below and give a brief description of why and how you are performing the activity.</p>
        <br>
        <form name="FormIForm">
        <div class="row FullWidth">
                    <div class="large-12 columns">
                        <div layout="rows">
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Equipment Activity Performed on</label>
                            <input ng-model="form_i.equipment" name="equipment" required>
                            <div ng-messages="NewFormIRecord.equipment.$error">
                                <div ng-message="required">
                                    Please enter a equipment activity!
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container flex-gt-sm>
                            <label>Activity Code</label>
                            <md-select ng-model="form_i.activity" required>
                                <md-option ng-repeat="activity in activites" value="@{{activity.id}}">@{{activity.name}}</md-option>
                            </md-select>
                            <div ng-messages="NewFormIRecord.activity.$error">
                                <div ng-message="required">
                                    Please select a activity!
                                </div>
                            </div>
                        </md-input-container>
                        </div>
                        <md-input-container class="md-block" flex-gt-sm ng-show="form_i.activity == 6">
                            <label>Specify other Activity Code</label>
                            <input ng-model="form_i.activity_other" name="activity_other">
                            <div ng-messages="NewFormIRecord.equipment.$error">
                                <div ng-message="required">
                                    Specify other Activity Code
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block">
                            <label>Description</label>
                            <textarea ng-model="form_i.description" columns="1" md-maxlength="500" rows="5"></textarea>
                        </md-input-container>

                    </div>
                          <md-button class="md-raised md-primary" ng-click="saveNewRecord()" ng-disabled="FormIForm.$invalid" style="padding: 0 20px;">Save Record</md-button>

                </div>
                </form>
        <div layout="row">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Employee Completing Job</th>
                        <th>Equipment Activity Performed On</th>
                        <th>Activity Code*</th>
                        <th>Brief Description of Activity</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_I as $i)
                    <tr>
                        <td>{{$i->created_at}}</td>
                        <td>{{$i->employee}}</td>
                        <td>{{$i->equipment}}</td>
                        <td>
                          @if($i->activity_code == 6)
                            {{ $i->activity_code }} -
                            {{ $i->activity_other }}
                          @else
                            {{ $i->activity_code }} -
                            {{ ($i->activity_code == 1) ? "Calibration" : null }}
                            {{ ($i->activity_code == 2) ? "Maintenance" : null }}
                            {{ ($i->activity_code == 3) ? "Repair" : null }}
                            {{ ($i->activity_code == 4) ? "Cleaning" : null }}
                            {{ ($i->activity_code == 5) ? "Inspection" : null }}
                          @endif
                        </td>
                        <td>{{$i->description}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <br>
        <p>*Activity Codes: 1 - Calibration 2 - Maintenance 3 - Repair 4 - Cleaning 5 - Inspection 6 - Other (specify)</p>
        <hr>
        <table style="padding: 0; margin: 0;">
            <tr>
                <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                    Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
                </td>
                <td style="text-align: right; padding: 0; border: 0;">
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      CanadaGAP Food Safety Manual for
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                      Fresh Fruits and Vegetables
                    </p>
                    <p style="padding: 0; margin: 0; line-height: 1.5em;">
                        {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                    </p>
                </td>
            </tr>
        </table>
        <br>

        </md-content>
</div>
@endforeach
