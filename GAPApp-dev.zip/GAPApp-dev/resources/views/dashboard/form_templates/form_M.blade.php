@foreach(Auth::user()->organizations as $org)
<md-content class="FormC" ng-controller="FormMController">
    <form name="FormMForm">
      {{ csrf_field() }}
        <p><b>Instructions:</b> Traps and control methods must be monitored a minimum of once a month (when in use) and the findings and action taken (if applicable) recorded below. Each trap or area controlled (e.g., for insects) must be recorded. Make additional copies as necessary.</p>
        <br>
        <md-input-container class="md-block" flex-gt-xs>
            <label>Storage ID # / Name:</label>
            <md-select ng-model="form_m.storage_id" name="storage_id" requiredrequired>
              <md-option ng-repeat="entity in entities" value="@{{ entity.id }}">
                    @{{ entity.name }}
              </md-option>
        </md-select>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Device Number (same as Form A) or Area Controlled (e.g., insect traps)</label>
          <input ng-model="form_m.device_number" name="device_number" required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Findings</label>
          <input ng-model="form_m.findings" name="findings" required>
        </md-input-container>
        <md-input-container class="md-block" flex-gt-xs>
          <label>Action Taken (cleaned area or traps, disposed of in garbage, chemical treatment, changed traps, etc.)</label>
          <textarea ng-model="form_m.action_taken" name="action_taken" columns="1" md-maxlength="150" rows="5"required></textarea>
        </md-input-container>
        <md-button class="md-raised md-primary" ng-disabled="FormMForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <div class="row FullWidth" style="margin: 20px auto;">
			<table>
                <thead>
                    <tr>
                        <th width="10%">Date</th>
                        <th width="15%">Device Number or Area Controlled</th>
                        <th width="15%">Findings</th>
                        <th width="20%">Action Taken</th>
                        <th width="10%">Person Responsible</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($org->forms_m as $m)
                    <tr>
                        <td>{{ $m->created_at }}</td>
                        <td>{{ $m->storage->name }}</td>
                        <td>{{ $m->findings }}</td>
                        <td>{{ $m->action_taken }}</td>
                        <td>{{ $m->author->first }} {{ $m->author->last }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </form>

    <hr>
    <table style="padding: 0; margin: 0;">
        <tr>
            <td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
                Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
            </td>
            <td style="text-align: right; padding: 0; border: 0;">
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  CanadaGAP Food Safety Manual for
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                  Fresh Fruits and Vegetables
                </p>
                <p style="padding: 0; margin: 0; line-height: 1.5em;">
                    {{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
                </p>
            </td>
        </tr>
    </table>
    <br>

</md-content>
@endforeach
