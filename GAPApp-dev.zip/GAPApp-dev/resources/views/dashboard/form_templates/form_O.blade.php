@foreach(Auth::user()->organizations as $org)
<md-content class="FormO md-padding" ng-controller="FormOController">
	<form name="FormOForm">
		<p class="md-padding"><b>Instructions:</b>  Complete for all product being transported to someone else’s premises</p>
		<br>
		<div layout="row" class="md-padding">
			<md-input-container class="md-block" flex-gt-xs>
				<md-checkbox ng-model="form_o.vehicle_inspected" aria-label="Checkbox 1" >
		            Vehicle Inspected?
		          </md-checkbox>
			</md-input-container>
			<md-input-container class="md-block" flex-gt-xs>
              <label>Hazards</label>
              <md-select ng-model="form_o.hazards" name="hazards" ng-disabled="form_o.vehicle_inspected" >
                <md-option ng-repeat="hazard in hazards" value="@{{ hazard.id }}">
                      @{{ hazard.id }}. @{{ hazard.name }}
                </md-option>
          </md-select>
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
              <label>Actions</label>
              <md-select ng-model="form_o.actions" name="actions" ng-disabled="form_o.vehicle_inspected || form_o.water_source || !form_o.hazards">
                <md-option ng-repeat="action in actions" value="@{{ action.id }}">
                      @{{ action.id }}. @{{ action.name }}
                </md-option>
          </md-select>
          </md-input-container>
		</div>
		<div class="md-padding">
			<md-input-container class="md-block" flex-gt-xs>
			<label>Product Identifier (Lot ID/ Pack ID/Field/Block #/Pallet/Bin Tag) (Same as on Form P1/P2 or Q)</label>
			<input type="text" ng-model="form_o.product_identifier"  required>
          </md-input-container>
          <div layout="rows">
          <md-input-container class="md-block" flex-gt-xs>
			<label>Quantity Shipped</label>
			<input type="text" ng-model="form_o.quantity_shipped" required >
          </md-input-container>
          <md-input-container class="md-block" flex-gt-xs>
			<label>Truck/Trailer ID #</label>
			<input type="text" ng-model="form_o.truck_id" required >
          </md-input-container>
          </div>
          <md-input-container class="md-block" flex-gt-xs>
			<label>Destination and Customer</label>
			<input type="text" ng-model="form_o.destination_and_customer" required >
          </md-input-container>

          <md-input-container class="md-block" flex-gt-xs>
      <label>Person Responsible (Loader)</label>
      <input type="text" ng-model="form_o.person_responsible" required >
          </md-input-container>
                  <md-button class="md-raised md-primary" ng-disabled="FormOForm.$invalid" ng-click="saveNewRecord()" style="padding: 0 20px;">Save Record</md-button>
        <!--<md-button class="md-raised md-primary DetailsButton" ng-show="isInPreviewMode" ng-click="closePreviewMode()" style="padding: 0 20px;">Close Details</md-button>-->

		</div>
		<hr>
		<table style="padding: 0; margin: 0;">
				<tr>
						<td style="vertical-align: top; padding: 0; text-align: left; border: 0;">
								Version {{ \App\Models\FormList::where('form', $form)->first()->version }}
						</td>
						<td style="text-align: right; padding: 0; border: 0;">
								<p style="padding: 0; margin: 0; line-height: 1.5em;">
									CanadaGAP Food Safety Manual for
								</p>
								<p style="padding: 0; margin: 0; line-height: 1.5em;">
									Fresh Fruits and Vegetables
								</p>
								<p style="padding: 0; margin: 0; line-height: 1.5em;">
										{{ env('FORM_YEAR') }}_v{{ \App\Models\FormList::where('form', $form)->first()->version }}
								</p>
						</td>
				</tr>
		</table>
		<br>

	</form>
                  <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Signature</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($org->forms_o as $o)
                        <tr>
                            <td>{{ $o->created_at }}</td>
                            <td>{{ $o->author->first }} {{ $o->author->last }}</td>
                            <td>
                                <md-button ng-click="showFormODetails('{{ $o->id }}')" class="md-primary">Details</md-button>
                                <md-button ng-click="confirmFormORecord({{$org->id}}, {{$o->author->id}}, {{$o->id}})" class="md-primary">Confirm and Submit</md-button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>

</md-content>

@endforeach
