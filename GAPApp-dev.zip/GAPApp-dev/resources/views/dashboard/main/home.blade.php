@extends('dashboard.home')

@section('dashboard-content')
	@foreach(Auth::user()->organizations as $org)
	<!--<div class="row animated fadeIn align-justify">
		<div class="large-12 columns OrganizationDashboardHeader" style="background: url('https://static.pexels.com/photos/4827/nature-forest-trees-fog-large.jpeg') no-repeat center center; background-size: cover;">
			<div class="AV">
					<img ng-src="{{ env('S3') . 'gapapp_organizations/logos/' . Auth::user()->organizations->first()->logo }}">
			</div>
		</div>
		<div class="large-12 columns OrganizationDashboardHeaderInfo">
			<h1>{{ Auth::user()->organizations->first()->name }}</h1>
			<h1>{{ $org->users->count() }} Members</h1>
		</div>
	</div>-->
	<div class="row align-justify" ng-controller="DashboardIncidentController">
		<div class="large-7 columns DashboardQuickIncident md-padding">
			<h4><i class="bi_editorial-compose"></i> Incidents</h4>
			<a href="{{ url('/dashboard/incidents') }}">+ Show More</a>
			<br>
			<table>
				<thead>
					<tr>
						<th width="20%">Date/Time</th>
						<th width="60%">Description</th>
						<th width="20%">Details</th>
					</tr>
				</thead>
				<tbody>
				@foreach(\App\Models\Incident::orderBy('created_at', 'DESC')->where('organization_id', $org->id)->limit(5)->get() as $incident)
					@if(!$incident->resolved)
						<tr>
							<td>{{ $incident->date }} {{ $incident->time }}</td>
							<td>{{ substr($incident->description, 0, 50) }}...</td>
							<td><md-button class="IncidentDetails" ng-click="toggleDetailsPage('{{ url('/dashboard/incidents/details/' . $incident->id) }}')">Details</md-button></td>
						</tr>
					@endif
				@endforeach
				</tbody>
			</table>
		</div>
		<div class="large-4 columns AnnouncementContainer">
			<h4><i class="bi_com-megaphone-a"></i> Announcements</h4>
			<br><br>
			<ul style="list-style: none; margin: 20px 0;">
				@foreach(\App\Models\Announcement::orderBy('created_at', 'DESC')->where('start_period', '<', date('Y-m-d H:i:s'))->where('end_period', '>', date('Y-m-d H:i:s'))->take(5)->get() as $ann)
				<li style="padding: 20px 0; border-bottom: 1px solid rgba(0, 0, 0, 0.1);">
					<p><b>{{ $ann->title }}</b></p>
					<p>{{ $ann->content }}</p>
				</li>
				@endforeach
			</ul>
		</div>
	</div>
	<div class="row align-justify">
		<div class="CalendarDashboardContainer large-7 columns md-padding">
			<h4><i class="bi_editorial-compose"></i> Calendar</h4>
			<a href="{{ url('/dashboard/calendar') }}">+ Show More</a>
			<br>
			<table>
				<thead>
					<tr>
						<th width="20%">Date/Time</th>
						<th width="60%">Title</th>
						<th width="20%">Details</th>
					</tr>
				</thead>
				<tbody>
				@foreach($org->calendars as $calendar)
						<tr>
							<td>{{ $calendar->date }} </td>
							<td>{{ substr($calendar->title, 0, 50) }}...</td>
							<td><md-button class="IncidentDetails" ng-click="toggleDetailsPage('{{ url('/dashboard/incidents/details/' . $incident->id) }}')">Details</md-button></td>
						</tr>
				@endforeach
				</tbody>
			</table>
		</div>
	</div>
	@endforeach
@stop
