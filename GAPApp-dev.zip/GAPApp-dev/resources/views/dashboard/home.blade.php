@extends('base.base')

@section('title', 'Dashboard')

@section('content')
	<ul class="VIMenu animated">
		<li class="Logo-Container animated fadeIn">
		</li>
		@if(Entrust::hasRole('superadmin'))
		<li class="{{ (Request::is('dashboard/administrator') || Request::is('dashboard/administrator/*')) ? 'is-active' : null }}" ><a href="{{ url('/dashboard/administrator') }}"><i class="bi_music-eq-a"></i><span>Admin</span></a></li>
		@endif
		<li class="{{ Request::is('dashboard') ? 'is-active' : null }}"><a href="{{ url('/dashboard') }}"><i class="bi_interface-dashboard"></i><span>Dashboard</span></a></li>
		<li class="{{ (Request::is('dashboard/form') || Request::is('dashboard/form/*')) ? 'is-active' : null }}"><a href="{{ url('/dashboard/form') }}"><i class="bi_doc-note-pen"></i><span>Forms</span></a></li>
		@if(Entrust::can('incidents'))
		<li class="{{ (Request::is('dashboard/incidents') || Request::is('dashboard/incidents/*')) ? 'is-active' : null }}"><a href="{{ url('/dashboard/incidents') }}"><i class="bi_web-report-a"></i><span>Incidents</span></a></li>
		@endif
		<li class="{{ Request::is('dashboard/report') || Request::is('dashboard/report/*') ? 'is-active' : null }}"><a href="{{ url('/dashboard/report') }}"><i class="bi_doc-pie-a"></i><span>Reports</span></li></a>
		@if(Entrust::can('audits'))
		<li class="{{ Request::is('dashboard/audits') || Request::is('dashboard/audits/*') ? 'is-active' : null }}"><a href="{{ url('/dashboard/audits') }}"><i class="bi_doc-pie-a"></i><span>Audits</span></li></a>
		@endif
		<li class="{{ (Request::is('dashboard/calendar') || Request::is('dashboard/calendar/*')) ? 'is-active' : null }}"><a href="{{ url('dashboard/calendar') }}"><i class="bi_interface-calendar"></i><span>Calendar</span></a></li>
		<li class="{{ (Request::is('dashboard/settings') || Request::is('dashboard/settings/*')) ? 'is-active' : null }}"><a href="{{ url('dashboard/settings') }}"><i class="bi_setting-gear-a"></i><span>Settings</span></a></li>
	</ul>
	<div class="Dashboard-Main">
		<header class="animated fadeIn" ng-controller="HeaderController">
			<div class="FullWidth">

				@if(Request::is('dashboard/form/*'))
				<md-input-container>
			        <label style="color: #FFFFFF;">Select Forms</label>
			        <md-select ng-change="changeForm()" ng-model="formSwitcher.form" style="color: #FFFFFF;">
			          <md-option ng-repeat="form in forms" value="@{{form.form}}">
			            Form @{{form.form}} - @{{form.title}}
			          </md-option>
			        </md-select>
			      </md-input-container>
			     @endif

			     <!--@if(Request::is('dashboard/report/*'))
				<md-button class="md-raised ReportDownloadButton" ng-href="{{ url('dashboard/report/download/' . $form) }}">Download PDF</md-button>
			     @endif-->
				<div class="ProfileMenuContainer">
					<div class="Profile-Menu">
						<a href="">Welcome, {{ Auth::user()->first }} <i class="bi_interface-bottom"></i></a>
						<div class="Profile-Menu-Float">
							<div class="Profile-Menu-Content">
								<div class="AV">
									<div class="uploader">
										<img src="https://projects.invisionapp.com/avatars/B5BBB33E-DB9C-A99D-C350CE9D1632C12A" alt="">
									</div>
								</div>
								<div class="Profile-Menu-Text">
									<h1>{{ Auth::user()->first }} {{ Auth::user()->last }}</h1>
									<p>{{ Auth::user()->email }}</p>
									<a href="{{ url('dashboard/settings') }}">Account Settings</a>
								</div>
								<ul>
									<!--<li><a href=""><i class="bi_web-browser-tab-plus"></i> Upgrade Plan <span class="new-tag">New</span></a></li>-->
									<li><a href="{{ url('/serviceLogin/logout') }}"><i class="bi_interface-power"></i> Logout</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div class="Dashboard-Main-Container" >
			@yield('dashboard-content')
		</div>
	</div>
@stop
