@extends('dashboard.home')

@section('dashboard-content')
<div ng-controller="AnnouncementController">
	<div class="row animated fadeIn align-justify">
		<div class="large-4 columns DBTitle">
			<h1><i class="bi_com-megaphone-a"></i> Announcements</h1>
		</div>
	</div>
  <div class="row">
      <div class="large-12 columns AnnouncementContainer md-padding">
          <form name="NewAnnouncement">
              <div layout="columns">
                <p style="margin: 10px 10px;">Start Date: </p>
                <md-datepicker ng-model="new_announcement.start_date" md-placeholder="Enter date"></md-datepicker>
                <p style="margin: 10px 10px; margin-left: 40px;">End Date:</p>
                <md-datepicker ng-model="new_announcement.end_date" md-placeholder="Enter date"></md-datepicker>
              </div>
              <md-input-container class="md-block" flex-gt-xs>
                <label>Title</label>
                <input ng-model="new_announcement.title" name="title"  ng-disabled="isInPreviewMode" required>
              </md-input-container>
              <md-input-container class="md-block" flex-gt-xs>
                <label>Content</label>
                <textarea ng-model="new_announcement.content" md-maxlength="500" rows="5" md-select-on-focus required></textarea>
              </md-input-container>
              <md-button class="md-raised md-primary" style="padding: 0 10px;" ng-disabled="NewAnnouncement.$invalid" ng-click="newAnnouncement()">Add Announcement</md-button>
          </form>
      </div>
  </div>
  <br>
	<div class="row" id="OrganizationList">
		<div class="large-12 columns IncidentsTable" style="padding-left: .9375rem !important; padding-right: .9375rem !important;">
			<div class="row align-justify IncidentsTable-Header" style="width: auto;">
				<div class="large-4 columns">
					<h3>List of Announcements</h3>
				</div>
				<div class="large-2 columns">
				</div>
			</div>
			<div class="row md-padding" style="background: #ffffff;">
				<md-card ng-repeat="ann in announcements" style="width: 100%;" class="md-padding">
            <table style="width: 100%;">
                <tr>
                    <td style="width: 80%; text-align: left;">
                      @{{ ann.title }}
                    </td>
                    <td style="width: 20%; text-align: right;">
                      @{{ ann.created_at }}
                    </td>
                </tr>
            </table>
            <md-divider></md-divider>
            <md-content style="padding-top: 10px;">
                @{{ ann.content }}
                <md-divider></md-divider>
                <md-button style="float: right; margin-top: 20px;" class="md-padding md-primary md-raised" ng-click="deleteAnnouncement($event, ann.id)">Delete</md-button>
            </md-content>
        </md-card>
			</div>
		</div>
	</div>
</div>
@stop
