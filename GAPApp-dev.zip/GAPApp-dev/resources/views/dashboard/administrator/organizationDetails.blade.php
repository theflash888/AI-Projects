@extends('dashboard.home')

@section('dashboard-content')
	<div class="row animated fadeIn align-justify">
		<div class="large-4 columns DBTitle">
			<h1>{{ $org->name }}</h1>
		</div>
		<div class="large-5 columns DBTitle">
			<div class="Admin-Stats">
				<h3>{{ $users->count() }}</h3>
				<a href="{{ url('/dashboard/administrator/organizations#OrganizationList') }}">Members</a>
			</div>
			<div class="Admin-Stats">
				@if(!$org->approved)
				<md-button><i class="bi_interface-tick"></i> Approve</md-button>
				@endif
			</div>
		</div>
	</div>
	<div class="row">
		<div class="large-12 columns OrganizationDetailsContainer">
			<md-card>
				<div class="row fullWidth">
					<div class="large-4 columns">
						<div class="OrgLogoContainer">
							@if(Storage::disk('local')->has('organizations/logos/' . $org->logo))
								<img src="data:image/jpeg;base64,{{ base64_encode(Storage::disk('local')->get('organizations/logos/'.$org->logo)) }}">
							@endif
						</div>
					</div>
					<div class="large-8 columns OrgDetailContainer">
						<h1><b>Type of organization:</b> {{ $org->type }}</h1>
						<h1><b>Person Responsible:</b> {{ $org->person_responsible }}</h1>
						<h1><b>Audit Company:</b> {{ $org->audit_company }}</h1>
						<h1><b>Audit Cycle:</b> {{ $org->audit_cycle }}</h1>
						<h1><b>Food & Safety Coordinator:</b> {{ $org->coordinator }}</h1>
						<p class="FormedOn"><b>Formed on:</b> {{ $org->created_at }}</p>
					</div>
				</div>
				<div class="row fullWidth">
					<div class="large-12 columns OrgDetailMemberContainer">
						<table>
							<thead>
								<tr>
									<th>Name</th>
									<th>Email</th>
									<th>Activated</th>
									<th>Verified</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								@foreach($users as $u)
								<tr>
									<td>{{ $u-> first }} {{ $u->last }}</td>
									<td>{{ $u->email }}</td>
									<td><i class="{{ ($u->activated) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
									<td><i class="{{ ($u->verified) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
									<td><md-button class="{{ (!$u->activated) ? 'OrgDevActivate' : 'OrgDevDectivate' }}">{{ (!$u->activated) ? 'Activate' : 'Deactivate' }}</md-button></td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</md-card>
		</div>
	</div>
@stop