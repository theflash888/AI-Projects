@extends('dashboard.home')

@section('dashboard-content')
	<div class="row animated fadeIn align-justify">
		<div class="large-5 columns DBTitle">
			<h1>Administrative Panel</h1>
		</div>
		<div class="large-4 columns DBTitle">
			<div class="Admin-Stats">
				<h3>{{ \App\Models\Organization::count() }}</h3>
				<a href="">Organizations</a>
			</div>
			<div class="Admin-Stats">
				<h3>{{ App\User::count() }}</h3>
				<a href="">Total Users</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="large-12 columns">
			<div class="row fullWidth">
				<div class="small-4 columns">
					<div class="AdminOption">
						<div class="IconContainer">
							<i class="bi_user-single-a-group"></i>
						</div>
						<div class="ActionContainer">
							<md-button ng-href="{{ url('/dashboard/administrator/organizations') }}">Organizations</md-button>
						</div>
					</div>
				</div>
				<div class="small-4 columns">
					<div class="AdminOption">
						<div class="IconContainer">
								<i class="bi_com-megaphone-a"></i>
						</div>
						<div class="ActionContainer">
								<md-button ng-href="{{ url('/dashboard/administrator/announcements') }}">Announcements</md-button>
						</div>
					</div>
				</div>
				<div class="small-4 columns">
					<div class="AdminOption">
						<div class="IconContainer">
							<i class="bi_web-database"></i>
						</div>
						<div class="ActionContainer">
							<md-button>Database</md-button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@stop
