@extends('dashboard.home')

@section('dashboard-content')
	<div class="row animated fadeIn align-justify" ng-controller="OrganizationRequestController">
		<div class="large-4 columns DBTitle">
			<h1>{{ $req->org_name }}</h1>
		</div>
		<div class="large-2 columns DBTitle">
			<div class="Admin-Stats">
				<md-button ng-click="approveOrganization('{{ $req->token }}')"><i class="bi_interface-tick"></i> Approve</md-button>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="large-12 columns OrganizationDetailsContainer">
			<md-card>
				<div class="row fullWidth">
					<div class="large-4 columns">
						<div class="OrgLogoContainer">
							
						</div>
					</div>
					<div class="large-8 columns OrgDetailContainer">
						<h1><b>Type of organization:</b> {{ $req->org_type }}</h1>
						<h1><b>Person Responsible:</b> {{ $req->org_first_name . ' ' . $req->org_last_name }}</h1>
						<h1><b>Audit Company:</b> {{ $req->org_audit_company }}</h1>
						<h1><b>Audit Cycle:</b> {{ $req->org_audit_cycle }}</h1>
						<h1><b>Food & Safety Coordinator:</b> {{ $req->org_fns_coordinator }}</h1>
						<p class="FormedOn"><b>Formed on:</b> {{ $req->created_at }}</p>
					</div>
				</div>
			</md-card>
		</div>
	</div>
@stop