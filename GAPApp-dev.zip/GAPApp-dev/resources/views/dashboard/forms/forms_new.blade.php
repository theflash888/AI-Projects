<md-content class="FormsMenuContent" ng-controller="FormsMenuController">
	<div class="row FullWidth">
		<div class="large-12 columns">
			<!--<md-input-container class="md-block">
	          <label>Search Form</label>
	          <input ng-model="user.address">
	        </md-input-container>-->
	        <h2>Forms</h2>
	        <!--<ul>
	        	<li ng-repeat="form in displayFormsList"><a href="{{ url('/dashboard/form') }}/@{{form.form}}">@{{ form.form }}. @{{ form.title }}</a></li>
	        </ul>-->
					<ul>
						@foreach(\App\Models\FormList::get() as $form)
							@if(Entrust::can('form_' . $form->form))
								@if($form->form != 'R2')
		        					<li><a href="{{ url('/dashboard/form') }}/{{$form->form}}">{{ $form->form }}. {{ $form->title }}</a></li>
		        				@endif
							@endif
						@endforeach
	        </ul>
		</div>
	</div>
</md-content>
