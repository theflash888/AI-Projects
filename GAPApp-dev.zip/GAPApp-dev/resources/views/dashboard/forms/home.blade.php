@extends('dashboard.home')

@section('dashboard-content')
	@if($form)
	<div class="row animated fadeIn align-justify" ng-controller="FormParentController">
		<div class="large-9 columns DBTitle">
			<h1>{{ $form }}. {{ \App\Models\FormList::where('form', $form)->first()->title }}</h1>
		</div>
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3>{{ \App\Models\FormList::where('form', $form)->first()->period }}</h3>
				<a href="" class="NewIncidentPopupToggle" ng-click="showIncidentDialog('{{\App\Models\FormList::where('form', $form)->first()->id}}')"><i class="bi_editorial-compose"></i> New Incident</a>
			</div>
		</div>
	</div>
	@endif
	<div class="row animated fadeIn {{ Request::is('dashboard/form/R') ? 'FullWidth' : null }} PlaceholderFix HBarFOE">
		<div class="large-12 columns" style="padding: 15px;">
			<div class="FormsBorder">
			@if($form)
				@include ('dashboard.form_templates.form_' . $form)
			@else
				@include ('dashboard/forms/forms_new')
			@endif
		</div>
		</div>
	</div>
@stop
