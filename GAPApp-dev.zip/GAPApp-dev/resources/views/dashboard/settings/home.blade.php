@extends('dashboard.home')

@section('dashboard-content')
@foreach(Auth::user()->organizations as $org)
	<div class="row animated fadeIn align-justify">
		<div class="large-4 columns DBTitle">
			<h1><i class="bi_interface-calendar"></i> Settings</h1>
		</div>
	</div>
	<div class="row animated fadeIn SettingsTab">
		<div class="large-12 columns" ng-controller="SettingsController">
			<md-tabs md-border-bottom md-dynamic-height>
				<md-tab label="account">
					<md-content class="md-padding">
						<h3 style="margin: 20px 0;">Password</h3>
						<hr>
						<div class="row">
							<div class="large-6 columns">
								<form name="passChangeSettings">
									<md-input-container class="md-block" flex-gt-sm>
						                <label>Current Password</label>
						                <input ng-model="passsetting.password" name="password" type="password" required>
						                <div ng-messages="passChangeSettings.password.$error">
								          <div ng-message-exp="['required']">
								            Please enter your current password
								          </div>
								        </div>
						            </md-input-container>

						            <md-input-container class="md-block" flex-gt-sm>
						                <label>New Password</label>
						                <input ng-model="passsetting.newPassword" name="newPassword" type="password" required>
						                <div ng-messages="passChangeSettings.newPassword.$error">
								          <div ng-message-exp="['required']">
								            Please enter your new password
								          </div>
								        </div>
						            </md-input-container>

						            <md-input-container class="md-block" flex-gt-sm>
						                <label>Repeat Password</label>
						                <input ng-model="passsetting.repeatPassword" name="repeatPassword" type="password" required>
						                <div ng-messages="passChangeSettings.repeatPassword.$error">
								          <div ng-message-exp="['required']">
								            Repeat your new password
								          </div>
								        </div>
						            </md-input-container>

						            <md-button class="md-primary md-raised" ng-disabled="passChangeSettings.$invalid" ng-click="changePasswordSettings()" style="padding: 0 20px;" flex-gt-sm>
										Save Password
						            </md-button>
					            </form>
							</div>
						</div>
					</md-content>
				</md-tab>

				@if(Auth::user()->hasRole('orgadmin' . $org->id) || Entrust::can('edit-settings'))

				<md-tab label="roles">
					<md-content class="md-padding">
					<form name="NewRole">
						<md-card layout="row" class="md-padding">

							 <md-input-container class="md-block" flex-gt-sm>
						                <label>Role Name</label>
						                <input ng-model="role.role_name" name="name" type="text" required ng-disabled="isPermissionEnabled">
						                <div ng-messages="NewRole.name.$error">
								          <div ng-message-exp="['required']">
								            Role name required!
								          </div>
								        </div>
						            </md-input-container>
						             <md-input-container class="md-block" flex-gt-sm>
						                <label>Role Identifier</label>
						                <input ng-model="role.role_identifier" name="identifier" type="text" required ng-disabled="isPermissionEnabled">
						                <div ng-messages="NewRole.identifier.$error">
								          <div ng-message-exp="['required']">
								            Role identifier required!
								          </div>
								        </div>
						            </md-input-container>
						           <md-button ng-click="createRole('{{ $org->id }}')" ng-disabled="NewRole.$invalid || isPermissionEnabled">
										Create Role
						           </md-button>
						</md-card>
						</form>
						<br>
						<table ng-show="isPermissionEnabled == false">
							<thead>
								<tr>
									<th>Role</th>
									<th>Name</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<tr ng-repeat="role in roles">
									<td>@{{ role.display_name }}</td>
									<td>@{{ role.name }}</td>
									<td><md-button class="md-raised md-primary" style="padding: 0 20px;" ng-click="showPermissions(role.id)">Permissions</md-button></td>
								</tr>
							</tbody>
						</table>
						<md-card ng-show="isPermissionEnabled == true" class="md-padding">
							<div layout="row">
								<h3 flex="90">@{{ roleName }}</h3>
								<a flex="10" ng-click="closePermissionsWindow()" style="line-height: 2em; text-align: right; text-decoration: none; color: rgba(0, 0, 0, 0.5); cursor: pointer;">Close</a>
							</div>
							<br>
						<table>
							<thead>
								<tr ng-repeat="permission in permissions">
									<td style="text-align: left; padding-left: 20px;">
										@{{ permission.name }}
									</td>
									<td style="width: 100px;">
										<md-checkbox ng-model="permission.canUse" aria-label="@{{ permission.name }}" ng-change="changePermissions(permission.id)"></md-checkbox>
									</td>
								</tr>
							</thead>
						</table>
					</md-card>
					</md-content>
				</md-tab>

				<md-tab label="entities">
					<md-content class="md-padding">
						<md-card class="md-padding">
						<h3>Add New Entity</h3>
						<md-divider></md-divider>
						<div class="row FullWidth">
							<div class="large-5 columns">
								<form name="NewEntityForm">
										<md-input-container class="md-block" >
								                <label>Entity Name</label>
								                <input ng-model="entity.entity_name" name="entity_name" type="text" required>
								                <div ng-messages="NewEntityForm.entity_name.$error">
										          <div ng-message-exp="['required']">
										            Please enter entity name
										          </div>
										        </div>
								            </md-input-container>
										<md-button class="md-primary md-raised NewEntityButton" ng-disabled="NewEntityForm.$invalid" ng-click="NewEntity('{{ $org->id }}')" style="padding: 0 20px; margin: 20px 0;" >
												Add Entity
								            </md-button>

						</form>
							</div>
							<div class="large-7 columns">
								<table style="margin: 20px 0;">
								<thead>
									<tr>
										<th>Name</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
									<tr ng-repeat="entity in entities">
										<td>@{{ entity.name }}</td>
										<td class="md-padding" style="text-align: center;">
											<md-switch ng-model="entity.active" name="active" aria-label="@{{ entity.id }}" ng-change="ChangeActiveState(entity.id)">
											    @{{ (entity.active) ? 'Active' : "Inactive" }}
											  </md-switch>
										</td>
									</tr>
								</tbody>
							</table>
							</div>
						</div>

						</md-card>
					</md-content>
				</md-tab>

				<md-tab label="users">
					<md-content class="md-padding">
						<md-card class="md-padding">
						<h3>Users</h3>
						<md-divider></md-divider>
						<form name="NewUserForm">
								<div layout="row">


							<md-input-container class="md-block" flex-gt-sm>
													<label>First Name</label>
													<input ng-model="newuser.firstname" name="firstname" type="text" required ng-disabled="isPermissionEnabled">
													<div ng-messages="NewUserForm.firstname.$error">
												<div ng-message-exp="['required']">
													First Name Required!
												</div>
											</div>
											</md-input-container>
											<md-input-container class="md-block" flex-gt-sm>
																	<label>Last Name</label>
																	<input ng-model="newuser.lastname" name="lastname" type="text" required ng-disabled="isPermissionEnabled">
																	<div ng-messages="NewUserForm.lastname.$error">
																<div ng-message-exp="['required']">
																	Last Name Required!
																</div>
															</div>
															</md-input-container>
														</md-input-container>
														<md-input-container class="md-block" flex-gt-sm>
																				<label>Email Address</label>
																				<input ng-model="newuser.email" name="email" type="text" ng-pattern="/^.+@.+\..+$/" required ng-disabled="isPermissionEnabled">
																				<div ng-messages="NewUserForm.email.$error">
																			<div ng-message-exp="['required', 'pattern']">
																				Valid Email Address required!
																			</div>
																		</div>
																		</md-input-container>
															</div>
															<div layout="row">
																<md-input-container class="md-block" flex-gt-sm>
																	<label>Assign Role</label>
																<md-select ng-model="newuser.role_id" aria-label="" required>
																	<md-option ng-repeat="role in roles" value="@{{ role.id }}">@{{ role.display_name }}</md-option>
																</md-select>
																</md-input-container>
																	<md-input-container class="md-block" flex-gt-sm>
																							<label>Password</label>
																							<input ng-model="newuser.password" name="password" type="password" required ng-disabled="isPermissionEnabled">
																							<div ng-messages="NewUserForm.password.$error">
																						<div ng-message-exp="['required']">
																							Password Required!
																						</div>
																					</div>
																					</md-input-container>
																	<md-input-container class="md-block" flex-gt-sm>
																							<label>Repeat Password</label>
																							<input ng-model="newuser.repeat_password" name="repeat_password" type="password" required ng-disabled="isPermissionEnabled">
																							<div ng-messages="NewUserForm.email.$error">
																						<div ng-message-exp="['required']">
																							Repeat Password!
																						</div>
																					</div>
																</md-input-container>
																<md-button class="md-raised md-primary" ng-click="CreateUser()">Add User</md-button>
															</div>
						</form>
						<md-divider></md-divider>
						<div class="row FullWidth" style="margin: 20px auto;">
							<div class="large-12 columns">
								<table>
									<thead>
										<tr>
											<th>Name</th>
											<th>Email</th>
											<th>Role</th>
											<!--<th>Activated</th>
											<th>Verified</th>-->
										</tr>
									</thead>
									<tbody>
										<!--@foreach($org->users as $user)
										<tr>
											<td>{{ $user->first }} {{ $user->last }}</td>
											<td>{{ $user->email }}</td>
											<td>
												<md-select ng-model="user.role">
													<md-option ng-repeat="role in roles" value="@{{ role.id }}">@{{ role.display_name }}</md-option>
												</md-select>
											</td>
											<td><i class="{{ ($user->activated) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
											<td><i class="{{ ($user->verified) ? 'bi_interface-tick' : 'bi_interface-cross' }}"></i></td>
										</tr>
										@endforeach-->
										<tr ng-repeat="user in users track by $index">
											<td>@{{ user.user.first }} @{{ user.user.last }}</td>
											<td>@{{ user.user.email }}</td>
											<td>
												<md-select ng-model="user.role.role_id" ng-change="changeUserRole(user.user.id, user.role.role_id)" aria-label="@{{ user.user.first }}">
													<md-option ng-repeat="role in roles" value="@{{ role.id }}">@{{ role.display_name }}</md-option>
												</md-select>
											</td>
											<!--<td><i class="bi_interface-tick" ng-show="@{{ user.user.activated }}"></i><i class="bi_interface-tick" ng-show="@{{ !user.user.activated }}"></i></td>
											<td><i class="bi_interface-tick" ng-show="@{{ user.user.verified }}"></i><i class="bi_interface-tick" ng-show="@{{ !user.user.verified }}"></i></td>-->
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</md-content>
				</md-tab>
				@endif
			</md-tabs>
		</div>
	</div>
	@endforeach
@stop
