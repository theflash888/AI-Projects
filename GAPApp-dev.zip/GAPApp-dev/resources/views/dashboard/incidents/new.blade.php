@extends('dashboard.home')

@section('dashboard-content')
	<div class="row animated fadeIn align-justify">
    <div class="large-4 columns DBTitle">
        <h1><i class="bi_editorial-compose"></i> New Incidents</h1>
    </div>
</div>
<div class="row">
    <div class="large-12 columns" ng-controller="IncidentsController">
        <md-content class="md-padding NewIncident">
            <div class="row">
                <div class="large-1 columns"></div>
                <div class="large-10 large-centered columns">
                    <form name="NewIncidentForm">
                        <!--<span class="NewIncident-DateLabel">Date of the Incident:</span><md-datepicker ng-model="newincident.date" name="date" md-placeholder="Enter date"></md-datepicker>
							<div layout="row">
								<p class="timeLabel">Time of the incident:</p>
								<md-input-container class="md-block">
					                <label>Hour</label>
					                <input required type="number" step="any" name="hour" ng-model="newincident.hour" min="0" max="23" />
					                <div ng-messages="NewIncidentForm.hour.$error" md-auto-hide="true">
							          <div ng-message="required">
							            Please enter hour
							          </div>
							          <div ng-message="min">
							          	Invalid hour
							          </div>
							          <div ng-message="max">
							          	Invalid hour
							          </div>
							        </div>
					            </md-input-container>
					            <md-input-container class="md-block">
					                <label>Minute</label>
					                <input required type="number" step="any" name="minute" ng-model="newincident.minute" min="0" max="59" />
					                <div ng-messages="NewIncidentForm.minute.$error">
							          <div ng-message="required">
							            Please enter minute
							          </div>
							          <div ng-message="min">
							          	Invalid minute
							          </div>
							          <div ng-message="max">
							          	Invalid minute
							          </div>
							        </div>
					            </md-input-container>
				            </div>-->
                        <md-input-container flex-gt-sm>
                            <label>Select Related Form</label>
                            <md-select ng-model="newincident.relatedForm" name="relatedForm" required>
                                <md-option ng-repeat="form in newincident.forms" value="@{{form.id}}">
                                    Form @{{form.form}} - @{{form.title}}
                                </md-option>
                            </md-select>
                            <div ng-messages="NewIncidentForm.relatedForm.$error">
                                <div ng-message="required">
                                    Please select Related Form
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block" flex-gt-sm>
                            <label>Deviation Type</label>
                            <md-select ng-model="newincident.deviationType" required>
                                <md-option ng-repeat="devType in deviationTypes" value="@{{devType.id}}">
                                    @{{devType.name}}
                                </md-option>
                            </md-select>
                        </md-input-container>
                        <br>
                        <md-input-container class="md-block">
                            <label>Deviation Description</label>
                            <textarea ng-model="newincident.description" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="NewIncidentForm.description.$error">
                                <div ng-message="required">
                                    Please enter description
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block">
                            <label>Cause of Deviation</label>
                            <textarea ng-model="newincident.cause_deviation" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="NewIncidentForm.cause_deviation.$error">
                                <div ng-message="required">
                                    Please enter cause of deviation
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block">
                            <label>Corrective Action</label>
                            <textarea ng-model="newincident.corrective_action" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="NewIncidentForm.corrective_action.$error">
                                <div ng-message="required">
                                    Please enter corrective action
                                </div>
                            </div>
                        </md-input-container>
                        <!--<div class="row FullWidth">
					        	<div class="large-7 columns" style="padding: 0 !important; margin: 10px auto;">
									  <div class="NewIncident-UploadArea" ngf-select ng-model="pictures" name="pictures" ngf-pattern="'image/*'"
									    ngf-accept="'image/*'" ngf-max-size="20MB" ngf-min-height="100" 
									    ngf-drop ngf-multiple="true">Drag & Drop or click to Select images</div>
					        	</div>
					        	<div class="large-5 columns IncidentsPicList">
					        		<ul>
					        			<li ng-repeat="p in pics">@{{ p.name | limitTo: 30 }}</li>
					        		</ul>
					        	</div>
					        </div>-->
                        <md-button class="md-primary md-raised" ng-disabled="NewIncidentForm.$invalid" ng-click="CreateNewIncident()" style="padding: 0 20px;">Create Incidents</md-button>
                    </form>
                </div>
                <div class="large-1 columns"></div>
            </div>
        </md-content>
    </div>
@stop