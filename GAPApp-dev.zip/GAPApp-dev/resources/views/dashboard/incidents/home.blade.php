@extends('dashboard.home')

@section('dashboard-content')
	@foreach(Auth::user()->organizations as $org)
	<br>
	
	<div class="row animated fadeIn align-justify">
		<div class="large-6 columns DBTitle">
			<h1><i class="bi_editorial-compose"></i> Incidents <a href="{{ url('/dashboard/incidents/new') }}" class="NewIncident-Button"><i class="bi_interface-plus"></i> New Incident</a></h1>
			
		</div>
		<div class="large-3 columns DBTitle">
			<div class="Admin-Stats">
				<h3>{{ $org->incidents->where('resolved', '0')->count() }}</h3>
				<a href="">Open Incidents</a>
			</div>
		</div>
	</div>
	<div class="row HBarFOE" ng-controller="IncidentImagesController" style="padding: 15px">
		<div class="large-12 columns IncidentsTable">
			<div class="FormsBorder--Incident" style="padding: 8px 25px;">
			<div class="row align-justify IncidentsTable-Header">
				<div class="large-4 columns">
					<h3>Latest Open Reported Incidents</h3>
				</div>
			</div>
			<div class="row">
				<table>
					<thead>
						<tr>
							<th>Date Time</th>
							<th>Author</th>
							<th>Description</th>
							<th>Form</th>
							<th>Details</th>
							<th>Images</th>
						</tr>
					</thead>
					<tbody>
						@foreach(\App\Models\Incident::orderBy('created_at', 'DESC')->where('organization_id', $org->id)->get() as $incident)
							@if(!$incident->resolved)
							<tr>
								<td>{{ $incident->date }} {{ $incident->time }}</td>
								<td>
								{{ $incident->author->first }} {{ $incident->author->last }}
								</td>
								<td>{{ substr($incident->description, 0, 50) }}...</td>
								<td>
									Form {{ $incident->form['form'] }}
									<md-tooltip md-direction="bottom">{{ $incident->form['title'] }}</md-tooltip>
								</td>
								<td><md-button class="IncidentDetails" ng-click="toggleDetailsPage('{{ url('/dashboard/incidents/details/' . $incident->id) }}')">Details</md-button></td>
								<td><md-button ng-click="toggleImagesSidebar('{{ $incident->id }}')" class="IncidentImages">Images</md-button></td>
							</tr>
							@endif
						@endforeach
					</tbody>
				</table>
			</div>
			</div>
		</div>
		<md-sidenav class="md-sidenav-right md-whiteframe-z2 IncidentsImagesSidebar" md-component-id="incright">
	      <md-toolbar class="md-theme-light">
	        <a class="IncidentImagesToggle" ng-click="toggleImagesSidebar()"><i class="bi_interface-cross"></i></a>
	      </md-toolbar>
	      <md-content  layout-padding>
	      	<form name="incidentUploadForm">
		      	<md-card class="IncidentImagesUploader" ngf-select="uploadFiles($files)" multiple="multiple">
					<span><i class="bi_web-upload"></i></span>
		        </md-card>
	        </form>
	        <md-card ng-repeat="image in images">
				<img ng-src="@{{ image.file_path }}" alt="">
	        </md-card>
	      </md-content>
    </md-sidenav>
	</div>
    @endforeach
@stop