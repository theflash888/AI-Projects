@extends('dashboard.home')

@section('dashboard-content')
	@foreach(Auth::user()->organizations as $org)
	<div class="row animated fadeIn align-justify">
		<div class="large-4 columns DBTitle">
			<h1><i class="bi_com-group-bubble-c"></i> Incident Details</h1>
		</div>
	</div>
		<div class="row" ng-controller="FormRController">
			<div class="large-12 columns">
				<md-content class="md-padding IncidentDetailsContent">
					<h3>Type of deviation
						@if(Auth::user()->hasRole('orgadmin' . $org->id)) 
						@if($incident->deviation_type == 1)
							<md-button class="md-raised md-primary ChangeDeviationButton" ng-click="changeDeviationType('{{ $incident->id }}')" style="padding: 0 20px;" name="resolve" value="{{ $incident->id }}">Change to Minor Deviation</md-button>
						@else
							<md-button class="md-raised md-primary ChangeDeviationButton" ng-click="changeDeviationType('{{ $incident->id }}')" style="padding: 0 20px;" name="resolve" value="{{ $incident->id }}">Change to Major Deviation</md-button>
						@endif
						@endif
						</h3>
					<p>{{ ($incident->deviation_type == 1) ? "Major Deviation" : "Minor Deviation" }}

					</p>
					<br>
					<h3>Deviation Description</h3>
					<p>{{ $incident->description }}</p>
					<br>
					<h3>Form</h3>
					<p>Form {{ $incident->form['form'] }}</p>
					<br>
					<h3>Deviation Cause of Deviation</h3>
					<p>{{ $incident->cause_deviation }}</p>
					<br>
					<h3>Corrective Action</h3>
					<p>{{ $incident->corrective_action }}</p>
					<br>
					@if($incident->prevention_recurrence && $incident->deviation_type == 1)
					<h3>Prevention of Recurrence</h3>
					<p>{{ $incident->prevention_recurrence }}</p>
					<br>
					@endif
					@if($incident->modified_procedure && $incident->deviation_type == 1)
					<h3>New/Modified Procedures</h3>
					<p>{{ $incident->modified_procedure }}</p>
					<br>
					@endif
					<p class="MetaInfo">Created on: {{ $incident->created_at }} <span>By: {{ $incident->author->first }} {{ $incident->author->last }}</span></p>
				</md-content>
				<md-content>
					<div class="row FullWidth md-padding">
						@foreach($incident->images as $image)
						<div class="large-5 columns">
							<img src="{{ env('S3') }}{{ $image->storage_path }}" alt="">
						</div>					
						@endforeach
					</div>
					
				</md-content>
				<md-content class="md-padding" ng-init="editIncidentFormData('{{ $incident->id }}')"><!-- ng-show="editIncidentForm" -->
					<h3>Edit Incident</h3>
					<form name="EditIncidentForm">
						<md-input-container flex-gt-sm>
                            <label>Select Related Form</label>
                            <md-select ng-model="editincident.relatedForm" name="relatedForm" required>
                                <md-option ng-repeat="form in forms" value="@{{form.id}}">
                                    Form @{{form.form}} - @{{form.title}}
                                </md-option>
                            </md-select>
                            <div ng-messages="NewIncidentForm.relatedForm.$error">
                                <div ng-message="required">
                                    Please select Related Form
                                </div>
                            </div>
                        </md-input-container>
						<md-input-container class="md-block">
                            <label>Deviation Description</label>
                            <textarea ng-model="editincident.description" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="EditIncidentForm.description.$error">
                                <div ng-message="required">
                                    Please enter description
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block">
                            <label>Cause of Deviation</label>
                            <textarea ng-model="editincident.cause_deviation" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="EditIncidentForm.cause_deviation.$error">
                                <div ng-message="required">
                                    Please enter cause of deviation
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block">
                            <label>Corrective Action</label>
                            <textarea ng-model="editincident.corrective_action" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="EditIncidentForm.corrective_action.$error">
                                <div ng-message="required">
                                    Please enter corrective action
                                </div>
                            </div>
                        </md-input-container>
                        @if($incident->deviation_type == 1)
                        <md-input-container class="md-block">
                            <label>Prevention of Recurrence (e.g., training employee)</label>
                            <textarea ng-model="editincident.prevention_recurrence" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="EditIncidentForm.prevention_recurrence.$error">
                                <div ng-message="required">
                                    Please enter corrective action
                                </div>
                            </div>
                        </md-input-container>
                        <md-input-container class="md-block">
                            <label>New/Modified Procedures</label>
                            <textarea ng-model="editincident.modified_procedure" md-maxlength="500" rows="10" required></textarea>
                            <div ng-messages="EditIncidentForm.modified_procedure.$error">
                                <div ng-message="required">
                                    Please enter corrective action
                                </div>
                            </div>
                        </md-input-container>
                        @endif
                        <md-button class="md-primary md-raised" ng-disabled="EditIncidentForm.$invalid" ng-click="SaveIncidentChanges('{{ $incident->id }}')" style="padding: 0 20px;">Save Changes</md-button>
					</form>
				</md-content>
				@if(Auth::user()->hasRole('orgadmin')) 
				<md-content class="md-padding" style="margin: 20px 0;">
					<h3>Incident's Log</h3>
					<table class="IncidentsLog">
						<tr>
							<th>Author</th>
							<th>Actions</th>
							<th>Timestamp</th>
						</tr>
						@foreach($incident->logs as $log)
						<tr>
							<td>{{ $log->user->first }} {{ $log->user->last }}</td>
							<td>{{ $log->comments }}</td>
							<td>{{ $log->created_at }}</td>
						</tr>
						@endforeach
					</table>
				</md-content>
				@endif
				<md-content  class="md-padding IncidentDetailsContent">
					<md-list>
						@foreach($incident->comments as $comment)
						<md-list-item class="md-3-line md-long-text">
					        <img ng-src="" class="md-avatar" alt="" />
					        <div class="md-list-item-text">
					          <h3>{{ $comment->author->first }} {{ $comment->author->last }}</h3>
					          <p>
					            {{ $comment->comment }}
					          </p>
					          <p>
					          	{{ $comment->created_at }}
					          </p>
					        </div>
					      </md-list-item>
					     @endforeach
					     <md-divider></md-divider>
					     @if($incident->resolved == '0')
					     <md-list-item class="md-3-line md-long-text">
							<img ng-src="" class="md-avatar" alt="" />
							<div class="md-list-item-text">
								<form action="{{ url('/api/new/incidents/comment') }}" name="NewIncidentComment" method="post">
									{{ csrf_field() }}
									<input type="text" value="{{ $incident->id }}" name="incident_id" hidden />
									<md-input-container class="md-block">
							          <label>Comment</label>
							          <textarea ng-model="incident_comment.newComment" name="newComment" columns="1" md-maxlength="500" rows="5" required></textarea>
							        </md-input-container>
							         <md-input-container class="md-block">
							        <md-button class="md-raised md-primary" type="submit" style="padding: 0 20px;" ng-disabled="NewIncidentComment.$invalid">Add Comments</md-button>
							        @if(Auth::user()->hasRole('orgadmin'))
									@if($incident->deviation_type == 2)
									<md-button class="md-raised md-primary ResolveButton" ng-click="createMinorFormRRecord('{{ $incident->id }}', '{{ $incident->deviation_type }}', $event)" style="padding: 0 20px;" name="resolve" value="{{ $incident->id }}">Resolve Incident</md-button>
									@else
									<md-button class="md-raised md-primary ResolveButton" ng-click="createMajorFormRRecord('{{ $incident->id }}', '{{ $incident->deviation_type }}')" style="padding: 0 20px;" name="resolve" value="{{ $incident->id }}">Resolve Incident</md-button>
									@endif
									<!--<md-button class="md-raised md-primary" ng-click="editIncidentFormData('{{ $incident->id }}')" style="padding: 0 20px;" name="resolve" value="{{ $incident->id }}">Edit Incident</md-button>-->
							        @endif
							        </md-input-container>
						        </form>
							</div>
					     </md-list-item>
					     @endif
					</md-list>
				</md-content>
			</div>
		</div>
	@endforeach
@stop