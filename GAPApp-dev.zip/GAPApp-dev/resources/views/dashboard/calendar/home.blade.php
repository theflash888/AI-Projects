@extends('dashboard.home')

@section('dashboard-content')
	<div class="FullWidth animated fadeIn align-justify">
		<div class="large-4 columns DBTitle">
			<h1><i class="bi_interface-calendar"></i> Calendar</h1>
		</div>
	</div>
	<div class="row animated fadeIn FullWidth" ng-controller="CalendarController">
		<div class="large-9 columns">
			<calendar selected="day"></calendar>
		</div>
		<div class="large-3 columns calendarDetail">
			<div class="header">
				<h1 ng-data="@{{day.format('dddd')}}">@{{day.format('dddd, MMMM Do YYYY')}}</h1>
				 <md-button class="md-fab" aria-label="New Event" ng-click="addNewEvent()">
		            <i class="bi_interface-plus"></i>
		        </md-button>
			</div>
			<md-content>
				<md-list>
			      <md-list-item class="md-3-line" ng-repeat="event in events">
			        <img ng-src="" class="md-avatar" alt="" />
			        <div class="md-list-item-text" layout="column">
			          <h3>@{{ event.title }}</h3>
			          <h4>@{{ event.type }}</h4>
			          <p>@{{ event.description }}</p>
			        </div>
			      </md-list-item>
			    </md-list>
			</md-content>
		</div>
	</div>
@stop