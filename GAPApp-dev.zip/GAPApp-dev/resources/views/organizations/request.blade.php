@extends('base.base')

@section('title', 'Request')

@section('content')
	<div class="MainHeader">
		<div class="OverlayContent">
			<div class="row MainNav">
				<div class="small-4 columns">
					lol
				</div>
				<div class="small-8 columns animated fadeInDown">
					<ul>
						<li><a href="">{{ trans('messages.navMenuAbout') }}</a></li>
						<li><a href="">{{ trans('messages.navMenuService') }}</a></li>
						<li><a href="">{{ trans('messages.navMenuContact') }}</a></li>
						<li><a href="/serviceLogin" class="loginButton">{{ trans('messages.navMenuLogin') }}</a></li>
					</ul>
				</div>
			</div>
			<div class="row">
				<h1 class="animated fadeInUp">{{ trans('messages.orgReqTitle') }}</h1>
			</div>
		</div>
	</div>
	<form name="OrgReqForm">
	<div class="row RequestOrg align-center animated fadeIn" ng-controller="OrganizationRequestController">
	    <div class="large-7 columns">
	        <h3>{{ trans('messages.orgReqInfoTitle') }}</h3>
	        <div layout="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqInfoName') }}</label>
	                <input ng-model="organization.name" name="name" required>
	                <div ng-messages="OrgReqForm.name.$error">
			          <div ng-message="required">
			            Please enter Organization Name!
			          </div>
			        </div>
	            </md-input-container>
	            <md-input-container flex-gt-sm>
	                <label>{{ trans('messages.orgReqInfoType') }}</label>
	                <md-select ng-model="organization.type" required>
	                    <md-option ng-repeat="orgType in organizationType" value="@{{orgType}}">@{{orgType}}</md-option>
	                </md-select>
	                <div ng-messages="OrgReqForm.type.$error" role="alert">
			          <div ng-message="required">
			            Please select the type of organization!
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <h3>{{ trans('messages.orgReqResTitle') }}</h3>
	        <div layout-gt-sm="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqResFirstName') }}</label>
	                <input ng-model="organization.firstName" name="firstName" required>
	                <div ng-messages="OrgReqForm.firstName.$error" role="alert">
			          <div ng-message="required">
			            Please enter person's responsible first name!
			          </div>
			        </div>
	            </md-input-container>
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqResLastName') }}</label>
	                <input ng-model="organization.lastName" name="lastName" required>
	                <div ng-messages="OrgReqForm.lastName.$error" role="alert">
			          <div ng-message="required">
			            Please enter person's responsible last name!
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <h3>{{ trans('messages.orgReqAuditInfo') }}</h3>
	        <div layout-gt-sm="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqAuditComp') }}</label>
	                <input ng-model="organization.auditCompany" name="auditCompany" required>
	                <div ng-messages="OrgReqForm.auditCompany.$error" role="alert">
			          <div ng-message="required">
			            Please enter an audit company!
			          </div>
			        </div>
	            </md-input-container>
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqAuditCycle') }}</label>
	                <input ng-model="organization.auditCycle" name="auditCycle" required>
	                <div ng-messages="OrgReqForm.auditCycle.$error" role="alert">
			          <div ng-message="required">
			            Please enter your audit cycle!
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <h3>{{ trans('messages.orgReqFoodNSafety') }}</h3>
	        <div layout-gt-sm="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqFoodNSafetyCoordName') }}</label>
	                <input ng-model="organization.foodNSafety" name="foodNSafety" required>
	                <div ng-messages="OrgReqForm.foodNSafety.$error" role="alert">
			          <div ng-message="required">
			            Please enter your Food and Safety Co-ordinator's full name!
			          </div>
			        </div>
	            </md-input-container>
	        </div>
	        <h3>{{ trans('messages.orgReqEmailCallback') }}</h3>
	        <div layout-gt-sm="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>{{ trans('messages.orgReqEmailCallback') }}</label>
	                <input ng-model="organization.contactEmail" name="contactEmail" ng-pattern="/^.+@.+\..+$/" required>
	                <div ng-messages="organization.contactEmail.$error" role="alert">
			          <div ng-message-exp="['required', 'pattern']">
			            Email address must be in a valid format!
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <div layout-gt-sm="row">
	        	<md-button type="submit" ng-disabled="OrgReqForm.$invalid" class="md-raised md-primary RequestButton" ng-click="OrgRequestFormValidate()" flex-gt-sm>Send Request</md-button>
	        </div>
	    </div>
	</div>
	</form>
@stop