@extends('base.base')

@section('title', 'Request')

@section('content')
	<div class="MainHeader">
		<div class="OverlayContent">
			<div class="row MainNav">
				<div class="small-4 columns">
					lol
				</div>
				<div class="small-8 columns animated fadeInDown">
					<ul>
						<li><a href="">{{ trans('messages.navMenuAbout') }}</a></li>
						<li><a href="">{{ trans('messages.navMenuService') }}</a></li>
						<li><a href="">{{ trans('messages.navMenuContact') }}</a></li>
						<li><a href="/serviceLogin" class="loginButton">{{ trans('messages.navMenuLogin') }}</a></li>
					</ul>
				</div>
			</div>
			<div class="row">
				<h1 class="animated fadeInUp">{{ \App\Models\Organization::where('token', '=', $token)->first()->name }}</h1>
			</div>
		</div>
	</div>
	@if(count(\App\Models\Organization::where('token', '=', $token)->first()->users) == 0)
	<form name="orgSignupForm">
	<div class="row RequestOrg align-center animated fadeIn" ng-controller="OrganizationRequestController">
	    <div class="large-7 columns">
	        <h3></h3>
			<div layout="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>First Name</label>
	                <input ng-model="organization.firstName" name="firstName" required>
	                <div ng-messages="orgSignupForm.firstName.$error">
			          <div ng-message-exp="['required']">
			            Please enter your first name
			          </div>
			        </div>
	            </md-input-container>
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>Last Name</label>
	                <input ng-model="organization.lastName" name="lastName" required>
	                <div ng-messages="orgSignupForm.lastName.$error">
			          <div ng-message-exp="['required']">
			            Please enter your last name
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <div layout="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>Email Address</label>
	                <input ng-model="organization.emailAddr" name="emailAddr" ng-pattern="/^.+@.+\..+$/" required>
	                <div ng-messages="orgSignupForm.emailAddr.$error">
			          <div ng-message-exp="['required', 'pattern']">
			            Please enter your valid email address for login
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <div layout="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>Repeat Email Address</label>
	                <input ng-model="organization.repeatEmailAddr" name="repeatEmailAddr" required>
	                <div ng-messages="orgSignupForm.repeatEmailAddr.$error">
			          <div ng-message="required">
			            Please repeat your email address
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <div layout="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>Password</label>
	                <input type="password" ng-model="organization.password" name="password" required minlength="5" maxlength="15">
	                <div ng-messages="orgSignupForm.password.$error">
			          <div ng-message-exp="['required', 'minlength', 'maxlength']">
			            Please enter password between 5-15 characters long
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <div layout="row">
	            <md-input-container class="md-block" flex-gt-sm>
	                <label>Repeat Password</label>
	                <input type="password" ng-model="organization.repeatPassword" name="repeatPassword" required>
	                <div ng-messages="orgSignupForm.repeatPassword.$error">
			          <div ng-message="required">
			            Please repeat your password for verification
			          </div>
			        </div>
	            </md-input-container>
	        </div>

	        <div layout-gt-sm="row">
	        	<md-button type="submit" ng-disabled="orgSignupForm.$invalid" class="md-raised md-primary RequestButton" ng-click="OrgSignupFormRequest('{{ $token }}')" flex-gt-sm>Send Request</md-button>
	        </div>
	    </div>
	</div>
	</form>
	@endif
@stop
