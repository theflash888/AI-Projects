@extends('base.base')

@section('title', 'Request')

@section('content')
	<div class="MainHeader">
		<div class="OverlayContent">
			<div class="row MainNav">
				<div class="small-4 columns">
					lol
				</div>
				<div class="small-8 columns animated fadeInDown">
					<ul>
						<li><a href="">{{ trans('messages.navMenuAbout') }}</a></li>
						<li><a href="">{{ trans('messages.navMenuService') }}</a></li>
						<li><a href="">{{ trans('messages.navMenuContact') }}</a></li>
						<li><a href="/serviceLogin" class="loginButton">{{ trans('messages.navMenuLogin') }}</a></li>
					</ul>
				</div>
			</div>
			<div class="row">
				@if($validated)
				<h1 class="animated fadeInUp">Your email has been successfully verified!</h1>
				@else
				<h1 class="animated fadeInUp">Your email has already been verified!</h1>
				@endif
			</div>
		</div>
	</div>
@stop