<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
   
   'navMenuAbout' => 'About',
   'navMenuService' => 'Service',
   'navMenuContact' => 'Contact',
   'navMenuLogin' => 'Login',

    'orgReqTitle' => "Request an Organization Access",

    'orgReqInfoTitle' => 'Organization Information',
    'orgReqInfoName' => 'Organization Name',
    'orgReqInfoType' => 'Organization Type',

    'orgReqResTitle' => 'Person Responsible',
    'orgReqResFirstName' => 'First Name',
    'orgReqResLastName' => 'Last Name',

    'orgReqAuditInfo' => 'Audit Information',
    'orgReqAuditComp' => 'Audit Company',
    'orgReqAuditCycle' => 'Audit Cycle',

    'orgReqFoodNSafety' => 'Food & Safety',
    'orgReqFoodNSafetyCoordName' => 'Coordinator Name',

    'orgReqEmailCallback' => 'Contact Email Address',

    'orgReqSendButton' => 'Send Request'
];
