var elixir = require('laravel-elixir'),
	gulp = require('gulp'),
	sass = require('gulp-sass'),
	minifyCss = require('gulp-cssnano'),
	rename = require('gulp-rename'),
	appDir = 'resources/assets/sass/',
	coffeeDir = 'resources/assets/coffee/',
	notify = require('gulp-notify'),
	coffee = require('gulp-coffee'),
	gutil = require('gulp-util'),
	minifyJs = require('gulp-uglify'),
	connect = require('gulp-connect'),
	inlinesource = require('gulp-inline-source'),
	minifyhtml = require('gulp-htmlmin'),
	zopfli = require('gulp-zopfli'),
	exec = require('child_process').exec;


/*
 |--------------------------------------------------------------------------
 | Elixir Asset Management
 |--------------------------------------------------------------------------
 |
 | Elixir provides a clean, fluent API for defining some basic Gulp tasks
 | for your Laravel application. By default, we are compiling the Sass
 | file for our application, as well as publishing vendor resources.
 |
 */

gulp.task('js', function () {
	return elixir(function (mix) {

	});
});

gulp.task('sass', function () {
	return gulp.src('./resources/assets/sass/app.scss')
		.pipe(sass().on('error', gutil.log))
		.pipe(minifyCss().on('error', gutil.log))
		.pipe(rename({ extname: '.min.css' }).on('error', gutil.log))
		.pipe(gulp.dest('./public/css/').on('error', gutil.log))
});

gulp.task('coffee', function() {
	return gulp.src('./resources/assets/coffee/**/*.coffee')
		.pipe(coffee().on('error', gutil.log))
		//.pipe(minifyJs())
		.pipe(rename({extname: '.min.js'}).on('error', gutil.log))
		.pipe(gulp.dest('./public/scripts/').on('error', gutil.log))
		//.pipe(notify('Coffee compiled'));
});

gulp.task('phpunit', function() {
	exec('phpunit', function(error, stdout) {
		console.log(stdout);
	});
});

gulp.task('minify', function () {
	return gulp.src('./resources/assets/coffee/**/.html')
		.pipe(inlinesource({compress: true}))
		.pipe(minifyhtml())
		.pipe(gulp.dest('./public/scripts/'))
});

gulp.task('compress', function () {
	return gulp.src('./resources/assets/coffee/**/.html')
		.pipe(zopfli())
		.pipe(gulp.dest('./public/scripts/'))
});

gulp.task('watch', function() {
	gulp.watch(appDir + '/**/*.scss', ['sass']);
	gulp.watch(coffeeDir + '/**/*.coffee', ['coffee']);
	gulp.watch('app/**/*.php', ['phpunit']);
});

gulp.task('deploy', function () {
	gulp.start('minify', 'compress');
});

gulp.task('default', ['sass', 'coffee', 'phpunit', 'watch', 'js']);