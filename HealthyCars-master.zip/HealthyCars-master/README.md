# Healthy-Cars
By Amusement Park

- Fuel Consumption Ratings: http://open.canada.ca/data/en/dataset/98f1a129-f628-4ce4-b24d-6f16bf24dd64
